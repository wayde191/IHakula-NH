require 'sinatra/base'
require 'sinatra/config_file'
require 'sinatra/json'
require 'json'
require 'sinatra/cookies'

require_relative '../stores/ihakula_store'
require_relative '../log/log_formatter'
require_relative '../log/log_wrapper'

class IhakulaResource < Sinatra::Base

  helpers Sinatra::JSON
  register Sinatra::ConfigFile
  set :environments, %w{development test prod}
  config_file '../../config.yml'
  use Rack::Session::Cookie, {secret: settings.session_secret}

  get '/sale/records' do
    write_request_details_to_log('IhakulaResource', request, '{}')
    json ihakula_store.get_all_sale_records(get_current_user_group_id())
  end

  get '/accounts' do
    write_request_details_to_log('IhakulaResource', request, '{hello:world}')
    json ihakula_store.get_all_accounts
  end

  private

  def ihakula_store
    IhakulaStore.new(settings)
  end

  def write_request_details_to_log(action, request, request_parameters)
    @logger = LogWrapper.new(LogFormatter.new, settings)
    @logger.info_details(action, request, request_parameters, 'IhakulaResource')
  end

  def get_current_user_group_id
    session[:group_id]
  end

end
