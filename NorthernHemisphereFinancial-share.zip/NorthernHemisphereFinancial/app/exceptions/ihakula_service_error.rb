class IhakulaServiceError < Exception
end
