class ExternalError < StandardError
#  TODO Add timestamp to message for debugging purposes
end
