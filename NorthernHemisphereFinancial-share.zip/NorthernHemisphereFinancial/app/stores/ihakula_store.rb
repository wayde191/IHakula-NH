require 'json'
require 'digest/md5'
require 'perfect-random-number-generator'

require_relative '../exceptions/ihakula_service_error'
require_relative '../database/ihakula_db'
require_relative '../log/log_formatter'
require_relative '../log/log_wrapper'
require_relative '../http/status_code'

include StatusCodes

class IhakulaStore

  def initialize(settings)
    @settings = settings
    @logger = LogWrapper.new(LogFormatter.new, settings)
  end

  def get_all_accounts
    begin
      Ih_products.find(1).description
    rescue StandardError => ex
      write_exception_details_to_log(ex, 'get_all_accounts', 'paras')
      raise IhakulaServiceError
    end
  end

  def get_all_sale_records(group_id)
    begin
      group = get_group(group_id)
      group_users = group.members
      group_users_detail_info = get_group_users_detail_info(group_users)
      group_users_records = get_group_users_records(group_users)

      account_field = get_account_field()
      account_field_detail = get_account_field_detail()

      all_sale_records_hash = Hash.new
      all_sale_records_hash['users'] = group_users;
      all_sale_records_hash['users_detail_info'] = group_users_detail_info
      all_sale_records_hash['users_sale_records'] = group_users_records
      all_sale_records_hash['account_field'] = account_field
      all_sale_records_hash['account_field_detail'] = account_field_detail

      all_sale_records_hash
    rescue StandardError => ex
      write_exception_details_to_log(ex, 'get_all_sale_records', 'paras')
      raise IhakulaServiceError
    end
  end

  def login(username, password)
    begin
      users = Ih_users.where(user_email: username, user_pass: Digest::MD5.hexdigest(password))
      users[0]
    rescue StandardError => ex
      write_exception_details_to_log(ex, 'get_all_accounts', 'paras')
      raise IhakulaServiceError
    end
  end

  # Northern Hemisphere Weixin
  def get_all_user_coupon(open_id)
    Ih_nh_qrcode.where(open_id:open_id)
  rescue ActiveRecord::RecordNotFound
    NOT_FOUND
  end

  def get_coupon(qrcode)
    qrcode = Ih_nh_qrcode.find_by(code:qrcode)
    if qrcode.nil? then
      {status:NOT_FOUND}
    else
      coupon_used_date = qrcode[:used_date].nil?;
      if coupon_used_date.nil?

      end
      res = {
          status: OK,
          name: qrcode[:name],
          code: qrcode[:code],
          used: qrcode[:used],
          end_date: qrcode[:end_date].strftime('%Y-%m-%d %H:%M:%S'),
          used_date: qrcode[:used_date] == nil ? '00-00-00 00:00:00' : qrcode[:used_date].strftime('%Y-%m-%d %H:%M:%S'),
          activity_type: qrcode[:activity_type],
          discount: qrcode[:discount],
          denomination: qrcode[:denomination],
          expire: 'no'
      }

      end_date = qrcode[:end_date]
      current = Time.now
      if current >= end_date then
        res[:expire] = 'yes'
      end

      res
    end
  rescue ActiveRecord::RecordNotFound
    {status:NOT_FOUND}
  end

  def used_coupon(qrcode)
    qrcode = Ih_nh_qrcode.find_by(code:qrcode)
    if qrcode.nil? then
      {status:NOT_FOUND}
    else
      res = {status:OK}

      end_date = qrcode[:end_date]
      current = Time.now
      if current >= end_date then
        res[:status] = COUPON_EXPIRED
      elsif qrcode[:used] == 'yes' then
        res[:status] = COUPON_USED
      else
        qrcode[:used] = 'yes'
        qrcode[:used_date] = get_current_time
        qrcode.save
      end

      res
    end
  rescue ActiveRecord::RecordNotFound
    {status:NOT_FOUND}
  end

  def get_coupon_by_id(qr_id, open_id)
    Ih_nh_qrcode.find_by(open_id:open_id, ID:qr_id)
  rescue ActiveRecord::RecordNotFound
    NOT_FOUND
  end

  def get_user_activity_coupon(open_id, activity_id)
    Ih_nh_qrcode.find_by(open_id:open_id, activity_id:activity_id)
  rescue ActiveRecord::RecordNotFound
    NOT_FOUND
  end

  def get_user_activity(open_id, activity_id)
     Ih_nh_user_activity.find_by(open_id:open_id, activity_id:activity_id)
  rescue ActiveRecord::RecordNotFound
    NOT_FOUND
  end

  def get_all_activities
    Ih_nh_activities.all
  end

  def get_activity_by_id(activity_id)
    Ih_nh_activities.find(activity_id)
  rescue ActiveRecord::RecordNotFound
    NOT_FOUND
  end

  def insert_user_request(from_user, request_xml)
    Ih_nh_requests.create(from_user_name: from_user, content: request_xml, date: get_current_time)
  end

  def user_first_time_subscribe(request_json)
    is_first_time = false
    user = Ih_nh_user.find_by(open_id: request_json['xml']['FromUserName'])
    if user.nil?
      is_first_time = true
    end

    is_first_time
  end

  def user_subscribe(request_json)
    user = Ih_nh_user.find_by(open_id: request_json['xml']['FromUserName'])
    if user.nil? then
      open_id = request_json['xml']['FromUserName']
      Ih_nh_user.create(open_id: open_id,
                        subscribe_date: get_current_time,
                        unsubscribe_date: '0000-00-00 00:00:00',
                        subscribe_times: 1
      )
      # user_join_activity(open_id, 1)
    else
      sub_times = user[:subscribe_times]
      sub_times = sub_times + 1
      user[:subscribe_times] = sub_times
      user[:subscribe_date] = get_current_time
      user.save

    end
  end

  def draw_user_prize(open_id, activity_id)
    res = {}

    activity = get_activity_by_id(activity_id)
    user_activity = get_user_activity(open_id, activity_id)
    unless user_activity.nil?
      res[:status] = ACTIVITY_HAS_JOINED
      user_activity_coupon = get_user_activity_coupon(open_id, activity_id)
      res[:coupon] = user_activity_coupon unless user_activity_coupon == NOT_FOUND
    else
      activity_rule = activity[:prize]
      activity_rule_arr = activity_rule.split('-')
      prize_base = Integer(activity_rule_arr[0])
      prize_rates = activity_rule_arr[1].split(',')

      random_number = (PerfectRandom::rand % prize_base) + 1
      prize_rates.each do |rate|
        rate_ele = rate.split(':')
        rate_number = Integer(rate_ele[0])
        prize_id = Integer(rate_ele[1])
        if random_number <= rate_number
          @prize_id = prize_id
          break;
        end
      end

      prize_obj = Ih_nh_prize.find(@prize_id)
      coupon = generate_coupon(activity_id, open_id)

      Ih_nh_qrcode.create(
          open_id: open_id,
          name: prize_obj[:name],
          activity_id: activity_id,
          code: coupon,
          start_date: prize_obj[:start_date],
          end_date: prize_obj[:end_date],
          activity_type: prize_obj[:prize_type],
          discount: prize_obj[:discount],
          denomination: prize_obj[:denomination]
      )
      user_join_activity(open_id, activity_id)

      res[:status] = ACTIVITY_CREATE_SUCC
      res[:code] = coupon
      res[:name] = prize_obj[:name]
      res[:start_date] = prize_obj[:start_date]
      res[:end_date] = prize_obj[:end_date]

    end

    res

  end

  private

  # Weixin
  def user_join_activity(open_id, activity_id)
    time = get_current_time
    Ih_nh_user_activity.create(
        open_id: open_id,
        activity_id: activity_id,
        status: 'activated',
        join_date: time,
        activated_date: time
    )
  end

  def send_first_time_subscribe_coupon(open_id)
    activity = Ih_nh_activities.find_by(ID: 1)
    coupon = generate_coupon(activity[:ID], open_id)
    Ih_nh_qrcode.create(
                    owner_id: open_id,
                    activity_id: activity[:ID],
                    code: coupon,
                    start_date: activity[:start_date],
                    end_date: activity[:end_date],
                    activity_type: activity[:activity_type],
                    discount: activity[:discount],
                    denomination: activity[:denomination]
    )
  end

  def generate_coupon(activity_id, index)
    created_time = get_current_time;
    Digest::MD5.hexdigest("NorthernHemisphere:#{activity_id}:#{created_time}:#{index}")
  end

  def get_current_time
    Time.now.strftime('%Y-%m-%d %H:%M:%S')
  end

  # Account
  def get_group(group_id)
    Ih_account_group.find(group_id)
  end

  def get_user(user_id)
    Ih_users.find(user_id)
  end

  def get_user_sale_records(user_id)
    Ih_account_money.where(user_id: user_id)
  end

  def get_account_field
    Ih_account_field.all
  end

  def get_account_field_detail
    Ih_account_field_detail.all
  end

  def get_group_users_detail_info(user_ids)
    users_arr = user_ids.split(',')
    user_detail_hash = Hash.new
    users_arr.each do |element|
      user_detail_hash[element] = get_user(element)
    end

    user_detail_hash
  end

  def get_group_users_records(user_ids)
    users_arr = user_ids.split(',')
    user_sale_records_hash = Hash.new
    users_arr.each do |element|
      user_sale_records_hash[element] = get_user_sale_records(element)
    end

    user_sale_records_hash
  end

  def write_exception_details_to_log(exception, request, request_parameters)
    puts exception.message
    @logger.error_details(exception.message, request, request_parameters, 'IhakulaStore')
  end

end
