!function(e){if("object"==typeof exports&&"undefined"!=typeof module)module.exports=e();else if("function"==typeof define&&define.amd)define([],e);else{var n;"undefined"!=typeof window?n=window:"undefined"!=typeof global?n=global:"undefined"!=typeof self&&(n=self),n.northernHemisphere=e()}}(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(_dereq_,module,exports){


//
// Generated on Tue Dec 16 2014 12:13:47 GMT+0100 (CET) by Charlie Robbins, Paolo Fragomeni & the Contributors (Using Codesurgeon).
// Version 1.2.6
//

(function (exports) {

/*
 * browser.js: Browser specific functionality for director.
 *
 * (C) 2011, Charlie Robbins, Paolo Fragomeni, & the Contributors.
 * MIT LICENSE
 *
 */

var dloc = document.location;

function dlocHashEmpty() {
  // Non-IE browsers return '' when the address bar shows '#'; Director's logic
  // assumes both mean empty.
  return dloc.hash === '' || dloc.hash === '#';
}

var listener = {
  mode: 'modern',
  hash: dloc.hash,
  history: false,

  check: function () {
    var h = dloc.hash;
    if (h != this.hash) {
      this.hash = h;
      this.onHashChanged();
    }
  },

  fire: function () {
    if (this.mode === 'modern') {
      this.history === true ? window.onpopstate() : window.onhashchange();
    }
    else {
      this.onHashChanged();
    }
  },

  init: function (fn, history) {
    var self = this;
    this.history = history;

    if (!Router.listeners) {
      Router.listeners = [];
    }

    function onchange(onChangeEvent) {
      for (var i = 0, l = Router.listeners.length; i < l; i++) {
        Router.listeners[i](onChangeEvent);
      }
    }

    //note IE8 is being counted as 'modern' because it has the hashchange event
    if ('onhashchange' in window && (document.documentMode === undefined
      || document.documentMode > 7)) {
      // At least for now HTML5 history is available for 'modern' browsers only
      if (this.history === true) {
        // There is an old bug in Chrome that causes onpopstate to fire even
        // upon initial page load. Since the handler is run manually in init(),
        // this would cause Chrome to run it twise. Currently the only
        // workaround seems to be to set the handler after the initial page load
        // http://code.google.com/p/chromium/issues/detail?id=63040
        setTimeout(function() {
          window.onpopstate = onchange;
        }, 500);
      }
      else {
        window.onhashchange = onchange;
      }
      this.mode = 'modern';
    }
    else {
      //
      // IE support, based on a concept by Erik Arvidson ...
      //
      var frame = document.createElement('iframe');
      frame.id = 'state-frame';
      frame.style.display = 'none';
      document.body.appendChild(frame);
      this.writeFrame('');

      if ('onpropertychange' in document && 'attachEvent' in document) {
        document.attachEvent('onpropertychange', function () {
          if (event.propertyName === 'location') {
            self.check();
          }
        });
      }

      window.setInterval(function () { self.check(); }, 50);

      this.onHashChanged = onchange;
      this.mode = 'legacy';
    }

    Router.listeners.push(fn);

    return this.mode;
  },

  destroy: function (fn) {
    if (!Router || !Router.listeners) {
      return;
    }

    var listeners = Router.listeners;

    for (var i = listeners.length - 1; i >= 0; i--) {
      if (listeners[i] === fn) {
        listeners.splice(i, 1);
      }
    }
  },

  setHash: function (s) {
    // Mozilla always adds an entry to the history
    if (this.mode === 'legacy') {
      this.writeFrame(s);
    }

    if (this.history === true) {
      window.history.pushState({}, document.title, s);
      // Fire an onpopstate event manually since pushing does not obviously
      // trigger the pop event.
      this.fire();
    } else {
      dloc.hash = (s[0] === '/') ? s : '/' + s;
    }
    return this;
  },

  writeFrame: function (s) {
    // IE support...
    var f = document.getElementById('state-frame');
    var d = f.contentDocument || f.contentWindow.document;
    d.open();
    d.write("<script>_hash = '" + s + "'; onload = parent.listener.syncHash;<script>");
    d.close();
  },

  syncHash: function () {
    // IE support...
    var s = this._hash;
    if (s != dloc.hash) {
      dloc.hash = s;
    }
    return this;
  },

  onHashChanged: function () {}
};

var Router = exports.Router = function (routes) {
  if (!(this instanceof Router)) return new Router(routes);

  this.params   = {};
  this.routes   = {};
  this.methods  = ['on', 'once', 'after', 'before'];
  this.scope    = [];
  this._methods = {};

  this._insert = this.insert;
  this.insert = this.insertEx;

  this.historySupport = (window.history != null ? window.history.pushState : null) != null

  this.configure();
  this.mount(routes || {});
};

Router.prototype.init = function (r) {
  var self = this
    , routeTo;
  this.handler = function(onChangeEvent) {
    var newURL = onChangeEvent && onChangeEvent.newURL || window.location.hash;
    var url = self.history === true ? self.getPath() : newURL.replace(/.*#/, '');
    self.dispatch('on', url.charAt(0) === '/' ? url : '/' + url);
  };

  listener.init(this.handler, this.history);

  if (this.history === false) {
    if (dlocHashEmpty() && r) {
      dloc.hash = r;
    } else if (!dlocHashEmpty()) {
      self.dispatch('on', '/' + dloc.hash.replace(/^(#\/|#|\/)/, ''));
    }
  }
  else {
    if (this.convert_hash_in_init) {
      // Use hash as route
      routeTo = dlocHashEmpty() && r ? r : !dlocHashEmpty() ? dloc.hash.replace(/^#/, '') : null;
      if (routeTo) {
        window.history.replaceState({}, document.title, routeTo);
      }
    }
    else {
      // Use canonical url
      routeTo = this.getPath();
    }

    // Router has been initialized, but due to the chrome bug it will not
    // yet actually route HTML5 history state changes. Thus, decide if should route.
    if (routeTo || this.run_in_init === true) {
      this.handler();
    }
  }

  return this;
};

Router.prototype.explode = function () {
  var v = this.history === true ? this.getPath() : dloc.hash;
  if (v.charAt(1) === '/') { v=v.slice(1) }
  return v.slice(1, v.length).split("/");
};

Router.prototype.setRoute = function (i, v, val) {
  var url = this.explode();

  if (typeof i === 'number' && typeof v === 'string') {
    url[i] = v;
  }
  else if (typeof val === 'string') {
    url.splice(i, v, s);
  }
  else {
    url = [i];
  }

  listener.setHash(url.join('/'));
  return url;
};

//
// ### function insertEx(method, path, route, parent)
// #### @method {string} Method to insert the specific `route`.
// #### @path {Array} Parsed path to insert the `route` at.
// #### @route {Array|function} Route handlers to insert.
// #### @parent {Object} **Optional** Parent "routes" to insert into.
// insert a callback that will only occur once per the matched route.
//
Router.prototype.insertEx = function(method, path, route, parent) {
  if (method === "once") {
    method = "on";
    route = function(route) {
      var once = false;
      return function() {
        if (once) return;
        once = true;
        return route.apply(this, arguments);
      };
    }(route);
  }
  return this._insert(method, path, route, parent);
};

Router.prototype.getRoute = function (v) {
  var ret = v;

  if (typeof v === "number") {
    ret = this.explode()[v];
  }
  else if (typeof v === "string"){
    var h = this.explode();
    ret = h.indexOf(v);
  }
  else {
    ret = this.explode();
  }

  return ret;
};

Router.prototype.destroy = function () {
  listener.destroy(this.handler);
  return this;
};

Router.prototype.getPath = function () {
  var path = window.location.pathname;
  if (path.substr(0, 1) !== '/') {
    path = '/' + path;
  }
  return path;
};
function _every(arr, iterator) {
  for (var i = 0; i < arr.length; i += 1) {
    if (iterator(arr[i], i, arr) === false) {
      return;
    }
  }
}

function _flatten(arr) {
  var flat = [];
  for (var i = 0, n = arr.length; i < n; i++) {
    flat = flat.concat(arr[i]);
  }
  return flat;
}

function _asyncEverySeries(arr, iterator, callback) {
  if (!arr.length) {
    return callback();
  }
  var completed = 0;
  (function iterate() {
    iterator(arr[completed], function(err) {
      if (err || err === false) {
        callback(err);
        callback = function() {};
      } else {
        completed += 1;
        if (completed === arr.length) {
          callback();
        } else {
          iterate();
        }
      }
    });
  })();
}

function paramifyString(str, params, mod) {
  mod = str;
  for (var param in params) {
    if (params.hasOwnProperty(param)) {
      mod = params[param](str);
      if (mod !== str) {
        break;
      }
    }
  }
  return mod === str ? "([._a-zA-Z0-9-%()]+)" : mod;
}

function regifyString(str, params) {
  var matches, last = 0, out = "";
  while (matches = str.substr(last).match(/[^\w\d\- %@&]*\*[^\w\d\- %@&]*/)) {
    last = matches.index + matches[0].length;
    matches[0] = matches[0].replace(/^\*/, "([_.()!\\ %@&a-zA-Z0-9-]+)");
    out += str.substr(0, matches.index) + matches[0];
  }
  str = out += str.substr(last);
  var captures = str.match(/:([^\/]+)/ig), capture, length;
  if (captures) {
    length = captures.length;
    for (var i = 0; i < length; i++) {
      capture = captures[i];
      if (capture.slice(0, 2) === "::") {
        str = capture.slice(1);
      } else {
        str = str.replace(capture, paramifyString(capture, params));
      }
    }
  }
  return str;
}

function terminator(routes, delimiter, start, stop) {
  var last = 0, left = 0, right = 0, start = (start || "(").toString(), stop = (stop || ")").toString(), i;
  for (i = 0; i < routes.length; i++) {
    var chunk = routes[i];
    if (chunk.indexOf(start, last) > chunk.indexOf(stop, last) || ~chunk.indexOf(start, last) && !~chunk.indexOf(stop, last) || !~chunk.indexOf(start, last) && ~chunk.indexOf(stop, last)) {
      left = chunk.indexOf(start, last);
      right = chunk.indexOf(stop, last);
      if (~left && !~right || !~left && ~right) {
        var tmp = routes.slice(0, (i || 1) + 1).join(delimiter);
        routes = [ tmp ].concat(routes.slice((i || 1) + 1));
      }
      last = (right > left ? right : left) + 1;
      i = 0;
    } else {
      last = 0;
    }
  }
  return routes;
}

var QUERY_SEPARATOR = /\?.*/;

Router.prototype.configure = function(options) {
  options = options || {};
  for (var i = 0; i < this.methods.length; i++) {
    this._methods[this.methods[i]] = true;
  }
  this.recurse = options.recurse || this.recurse || false;
  this.async = options.async || false;
  this.delimiter = options.delimiter || "/";
  this.strict = typeof options.strict === "undefined" ? true : options.strict;
  this.notfound = options.notfound;
  this.resource = options.resource;
  this.history = options.html5history && this.historySupport || false;
  this.run_in_init = this.history === true && options.run_handler_in_init !== false;
  this.convert_hash_in_init = this.history === true && options.convert_hash_in_init !== false;
  this.every = {
    after: options.after || null,
    before: options.before || null,
    on: options.on || null
  };
  return this;
};

Router.prototype.param = function(token, matcher) {
  if (token[0] !== ":") {
    token = ":" + token;
  }
  var compiled = new RegExp(token, "g");
  this.params[token] = function(str) {
    return str.replace(compiled, matcher.source || matcher);
  };
  return this;
};

Router.prototype.on = Router.prototype.route = function(method, path, route) {
  var self = this;
  if (!route && typeof path == "function") {
    route = path;
    path = method;
    method = "on";
  }
  if (Array.isArray(path)) {
    return path.forEach(function(p) {
      self.on(method, p, route);
    });
  }
  if (path.source) {
    path = path.source.replace(/\\\//ig, "/");
  }
  if (Array.isArray(method)) {
    return method.forEach(function(m) {
      self.on(m.toLowerCase(), path, route);
    });
  }
  path = path.split(new RegExp(this.delimiter));
  path = terminator(path, this.delimiter);
  this.insert(method, this.scope.concat(path), route);
};

Router.prototype.path = function(path, routesFn) {
  var self = this, length = this.scope.length;
  if (path.source) {
    path = path.source.replace(/\\\//ig, "/");
  }
  path = path.split(new RegExp(this.delimiter));
  path = terminator(path, this.delimiter);
  this.scope = this.scope.concat(path);
  routesFn.call(this, this);
  this.scope.splice(length, path.length);
};

Router.prototype.dispatch = function(method, path, callback) {
  var self = this, fns = this.traverse(method, path.replace(QUERY_SEPARATOR, ""), this.routes, ""), invoked = this._invoked, after;
  this._invoked = true;
  if (!fns || fns.length === 0) {
    this.last = [];
    if (typeof this.notfound === "function") {
      this.invoke([ this.notfound ], {
        method: method,
        path: path
      }, callback);
    }
    return false;
  }
  if (this.recurse === "forward") {
    fns = fns.reverse();
  }
  function updateAndInvoke() {
    self.last = fns.after;
    self.invoke(self.runlist(fns), self, callback);
  }
  after = this.every && this.every.after ? [ this.every.after ].concat(this.last) : [ this.last ];
  if (after && after.length > 0 && invoked) {
    if (this.async) {
      this.invoke(after, this, updateAndInvoke);
    } else {
      this.invoke(after, this);
      updateAndInvoke();
    }
    return true;
  }
  updateAndInvoke();
  return true;
};

Router.prototype.invoke = function(fns, thisArg, callback) {
  var self = this;
  var apply;
  if (this.async) {
    apply = function(fn, next) {
      if (Array.isArray(fn)) {
        return _asyncEverySeries(fn, apply, next);
      } else if (typeof fn == "function") {
        fn.apply(thisArg, (fns.captures || []).concat(next));
      }
    };
    _asyncEverySeries(fns, apply, function() {
      if (callback) {
        callback.apply(thisArg, arguments);
      }
    });
  } else {
    apply = function(fn) {
      if (Array.isArray(fn)) {
        return _every(fn, apply);
      } else if (typeof fn === "function") {
        return fn.apply(thisArg, fns.captures || []);
      } else if (typeof fn === "string" && self.resource) {
        self.resource[fn].apply(thisArg, fns.captures || []);
      }
    };
    _every(fns, apply);
  }
};

Router.prototype.traverse = function(method, path, routes, regexp, filter) {
  var fns = [], current, exact, match, next, that;
  function filterRoutes(routes) {
    if (!filter) {
      return routes;
    }
    function deepCopy(source) {
      var result = [];
      for (var i = 0; i < source.length; i++) {
        result[i] = Array.isArray(source[i]) ? deepCopy(source[i]) : source[i];
      }
      return result;
    }
    function applyFilter(fns) {
      for (var i = fns.length - 1; i >= 0; i--) {
        if (Array.isArray(fns[i])) {
          applyFilter(fns[i]);
          if (fns[i].length === 0) {
            fns.splice(i, 1);
          }
        } else {
          if (!filter(fns[i])) {
            fns.splice(i, 1);
          }
        }
      }
    }
    var newRoutes = deepCopy(routes);
    newRoutes.matched = routes.matched;
    newRoutes.captures = routes.captures;
    newRoutes.after = routes.after.filter(filter);
    applyFilter(newRoutes);
    return newRoutes;
  }
  if (path === this.delimiter && routes[method]) {
    next = [ [ routes.before, routes[method] ].filter(Boolean) ];
    next.after = [ routes.after ].filter(Boolean);
    next.matched = true;
    next.captures = [];
    return filterRoutes(next);
  }
  for (var r in routes) {
    if (routes.hasOwnProperty(r) && (!this._methods[r] || this._methods[r] && typeof routes[r] === "object" && !Array.isArray(routes[r]))) {
      current = exact = regexp + this.delimiter + r;
      if (!this.strict) {
        exact += "[" + this.delimiter + "]?";
      }
      match = path.match(new RegExp("^" + exact));
      if (!match) {
        continue;
      }
      if (match[0] && match[0] == path && routes[r][method]) {
        next = [ [ routes[r].before, routes[r][method] ].filter(Boolean) ];
        next.after = [ routes[r].after ].filter(Boolean);
        next.matched = true;
        next.captures = match.slice(1);
        if (this.recurse && routes === this.routes) {
          next.push([ routes.before, routes.on ].filter(Boolean));
          next.after = next.after.concat([ routes.after ].filter(Boolean));
        }
        return filterRoutes(next);
      }
      next = this.traverse(method, path, routes[r], current);
      if (next.matched) {
        if (next.length > 0) {
          fns = fns.concat(next);
        }
        if (this.recurse) {
          fns.push([ routes[r].before, routes[r].on ].filter(Boolean));
          next.after = next.after.concat([ routes[r].after ].filter(Boolean));
          if (routes === this.routes) {
            fns.push([ routes["before"], routes["on"] ].filter(Boolean));
            next.after = next.after.concat([ routes["after"] ].filter(Boolean));
          }
        }
        fns.matched = true;
        fns.captures = next.captures;
        fns.after = next.after;
        return filterRoutes(fns);
      }
    }
  }
  return false;
};

Router.prototype.insert = function(method, path, route, parent) {
  var methodType, parentType, isArray, nested, part;
  path = path.filter(function(p) {
    return p && p.length > 0;
  });
  parent = parent || this.routes;
  part = path.shift();
  if (/\:|\*/.test(part) && !/\\d|\\w/.test(part)) {
    part = regifyString(part, this.params);
  }
  if (path.length > 0) {
    parent[part] = parent[part] || {};
    return this.insert(method, path, route, parent[part]);
  }
  if (!part && !path.length && parent === this.routes) {
    methodType = typeof parent[method];
    switch (methodType) {
     case "function":
      parent[method] = [ parent[method], route ];
      return;
     case "object":
      parent[method].push(route);
      return;
     case "undefined":
      parent[method] = route;
      return;
    }
    return;
  }
  parentType = typeof parent[part];
  isArray = Array.isArray(parent[part]);
  if (parent[part] && !isArray && parentType == "object") {
    methodType = typeof parent[part][method];
    switch (methodType) {
     case "function":
      parent[part][method] = [ parent[part][method], route ];
      return;
     case "object":
      parent[part][method].push(route);
      return;
     case "undefined":
      parent[part][method] = route;
      return;
    }
  } else if (parentType == "undefined") {
    nested = {};
    nested[method] = route;
    parent[part] = nested;
    return;
  }
  throw new Error("Invalid route context: " + parentType);
};



Router.prototype.extend = function(methods) {
  var self = this, len = methods.length, i;
  function extend(method) {
    self._methods[method] = true;
    self[method] = function() {
      var extra = arguments.length === 1 ? [ method, "" ] : [ method ];
      self.on.apply(self, extra.concat(Array.prototype.slice.call(arguments)));
    };
  }
  for (i = 0; i < len; i++) {
    extend(methods[i]);
  }
};

Router.prototype.runlist = function(fns) {
  var runlist = this.every && this.every.before ? [ this.every.before ].concat(_flatten(fns)) : _flatten(fns);
  if (this.every && this.every.on) {
    runlist.push(this.every.on);
  }
  runlist.captures = fns.captures;
  runlist.source = fns.source;
  return runlist;
};

Router.prototype.mount = function(routes, path) {
  if (!routes || typeof routes !== "object" || Array.isArray(routes)) {
    return;
  }
  var self = this;
  path = path || [];
  if (!Array.isArray(path)) {
    path = path.split(self.delimiter);
  }
  function insertOrMount(route, local) {
    var rename = route, parts = route.split(self.delimiter), routeType = typeof routes[route], isRoute = parts[0] === "" || !self._methods[parts[0]], event = isRoute ? "on" : rename;
    if (isRoute) {
      rename = rename.slice((rename.match(new RegExp("^" + self.delimiter)) || [ "" ])[0].length);
      parts.shift();
    }
    if (isRoute && routeType === "object" && !Array.isArray(routes[route])) {
      local = local.concat(parts);
      self.mount(routes[route], local);
      return;
    }
    if (isRoute) {
      local = local.concat(rename.split(self.delimiter));
      local = terminator(local, self.delimiter);
    }
    self.insert(event, local, routes[route]);
  }
  for (var route in routes) {
    if (routes.hasOwnProperty(route)) {
      insertOrMount(route, path.slice(0));
    }
  }
};



}(typeof exports === "object" ? exports : window));
},{}],2:[function(_dereq_,module,exports){
/*!
  * domready (c) Dustin Diaz 2014 - License MIT
  */
!function (name, definition) {

  if (typeof module != 'undefined') module.exports = definition()
  else if (typeof define == 'function' && typeof define.amd == 'object') define(definition)
  else this[name] = definition()

}('domready', function () {

  var fns = [], listener
    , doc = document
    , hack = doc.documentElement.doScroll
    , domContentLoaded = 'DOMContentLoaded'
    , loaded = (hack ? /^loaded|^c/ : /^loaded|^i|^c/).test(doc.readyState)


  if (!loaded)
  doc.addEventListener(domContentLoaded, listener = function () {
    doc.removeEventListener(domContentLoaded, listener)
    loaded = 1
    while (listener = fns.shift()) listener()
  })

  return function (fn) {
    loaded ? setTimeout(fn, 0) : fns.push(fn)
  }

});

},{}],3:[function(_dereq_,module,exports){
//---------------------------------------------------------------------
//
// QR Code Generator for JavaScript
//
// Copyright (c) 2009 Kazuhiko Arase
//
// URL: http://www.d-project.com/
//
// Licensed under the MIT license:
//	http://www.opensource.org/licenses/mit-license.php
//
// The word 'QR Code' is registered trademark of
// DENSO WAVE INCORPORATED
//	http://www.denso-wave.com/qrcode/faqpatent-e.html
//
//---------------------------------------------------------------------

exports.qrcode = function() {

	//---------------------------------------------------------------------
	// qrcode
	//---------------------------------------------------------------------

	/**
	 * qrcode
	 * @param typeNumber 1 to 10
	 * @param errorCorrectLevel 'L','M','Q','H'
	 */
	var qrcode = function(typeNumber, errorCorrectLevel) {

		var PAD0 = 0xEC;
		var PAD1 = 0x11;

		var _typeNumber = typeNumber;
		var _errorCorrectLevel = QRErrorCorrectLevel[errorCorrectLevel];
		var _modules = null;
		var _moduleCount = 0;
		var _dataCache = null;
		var _dataList = new Array();

		var _this = {};

		var makeImpl = function(test, maskPattern) {

			_moduleCount = _typeNumber * 4 + 17;
			_modules = function(moduleCount) {
				var modules = new Array(moduleCount);
				for (var row = 0; row < moduleCount; row += 1) {
					modules[row] = new Array(moduleCount);
					for (var col = 0; col < moduleCount; col += 1) {
						modules[row][col] = null;
					}
				}
				return modules;
			}(_moduleCount);

			setupPositionProbePattern(0, 0);
			setupPositionProbePattern(_moduleCount - 7, 0);
			setupPositionProbePattern(0, _moduleCount - 7);
			setupPositionAdjustPattern();
			setupTimingPattern();
			setupTypeInfo(test, maskPattern);

			if (_typeNumber >= 7) {
				setupTypeNumber(test);
			}

			if (_dataCache == null) {
				_dataCache = createData(_typeNumber, _errorCorrectLevel, _dataList);
			}

			mapData(_dataCache, maskPattern);
		};

		var setupPositionProbePattern = function(row, col) {

			for (var r = -1; r <= 7; r += 1) {

				if (row + r <= -1 || _moduleCount <= row + r) continue;

				for (var c = -1; c <= 7; c += 1) {

					if (col + c <= -1 || _moduleCount <= col + c) continue;

					if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
							|| (0 <= c && c <= 6 && (r == 0 || r == 6) )
							|| (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
						_modules[row + r][col + c] = true;
					} else {
						_modules[row + r][col + c] = false;
					}
				}
			}
		};

		var getBestMaskPattern = function() {

			var minLostPoint = 0;
			var pattern = 0;

			for (var i = 0; i < 8; i += 1) {

				makeImpl(true, i);

				var lostPoint = QRUtil.getLostPoint(_this);

				if (i == 0 || minLostPoint > lostPoint) {
					minLostPoint = lostPoint;
					pattern = i;
				}
			}

			return pattern;
		};

		var setupTimingPattern = function() {

			for (var r = 8; r < _moduleCount - 8; r += 1) {
				if (_modules[r][6] != null) {
					continue;
				}
				_modules[r][6] = (r % 2 == 0);
			}

			for (var c = 8; c < _moduleCount - 8; c += 1) {
				if (_modules[6][c] != null) {
					continue;
				}
				_modules[6][c] = (c % 2 == 0);
			}
		};

		var setupPositionAdjustPattern = function() {

			var pos = QRUtil.getPatternPosition(_typeNumber);

			for (var i = 0; i < pos.length; i += 1) {

				for (var j = 0; j < pos.length; j += 1) {

					var row = pos[i];
					var col = pos[j];

					if (_modules[row][col] != null) {
						continue;
					}

					for (var r = -2; r <= 2; r += 1) {

						for (var c = -2; c <= 2; c += 1) {

							if (r == -2 || r == 2 || c == -2 || c == 2
									|| (r == 0 && c == 0) ) {
								_modules[row + r][col + c] = true;
							} else {
								_modules[row + r][col + c] = false;
							}
						}
					}
				}
			}
		};

		var setupTypeNumber = function(test) {

			var bits = QRUtil.getBCHTypeNumber(_typeNumber);

			for (var i = 0; i < 18; i += 1) {
				var mod = (!test && ( (bits >> i) & 1) == 1);
				_modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
			}

			for (var i = 0; i < 18; i += 1) {
				var mod = (!test && ( (bits >> i) & 1) == 1);
				_modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
			}
		};

		var setupTypeInfo = function(test, maskPattern) {

			var data = (_errorCorrectLevel << 3) | maskPattern;
			var bits = QRUtil.getBCHTypeInfo(data);

			// vertical
			for (var i = 0; i < 15; i += 1) {

				var mod = (!test && ( (bits >> i) & 1) == 1);

				if (i < 6) {
					_modules[i][8] = mod;
				} else if (i < 8) {
					_modules[i + 1][8] = mod;
				} else {
					_modules[_moduleCount - 15 + i][8] = mod;
				}
			}

			// horizontal
			for (var i = 0; i < 15; i += 1) {

				var mod = (!test && ( (bits >> i) & 1) == 1);

				if (i < 8) {
					_modules[8][_moduleCount - i - 1] = mod;
				} else if (i < 9) {
					_modules[8][15 - i - 1 + 1] = mod;
				} else {
					_modules[8][15 - i - 1] = mod;
				}
			}

			// fixed module
			_modules[_moduleCount - 8][8] = (!test);
		};

		var mapData = function(data, maskPattern) {

			var inc = -1;
			var row = _moduleCount - 1;
			var bitIndex = 7;
			var byteIndex = 0;
			var maskFunc = QRUtil.getMaskFunction(maskPattern);

			for (var col = _moduleCount - 1; col > 0; col -= 2) {

				if (col == 6) col -= 1;

				while (true) {

					for (var c = 0; c < 2; c += 1) {

						if (_modules[row][col - c] == null) {

							var dark = false;

							if (byteIndex < data.length) {
								dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
							}

							var mask = maskFunc(row, col - c);

							if (mask) {
								dark = !dark;
							}

							_modules[row][col - c] = dark;
							bitIndex -= 1;

							if (bitIndex == -1) {
								byteIndex += 1;
								bitIndex = 7;
							}
						}
					}

					row += inc;

					if (row < 0 || _moduleCount <= row) {
						row -= inc;
						inc = -inc;
						break;
					}
				}
			}
		};

		var createBytes = function(buffer, rsBlocks) {

			var offset = 0;

			var maxDcCount = 0;
			var maxEcCount = 0;

			var dcdata = new Array(rsBlocks.length);
			var ecdata = new Array(rsBlocks.length);

			for (var r = 0; r < rsBlocks.length; r += 1) {

				var dcCount = rsBlocks[r].dataCount;
				var ecCount = rsBlocks[r].totalCount - dcCount;

				maxDcCount = Math.max(maxDcCount, dcCount);
				maxEcCount = Math.max(maxEcCount, ecCount);

				dcdata[r] = new Array(dcCount);

				for (var i = 0; i < dcdata[r].length; i += 1) {
					dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
				}
				offset += dcCount;

				var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
				var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);

				var modPoly = rawPoly.mod(rsPoly);
				ecdata[r] = new Array(rsPoly.getLength() - 1);
				for (var i = 0; i < ecdata[r].length; i += 1) {
					var modIndex = i + modPoly.getLength() - ecdata[r].length;
					ecdata[r][i] = (modIndex >= 0)? modPoly.get(modIndex) : 0;
				}
			}

			var totalCodeCount = 0;
			for (var i = 0; i < rsBlocks.length; i += 1) {
				totalCodeCount += rsBlocks[i].totalCount;
			}

			var data = new Array(totalCodeCount);
			var index = 0;

			for (var i = 0; i < maxDcCount; i += 1) {
				for (var r = 0; r < rsBlocks.length; r += 1) {
					if (i < dcdata[r].length) {
						data[index] = dcdata[r][i];
						index += 1;
					}
				}
			}

			for (var i = 0; i < maxEcCount; i += 1) {
				for (var r = 0; r < rsBlocks.length; r += 1) {
					if (i < ecdata[r].length) {
						data[index] = ecdata[r][i];
						index += 1;
					}
				}
			}

			return data;
		};

		var createData = function(typeNumber, errorCorrectLevel, dataList) {

			var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectLevel);

			var buffer = qrBitBuffer();

			for (var i = 0; i < dataList.length; i += 1) {
				var data = dataList[i];
				buffer.put(data.getMode(), 4);
				buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
				data.write(buffer);
			}

			// calc num max data.
			var totalDataCount = 0;
			for (var i = 0; i < rsBlocks.length; i += 1) {
				totalDataCount += rsBlocks[i].dataCount;
			}

			if (buffer.getLengthInBits() > totalDataCount * 8) {
				throw new Error('code length overflow. ('
					+ buffer.getLengthInBits()
					+ '>'
					+ totalDataCount * 8
					+ ')');
			}

			// end code
			if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
				buffer.put(0, 4);
			}

			// padding
			while (buffer.getLengthInBits() % 8 != 0) {
				buffer.putBit(false);
			}

			// padding
			while (true) {

				if (buffer.getLengthInBits() >= totalDataCount * 8) {
					break;
				}
				buffer.put(PAD0, 8);

				if (buffer.getLengthInBits() >= totalDataCount * 8) {
					break;
				}
				buffer.put(PAD1, 8);
			}

			return createBytes(buffer, rsBlocks);
		};

		_this.addData = function(data) {
			var newData = qr8BitByte(data);
			_dataList.push(newData);
			_dataCache = null;
		};

		_this.isDark = function(row, col) {
			if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
				throw new Error(row + ',' + col);
			}
			return _modules[row][col];
		};

		_this.getModuleCount = function() {
			return _moduleCount;
		};

		_this.make = function() {
			makeImpl(false, getBestMaskPattern() );
		};

		_this.createTableTag = function(cellSize, margin) {

			cellSize = cellSize || 2;
			margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

			var qrHtml = '';

			qrHtml += '<table style="';
			qrHtml += ' border-width: 0px; border-style: none;';
			qrHtml += ' border-collapse: collapse;';
			qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
			qrHtml += '">';
			qrHtml += '<tbody>';

			for (var r = 0; r < _this.getModuleCount(); r += 1) {

				qrHtml += '<tr>';

				for (var c = 0; c < _this.getModuleCount(); c += 1) {
					qrHtml += '<td style="';
					qrHtml += ' border-width: 0px; border-style: none;';
					qrHtml += ' border-collapse: collapse;';
					qrHtml += ' padding: 0px; margin: 0px;';
					qrHtml += ' width: ' + cellSize + 'px;';
					qrHtml += ' height: ' + cellSize + 'px;';
					qrHtml += ' background-color: ';
					qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
					qrHtml += ';';
					qrHtml += '"/>';
				}

				qrHtml += '</tr>';
			}

			qrHtml += '</tbody>';
			qrHtml += '</table>';

			return qrHtml;
		};

		_this.createImgTag = function(cellSize, margin) {

			cellSize = cellSize || 2;
			margin = (typeof margin == 'undefined')? cellSize * 4 : margin;

			var size = _this.getModuleCount() * cellSize + margin * 2;
			var min = margin;
			var max = size - margin;

			return createImgTag(size, size, function(x, y) {
				if (min <= x && x < max && min <= y && y < max) {
					var c = Math.floor( (x - min) / cellSize);
					var r = Math.floor( (y - min) / cellSize);
					return _this.isDark(r, c)? 0 : 1;
				} else {
					return 1;
				}
			} );
		};

		return _this;
	};

	//---------------------------------------------------------------------
	// qrcode.stringToBytes
	//---------------------------------------------------------------------

	qrcode.stringToBytes = function(s) {
		var bytes = new Array();
		for (var i = 0; i < s.length; i += 1) {
			var c = s.charCodeAt(i);
			bytes.push(c & 0xff);
		}
		return bytes;
	};

	//---------------------------------------------------------------------
	// qrcode.createStringToBytes
	//---------------------------------------------------------------------

	/**
	 * @param unicodeData base64 string of byte array.
	 * [16bit Unicode],[16bit Bytes], ...
	 * @param numChars
	 */
	qrcode.createStringToBytes = function(unicodeData, numChars) {

		// create conversion map.

		var unicodeMap = function() {

			var bin = base64DecodeInputStream(unicodeData);
			var read = function() {
				var b = bin.read();
				if (b == -1) throw new Error();
				return b;
			};

			var count = 0;
			var unicodeMap = {};
			while (true) {
				var b0 = bin.read();
				if (b0 == -1) break;
				var b1 = read();
				var b2 = read();
				var b3 = read();
				var k = String.fromCharCode( (b0 << 8) | b1);
				var v = (b2 << 8) | b3;
				unicodeMap[k] = v;
				count += 1;
			}
			if (count != numChars) {
				throw new Error(count + ' != ' + numChars);
			}

			return unicodeMap;
		}();

		var unknownChar = '?'.charCodeAt(0);

		return function(s) {
			var bytes = new Array();
			for (var i = 0; i < s.length; i += 1) {
				var c = s.charCodeAt(i);
				if (c < 128) {
					bytes.push(c);
				} else {
					var b = unicodeMap[s.charAt(i)];
					if (typeof b == 'number') {
						if ( (b & 0xff) == b) {
							// 1byte
							bytes.push(b);
						} else {
							// 2bytes
							bytes.push(b >>> 8);
							bytes.push(b & 0xff);
						}
					} else {
						bytes.push(unknownChar);
					}
				}
			}
			return bytes;
		};
	};

	//---------------------------------------------------------------------
	// QRMode
	//---------------------------------------------------------------------

	var QRMode = {
		MODE_NUMBER :		1 << 0,
		MODE_ALPHA_NUM : 	1 << 1,
		MODE_8BIT_BYTE : 	1 << 2,
		MODE_KANJI :		1 << 3
	};

	//---------------------------------------------------------------------
	// QRErrorCorrectLevel
	//---------------------------------------------------------------------

	var QRErrorCorrectLevel = {
		L : 1,
		M : 0,
		Q : 3,
		H : 2
	};

	//---------------------------------------------------------------------
	// QRMaskPattern
	//---------------------------------------------------------------------

	var QRMaskPattern = {
		PATTERN000 : 0,
		PATTERN001 : 1,
		PATTERN010 : 2,
		PATTERN011 : 3,
		PATTERN100 : 4,
		PATTERN101 : 5,
		PATTERN110 : 6,
		PATTERN111 : 7
	};

	//---------------------------------------------------------------------
	// QRUtil
	//---------------------------------------------------------------------

	var QRUtil = function() {

		var PATTERN_POSITION_TABLE = [
			[],
			[6, 18],
			[6, 22],
			[6, 26],
			[6, 30],
			[6, 34],
			[6, 22, 38],
			[6, 24, 42],
			[6, 26, 46],
			[6, 28, 50],
			[6, 30, 54],
			[6, 32, 58],
			[6, 34, 62],
			[6, 26, 46, 66],
			[6, 26, 48, 70],
			[6, 26, 50, 74],
			[6, 30, 54, 78],
			[6, 30, 56, 82],
			[6, 30, 58, 86],
			[6, 34, 62, 90],
			[6, 28, 50, 72, 94],
			[6, 26, 50, 74, 98],
			[6, 30, 54, 78, 102],
			[6, 28, 54, 80, 106],
			[6, 32, 58, 84, 110],
			[6, 30, 58, 86, 114],
			[6, 34, 62, 90, 118],
			[6, 26, 50, 74, 98, 122],
			[6, 30, 54, 78, 102, 126],
			[6, 26, 52, 78, 104, 130],
			[6, 30, 56, 82, 108, 134],
			[6, 34, 60, 86, 112, 138],
			[6, 30, 58, 86, 114, 142],
			[6, 34, 62, 90, 118, 146],
			[6, 30, 54, 78, 102, 126, 150],
			[6, 24, 50, 76, 102, 128, 154],
			[6, 28, 54, 80, 106, 132, 158],
			[6, 32, 58, 84, 110, 136, 162],
			[6, 26, 54, 82, 110, 138, 166],
			[6, 30, 58, 86, 114, 142, 170]
		];
		var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
		var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
		var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);

		var _this = {};

		var getBCHDigit = function(data) {
			var digit = 0;
			while (data != 0) {
				digit += 1;
				data >>>= 1;
			}
			return digit;
		};

		_this.getBCHTypeInfo = function(data) {
			var d = data << 10;
			while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
				d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
			}
			return ( (data << 10) | d) ^ G15_MASK;
		};

		_this.getBCHTypeNumber = function(data) {
			var d = data << 12;
			while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
				d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
			}
			return (data << 12) | d;
		};

		_this.getPatternPosition = function(typeNumber) {
			return PATTERN_POSITION_TABLE[typeNumber - 1];
		};

		_this.getMaskFunction = function(maskPattern) {

			switch (maskPattern) {

			case QRMaskPattern.PATTERN000 :
				return function(i, j) { return (i + j) % 2 == 0; };
			case QRMaskPattern.PATTERN001 :
				return function(i, j) { return i % 2 == 0; };
			case QRMaskPattern.PATTERN010 :
				return function(i, j) { return j % 3 == 0; };
			case QRMaskPattern.PATTERN011 :
				return function(i, j) { return (i + j) % 3 == 0; };
			case QRMaskPattern.PATTERN100 :
				return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
			case QRMaskPattern.PATTERN101 :
				return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
			case QRMaskPattern.PATTERN110 :
				return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
			case QRMaskPattern.PATTERN111 :
				return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };

			default :
				throw new Error('bad maskPattern:' + maskPattern);
			}
		};

		_this.getErrorCorrectPolynomial = function(errorCorrectLength) {
			var a = qrPolynomial([1], 0);
			for (var i = 0; i < errorCorrectLength; i += 1) {
				a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
			}
			return a;
		};

		_this.getLengthInBits = function(mode, type) {

			if (1 <= type && type < 10) {

				// 1 - 9

				switch(mode) {
				case QRMode.MODE_NUMBER 	: return 10;
				case QRMode.MODE_ALPHA_NUM 	: return 9;
				case QRMode.MODE_8BIT_BYTE	: return 8;
				case QRMode.MODE_KANJI		: return 8;
				default :
					throw new Error('mode:' + mode);
				}

			} else if (type < 27) {

				// 10 - 26

				switch(mode) {
				case QRMode.MODE_NUMBER 	: return 12;
				case QRMode.MODE_ALPHA_NUM 	: return 11;
				case QRMode.MODE_8BIT_BYTE	: return 16;
				case QRMode.MODE_KANJI		: return 10;
				default :
					throw new Error('mode:' + mode);
				}

			} else if (type < 41) {

				// 27 - 40

				switch(mode) {
				case QRMode.MODE_NUMBER 	: return 14;
				case QRMode.MODE_ALPHA_NUM	: return 13;
				case QRMode.MODE_8BIT_BYTE	: return 16;
				case QRMode.MODE_KANJI		: return 12;
				default :
					throw new Error('mode:' + mode);
				}

			} else {
				throw new Error('type:' + type);
			}
		};

		_this.getLostPoint = function(qrcode) {

			var moduleCount = qrcode.getModuleCount();

			var lostPoint = 0;

			// LEVEL1

			for (var row = 0; row < moduleCount; row += 1) {
				for (var col = 0; col < moduleCount; col += 1) {

					var sameCount = 0;
					var dark = qrcode.isDark(row, col);

					for (var r = -1; r <= 1; r += 1) {

						if (row + r < 0 || moduleCount <= row + r) {
							continue;
						}

						for (var c = -1; c <= 1; c += 1) {

							if (col + c < 0 || moduleCount <= col + c) {
								continue;
							}

							if (r == 0 && c == 0) {
								continue;
							}

							if (dark == qrcode.isDark(row + r, col + c) ) {
								sameCount += 1;
							}
						}
					}

					if (sameCount > 5) {
						lostPoint += (3 + sameCount - 5);
					}
				}
			};

			// LEVEL2

			for (var row = 0; row < moduleCount - 1; row += 1) {
				for (var col = 0; col < moduleCount - 1; col += 1) {
					var count = 0;
					if (qrcode.isDark(row, col) ) count += 1;
					if (qrcode.isDark(row + 1, col) ) count += 1;
					if (qrcode.isDark(row, col + 1) ) count += 1;
					if (qrcode.isDark(row + 1, col + 1) ) count += 1;
					if (count == 0 || count == 4) {
						lostPoint += 3;
					}
				}
			}

			// LEVEL3

			for (var row = 0; row < moduleCount; row += 1) {
				for (var col = 0; col < moduleCount - 6; col += 1) {
					if (qrcode.isDark(row, col)
							&& !qrcode.isDark(row, col + 1)
							&&  qrcode.isDark(row, col + 2)
							&&  qrcode.isDark(row, col + 3)
							&&  qrcode.isDark(row, col + 4)
							&& !qrcode.isDark(row, col + 5)
							&&  qrcode.isDark(row, col + 6) ) {
						lostPoint += 40;
					}
				}
			}

			for (var col = 0; col < moduleCount; col += 1) {
				for (var row = 0; row < moduleCount - 6; row += 1) {
					if (qrcode.isDark(row, col)
							&& !qrcode.isDark(row + 1, col)
							&&  qrcode.isDark(row + 2, col)
							&&  qrcode.isDark(row + 3, col)
							&&  qrcode.isDark(row + 4, col)
							&& !qrcode.isDark(row + 5, col)
							&&  qrcode.isDark(row + 6, col) ) {
						lostPoint += 40;
					}
				}
			}

			// LEVEL4

			var darkCount = 0;

			for (var col = 0; col < moduleCount; col += 1) {
				for (var row = 0; row < moduleCount; row += 1) {
					if (qrcode.isDark(row, col) ) {
						darkCount += 1;
					}
				}
			}

			var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
			lostPoint += ratio * 10;

			return lostPoint;
		};

		return _this;
	}();

	//---------------------------------------------------------------------
	// QRMath
	//---------------------------------------------------------------------

	var QRMath = function() {

		var EXP_TABLE = new Array(256);
		var LOG_TABLE = new Array(256);

		// initialize tables
		for (var i = 0; i < 8; i += 1) {
			EXP_TABLE[i] = 1 << i;
		}
		for (var i = 8; i < 256; i += 1) {
			EXP_TABLE[i] = EXP_TABLE[i - 4]
				^ EXP_TABLE[i - 5]
				^ EXP_TABLE[i - 6]
				^ EXP_TABLE[i - 8];
		}
		for (var i = 0; i < 255; i += 1) {
			LOG_TABLE[EXP_TABLE[i] ] = i;
		}

		var _this = {};

		_this.glog = function(n) {

			if (n < 1) {
				throw new Error('glog(' + n + ')');
			}

			return LOG_TABLE[n];
		};

		_this.gexp = function(n) {

			while (n < 0) {
				n += 255;
			}

			while (n >= 256) {
				n -= 255;
			}

			return EXP_TABLE[n];
		};

		return _this;
	}();

	//---------------------------------------------------------------------
	// qrPolynomial
	//---------------------------------------------------------------------

	function qrPolynomial(num, shift) {

		if (typeof num.length == 'undefined') {
			throw new Error(num.length + '/' + shift);
		}

		var _num = function() {
			var offset = 0;
			while (offset < num.length && num[offset] == 0) {
				offset += 1;
			}
			var _num = new Array(num.length - offset + shift);
			for (var i = 0; i < num.length - offset; i += 1) {
				_num[i] = num[i + offset];
			}
			return _num;
		}();

		var _this = {};

		_this.get = function(index) {
			return _num[index];
		};

		_this.getLength = function() {
			return _num.length;
		};

		_this.multiply = function(e) {

			var num = new Array(_this.getLength() + e.getLength() - 1);

			for (var i = 0; i < _this.getLength(); i += 1) {
				for (var j = 0; j < e.getLength(); j += 1) {
					num[i + j] ^= QRMath.gexp(QRMath.glog(_this.get(i) ) + QRMath.glog(e.get(j) ) );
				}
			}

			return qrPolynomial(num, 0);
		};

		_this.mod = function(e) {

			if (_this.getLength() - e.getLength() < 0) {
				return _this;
			}

			var ratio = QRMath.glog(_this.get(0) ) - QRMath.glog(e.get(0) );

			var num = new Array(_this.getLength() );
			for (var i = 0; i < _this.getLength(); i += 1) {
				num[i] = _this.get(i);
			}

			for (var i = 0; i < e.getLength(); i += 1) {
				num[i] ^= QRMath.gexp(QRMath.glog(e.get(i) ) + ratio);
			}

			// recursive call
			return qrPolynomial(num, 0).mod(e);
		};

		return _this;
	};

	//---------------------------------------------------------------------
	// QRRSBlock
	//---------------------------------------------------------------------

	var QRRSBlock = function() {

		var RS_BLOCK_TABLE = [

			// L
			// M
			// Q
			// H

			// 1
			[1, 26, 19],
			[1, 26, 16],
			[1, 26, 13],
			[1, 26, 9],

			// 2
			[1, 44, 34],
			[1, 44, 28],
			[1, 44, 22],
			[1, 44, 16],

			// 3
			[1, 70, 55],
			[1, 70, 44],
			[2, 35, 17],
			[2, 35, 13],

			// 4
			[1, 100, 80],
			[2, 50, 32],
			[2, 50, 24],
			[4, 25, 9],

			// 5
			[1, 134, 108],
			[2, 67, 43],
			[2, 33, 15, 2, 34, 16],
			[2, 33, 11, 2, 34, 12],

			// 6
			[2, 86, 68],
			[4, 43, 27],
			[4, 43, 19],
			[4, 43, 15],

			// 7
			[2, 98, 78],
			[4, 49, 31],
			[2, 32, 14, 4, 33, 15],
			[4, 39, 13, 1, 40, 14],

			// 8
			[2, 121, 97],
			[2, 60, 38, 2, 61, 39],
			[4, 40, 18, 2, 41, 19],
			[4, 40, 14, 2, 41, 15],

			// 9
			[2, 146, 116],
			[3, 58, 36, 2, 59, 37],
			[4, 36, 16, 4, 37, 17],
			[4, 36, 12, 4, 37, 13],

			// 10
			[2, 86, 68, 2, 87, 69],
			[4, 69, 43, 1, 70, 44],
			[6, 43, 19, 2, 44, 20],
			[6, 43, 15, 2, 44, 16]
		];

		var qrRSBlock = function(totalCount, dataCount) {
			var _this = {};
			_this.totalCount = totalCount;
			_this.dataCount = dataCount;
			return _this;
		};

		var _this = {};

		var getRsBlockTable = function(typeNumber, errorCorrectLevel) {

			switch(errorCorrectLevel) {
			case QRErrorCorrectLevel.L :
				return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
			case QRErrorCorrectLevel.M :
				return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
			case QRErrorCorrectLevel.Q :
				return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
			case QRErrorCorrectLevel.H :
				return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
			default :
				return undefined;
			}
		};

		_this.getRSBlocks = function(typeNumber, errorCorrectLevel) {

			var rsBlock = getRsBlockTable(typeNumber, errorCorrectLevel);

			if (typeof rsBlock == 'undefined') {
				throw new Error('bad rs block @ typeNumber:' + typeNumber +
						'/errorCorrectLevel:' + errorCorrectLevel);
			}

			var length = rsBlock.length / 3;

			var list = new Array();

			for (var i = 0; i < length; i += 1) {

				var count = rsBlock[i * 3 + 0];
				var totalCount = rsBlock[i * 3 + 1];
				var dataCount = rsBlock[i * 3 + 2];

				for (var j = 0; j < count; j += 1) {
					list.push(qrRSBlock(totalCount, dataCount) );
				}
			}

			return list;
		};

		return _this;
	}();

	//---------------------------------------------------------------------
	// qrBitBuffer
	//---------------------------------------------------------------------

	var qrBitBuffer = function() {

		var _buffer = new Array();
		var _length = 0;

		var _this = {};

		_this.getBuffer = function() {
			return _buffer;
		};

		_this.get = function(index) {
			var bufIndex = Math.floor(index / 8);
			return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
		};

		_this.put = function(num, length) {
			for (var i = 0; i < length; i += 1) {
				_this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
			}
		};

		_this.getLengthInBits = function() {
			return _length;
		};

		_this.putBit = function(bit) {

			var bufIndex = Math.floor(_length / 8);
			if (_buffer.length <= bufIndex) {
				_buffer.push(0);
			}

			if (bit) {
				_buffer[bufIndex] |= (0x80 >>> (_length % 8) );
			}

			_length += 1;
		};

		return _this;
	};

	//---------------------------------------------------------------------
	// qr8BitByte
	//---------------------------------------------------------------------

	var qr8BitByte = function(data) {

		var _mode = QRMode.MODE_8BIT_BYTE;
		var _data = data;
		var _bytes = qrcode.stringToBytes(data);

		var _this = {};

		_this.getMode = function() {
			return _mode;
		};

		_this.getLength = function(buffer) {
			return _bytes.length;
		};

		_this.write = function(buffer) {
			for (var i = 0; i < _bytes.length; i += 1) {
				buffer.put(_bytes[i], 8);
			}
		};

		return _this;
	};

	//=====================================================================
	// GIF Support etc.
	//

	//---------------------------------------------------------------------
	// byteArrayOutputStream
	//---------------------------------------------------------------------

	var byteArrayOutputStream = function() {

		var _bytes = new Array();

		var _this = {};

		_this.writeByte = function(b) {
			_bytes.push(b & 0xff);
		};

		_this.writeShort = function(i) {
			_this.writeByte(i);
			_this.writeByte(i >>> 8);
		};

		_this.writeBytes = function(b, off, len) {
			off = off || 0;
			len = len || b.length;
			for (var i = 0; i < len; i += 1) {
				_this.writeByte(b[i + off]);
			}
		};

		_this.writeString = function(s) {
			for (var i = 0; i < s.length; i += 1) {
				_this.writeByte(s.charCodeAt(i) );
			}
		};

		_this.toByteArray = function() {
			return _bytes;
		};

		_this.toString = function() {
			var s = '';
			s += '[';
			for (var i = 0; i < _bytes.length; i += 1) {
				if (i > 0) {
					s += ',';
				}
				s += _bytes[i];
			}
			s += ']';
			return s;
		};

		return _this;
	};

	//---------------------------------------------------------------------
	// base64EncodeOutputStream
	//---------------------------------------------------------------------

	var base64EncodeOutputStream = function() {

		var _buffer = 0;
		var _buflen = 0;
		var _length = 0;
		var _base64 = '';

		var _this = {};

		var writeEncoded = function(b) {
			_base64 += String.fromCharCode(encode(b & 0x3f) );
		};

		var encode = function(n) {
			if (n < 0) {
				// error.
			} else if (n < 26) {
				return 0x41 + n;
			} else if (n < 52) {
				return 0x61 + (n - 26);
			} else if (n < 62) {
				return 0x30 + (n - 52);
			} else if (n == 62) {
				return 0x2b;
			} else if (n == 63) {
				return 0x2f;
			}
			throw new Error('n:' + n);
		};

		_this.writeByte = function(n) {

			_buffer = (_buffer << 8) | (n & 0xff);
			_buflen += 8;
			_length += 1;

			while (_buflen >= 6) {
				writeEncoded(_buffer >>> (_buflen - 6) );
				_buflen -= 6;
			}
		};

		_this.flush = function() {

			if (_buflen > 0) {
				writeEncoded(_buffer << (6 - _buflen) );
				_buffer = 0;
				_buflen = 0;
			}

			if (_length % 3 != 0) {
				// padding
				var padlen = 3 - _length % 3;
				for (var i = 0; i < padlen; i += 1) {
					_base64 += '=';
				}
			}
		};

		_this.toString = function() {
			return _base64;
		};

		return _this;
	};

	//---------------------------------------------------------------------
	// base64DecodeInputStream
	//---------------------------------------------------------------------

	var base64DecodeInputStream = function(str) {

		var _str = str;
		var _pos = 0;
		var _buffer = 0;
		var _buflen = 0;

		var _this = {};

		_this.read = function() {

			while (_buflen < 8) {

				if (_pos >= _str.length) {
					if (_buflen == 0) {
						return -1;
					}
					throw new Error('unexpected end of file./' + _buflen);
				}

				var c = _str.charAt(_pos);
				_pos += 1;

				if (c == '=') {
					_buflen = 0;
					return -1;
				} else if (c.match(/^\s$/) ) {
					// ignore if whitespace.
					continue;
				}

				_buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
				_buflen += 6;
			}

			var n = (_buffer >>> (_buflen - 8) ) & 0xff;
			_buflen -= 8;
			return n;
		};

		var decode = function(c) {
			if (0x41 <= c && c <= 0x5a) {
				return c - 0x41;
			} else if (0x61 <= c && c <= 0x7a) {
				return c - 0x61 + 26;
			} else if (0x30 <= c && c <= 0x39) {
				return c - 0x30 + 52;
			} else if (c == 0x2b) {
				return 62;
			} else if (c == 0x2f) {
				return 63;
			} else {
				throw new Error('c:' + c);
			}
		};

		return _this;
	};

	//---------------------------------------------------------------------
	// gifImage (B/W)
	//---------------------------------------------------------------------

	var gifImage = function(width, height) {

		var _width = width;
		var _height = height;
		var _data = new Array(width * height);

		var _this = {};

		_this.setPixel = function(x, y, pixel) {
			_data[y * _width + x] = pixel;
		};

		_this.write = function(out) {

			//---------------------------------
			// GIF Signature

			out.writeString('GIF87a');

			//---------------------------------
			// Screen Descriptor

			out.writeShort(_width);
			out.writeShort(_height);

			out.writeByte(0x80); // 2bit
			out.writeByte(0);
			out.writeByte(0);

			//---------------------------------
			// Global Color Map

			// black
			out.writeByte(0x00);
			out.writeByte(0x00);
			out.writeByte(0x00);

			// white
			out.writeByte(0xff);
			out.writeByte(0xff);
			out.writeByte(0xff);

			//---------------------------------
			// Image Descriptor

			out.writeString(',');
			out.writeShort(0);
			out.writeShort(0);
			out.writeShort(_width);
			out.writeShort(_height);
			out.writeByte(0);

			//---------------------------------
			// Local Color Map

			//---------------------------------
			// Raster Data

			var lzwMinCodeSize = 2;
			var raster = getLZWRaster(lzwMinCodeSize);

			out.writeByte(lzwMinCodeSize);

			var offset = 0;

			while (raster.length - offset > 255) {
				out.writeByte(255);
				out.writeBytes(raster, offset, 255);
				offset += 255;
			}

			out.writeByte(raster.length - offset);
			out.writeBytes(raster, offset, raster.length - offset);
			out.writeByte(0x00);

			//---------------------------------
			// GIF Terminator
			out.writeString(';');
		};

		var bitOutputStream = function(out) {

			var _out = out;
			var _bitLength = 0;
			var _bitBuffer = 0;

			var _this = {};

			_this.write = function(data, length) {

				if ( (data >>> length) != 0) {
					throw new Error('length over');
				}

				while (_bitLength + length >= 8) {
					_out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
					length -= (8 - _bitLength);
					data >>>= (8 - _bitLength);
					_bitBuffer = 0;
					_bitLength = 0;
				}

				_bitBuffer = (data << _bitLength) | _bitBuffer;
				_bitLength = _bitLength + length;
			};

			_this.flush = function() {
				if (_bitLength > 0) {
					_out.writeByte(_bitBuffer);
				}
			};

			return _this;
		};

		var getLZWRaster = function(lzwMinCodeSize) {

			var clearCode = 1 << lzwMinCodeSize;
			var endCode = (1 << lzwMinCodeSize) + 1;
			var bitLength = lzwMinCodeSize + 1;

			// Setup LZWTable
			var table = lzwTable();

			for (var i = 0; i < clearCode; i += 1) {
				table.add(String.fromCharCode(i) );
			}
			table.add(String.fromCharCode(clearCode) );
			table.add(String.fromCharCode(endCode) );

			var byteOut = byteArrayOutputStream();
			var bitOut = bitOutputStream(byteOut);

			// clear code
			bitOut.write(clearCode, bitLength);

			var dataIndex = 0;

			var s = String.fromCharCode(_data[dataIndex]);
			dataIndex += 1;

			while (dataIndex < _data.length) {

				var c = String.fromCharCode(_data[dataIndex]);
				dataIndex += 1;

				if (table.contains(s + c) ) {

					s = s + c;

				} else {

					bitOut.write(table.indexOf(s), bitLength);

					if (table.size() < 0xfff) {

						if (table.size() == (1 << bitLength) ) {
							bitLength += 1;
						}

						table.add(s + c);
					}

					s = c;
				}
			}

			bitOut.write(table.indexOf(s), bitLength);

			// end code
			bitOut.write(endCode, bitLength);

			bitOut.flush();

			return byteOut.toByteArray();
		};

		var lzwTable = function() {

			var _map = {};
			var _size = 0;

			var _this = {};

			_this.add = function(key) {
				if (_this.contains(key) ) {
					throw new Error('dup key:' + key);
				}
				_map[key] = _size;
				_size += 1;
			};

			_this.size = function() {
				return _size;
			};

			_this.indexOf = function(key) {
				return _map[key];
			};

			_this.contains = function(key) {
				return typeof _map[key] != 'undefined';
			};

			return _this;
		};

		return _this;
	};

	var createImgTag = function(width, height, getPixel, alt) {

		var gif = gifImage(width, height);
		for (var y = 0; y < height; y += 1) {
			for (var x = 0; x < width; x += 1) {
				gif.setPixel(x, y, getPixel(x, y) );
			}
		}

		var b = byteArrayOutputStream();
		gif.write(b);

		var base64 = base64EncodeOutputStream();
		var bytes = b.toByteArray();
		for (var i = 0; i < bytes.length; i += 1) {
			base64.writeByte(bytes[i]);
		}
		base64.flush();

		var img = '';
		img += '<img';
		img += '\u0020src="';
		img += 'data:image/gif;base64,';
		img += base64;
		img += '"';
		img += '\u0020width="';
		img += width;
		img += '"';
		img += '\u0020height="';
		img += height;
		img += '"';
		if (alt) {
			img += '\u0020alt="';
			img += alt;
			img += '"';
		}
		img += '/>';

		return img;
	};

	//---------------------------------------------------------------------
	// returns qrcode function.

	return qrcode;
}();

},{}],4:[function(_dereq_,module,exports){
module.exports = (function ($) {
    "use strict";
    function getJsonWithPromise(url) {

        return $.getJSON(url);
    }

    function get(path) {
        return $.get(path);
    }

    function postWithPromise(url, data) {
        return $.post(url, data);
    }

    function post(path, data, success, error) {
        $.ajax({
            url: path,
            type: 'POST',
            data: data,
            success: success,
            error: error
        });
    }

    function put(path, data, success, error) {
        $.ajax(
            {
                url: path,
                type: 'PUT',
                data: data,
                success: success,
                error: error
            });
    }

    function putWithPromise(path, data) {
        return $.ajax({
            url: path,
            type: 'PUT',
            data: data,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json'
        });
    }

    function remove(path) {
        return $.ajax({
            url: path,
            type: 'DELETE'
        });
    }

    return {
        getJsonWithPromise: getJsonWithPromise,
        get: get,
        postWithPromise: postWithPromise,
        post: post,
        putWithPromise: putWithPromise,
        put: put,
        remove: remove
    };
})(jQuery);


},{}],5:[function(_dereq_,module,exports){
var director = _dereq_('director'),
    viewEngine = _dereq_('../infrastructure/view_engine');

var routes = {
    "/weixin/join/activity/:open_id/:activity_id": function (openId, activityId) {
        viewEngine.bindView("/join-activity", {
            openId: openId,
            activityId: activityId
        });
    }
};

module.exports = {

    configure: function () {
        var router = new director.Router(routes);

        router.init();
        return router;
    }
};
},{"../infrastructure/view_engine":6,"director":1}],6:[function(_dereq_,module,exports){
var viewResolver = _dereq_('./view_resolver'),
    viewModelResolver = _dereq_('./view_model_resolver');

function doBind(ViewModel, view, data) {
    'use strict';
    $(function () {
        ko.postbox.reset();
        var sfView = document.getElementById('sf-view');
        $(sfView).html(view);
        ko.cleanNode(sfView);
        ko.applyBindings(new ViewModel(data), sfView);
    });
}

function viewResolverComplete(routeName, view, data) {
    var viewModel = viewModelResolver.resolveViewModel(routeName);
    doBind(viewModel, view, data);
}

module.exports = {
    bindView: function (routeName, data) {

        return viewResolver.resolveView(routeName)
            .done(function (view) {
                viewResolverComplete(routeName, view, data);
            });
    }
};

},{"./view_model_resolver":7,"./view_resolver":8}],7:[function(_dereq_,module,exports){
//TODO Require this in the future

//var StaffingProxyViewModel = require('../view_models/staffing_proxy_view_model');
//var OpportunityDetailsModel = require('../view_models/opportunity_view_model');
//var OpportunityRoleViewModel = require('../view_models/opportunity_role_view_model');

//var viewModels = {
//    "/role": StaffingProxyViewModel,
//    "/opportunity-details": OpportunityDetailsModel,
//    "/opportunity-staffing": OpportunityRoleViewModel
//};
//
//module.exports = {
//    resolveViewModel: function (routeName) {
//        return viewModels[routeName];
//    }
//};
},{}],8:[function(_dereq_,module,exports){
var ajaxWrapper = _dereq_('../ajax_wrapper');

module.exports = (function () {
    'use strict';
    var viewBase = "/views/partials",
        viewBaseExtension = ".html",
        viewCache = {};

    return {
        resolveView: function (routeName) {
            var deferred = $.Deferred();

            if (viewCache.hasOwnProperty(routeName)) {
                var cachedView = viewCache[routeName];
                deferred.resolve($.parseHTML(cachedView));
            }
            else {
                ajaxWrapper.get(viewBase + routeName.toLowerCase() + viewBaseExtension)
                    .done(function (viewAsString) {
                        viewCache[routeName] = viewAsString;
                        deferred.resolve($.parseHTML(viewAsString));
                    })
                    .fail(function () {
                        deferred.reject('View not found at route');
                    });
            }
            return deferred.promise();
        }
    };
})();
},{"../ajax_wrapper":4}],9:[function(_dereq_,module,exports){
var domReady = _dereq_('domready'),
    routeConfig = _dereq_('./config/routes'),
    router;

module.exports.homePageViewModelFactory = _dereq_("./view_models/home_page_view_model_factory");
module.exports.activityPageViewModelFactory = _dereq_("./view_models/activity_page_view_model_factory");
module.exports.joinActivityPageViewModelFactory = _dereq_("./view_models/join_activity_page_view_model_factory");


domReady(function () {
    router = routeConfig.configure();
    module.exports.router = router;
});


},{"./config/routes":5,"./view_models/activity_page_view_model_factory":13,"./view_models/home_page_view_model_factory":15,"./view_models/join_activity_page_view_model_factory":17,"domready":2}],10:[function(_dereq_,module,exports){
var ajax = _dereq_('../ajax_wrapper');

module.exports = {

    getAllActivities: function () {
        var deferred = $.Deferred();

        ajax.getJsonWithPromise('/weixin/get/all/activities')
            .done(function (activities) {
                deferred.resolve(activities);
            });
        return deferred.promise();
    }
};
},{"../ajax_wrapper":4}],11:[function(_dereq_,module,exports){
var ajax = _dereq_('../ajax_wrapper');

module.exports = {

    getUserActivityStatus: function (openId, activityId) {
        var deferred = $.Deferred();

        var params = 'ihakula_request=ihakula_northern_hemisphere'
            + '&open_id=' + openId
            + '&activity_id=' + activityId;
        ajax.getJsonWithPromise('/weixin/get/user/activity/status?' + params)
            .done(function (userActivityInfo) {
                deferred.resolve(userActivityInfo);
            });
        return deferred.promise();
    },

    drawPrize: function (openId, activityId) {
        var deferred = $.Deferred();

        var params = openId + '/' + activityId +  '?ihakula_request=ihakula_northern_hemisphere';
        ajax.getJsonWithPromise('/weixin/user/draw/prize/' + params)
            .done(function (userActivityInfo) {
                deferred.resolve(userActivityInfo);
            });
        return deferred.promise();
    }
};
},{"../ajax_wrapper":4}],12:[function(_dereq_,module,exports){
var ajax = _dereq_('../ajax_wrapper');

module.exports = {

    getAllSaleRecords: function () {
        var deferred = $.Deferred();

        ajax.getJsonWithPromise('/sale/records')
            .done(function (records) {
                deferred.resolve(records);
            });
        return deferred.promise();
    }
};
},{"../ajax_wrapper":4}],13:[function(_dereq_,module,exports){
var ActivityPageViewModel = _dereq_('./activitypage_view_model');

module.exports = {
    applyToPage: function() {
        var sfView = document.getElementById('sf-view');
        ko.applyBindings(new ActivityPageViewModel(), sfView);
    }
};
},{"./activitypage_view_model":14}],14:[function(_dereq_,module,exports){
var sales_service = _dereq_('../services/activity_service.js');

module.exports = (function () {
    'use strict';
    var self;

    function HomepageViewModel() {
        self = this;
        self.usersIdArr = null;
        self.usersDetailDic = null;
        self.usersSaleDic = null;
        self.accountFieldArr = null;
        self.accountFieldDetailArr = null;
        self.activities = ko.observableArray([]);
        self.userFinacial = ko.observableArray([]);
        self.isLoading = ko.observable(true);

        self.initialise();

        self.cacheCaches = function(data){
            self.usersIdArr = data["users"].split(",");
            self.usersDetailDic = data["users_detail_info"];
            self.usersSaleDic = data["users_sale_records"];
            self.accountFieldArr = data["account_field"];
            self.accountFieldDetailArr = data["account_field_detail"];
        };

        self.caculateRecords = function(){
            var allRecords = [];
            var totalEarn = 0.0;
            var totalCost = 0.0;
            var userCostAndEarn = [];
            _.each(self.usersIdArr, function(userId){
                var userEarn = 0.0;
                var userCost = 0.0;
                var userName = self.usersDetailDic[userId]['user_nickname'];
                var personRecords = self.usersSaleDic[userId];
                _.each(personRecords, function (record) {
                    var item = getFieldByFieldID(record.field_id)[0];
                    var itemDetail = getFieldDetailByFieldDetailId(record.field_detail_id)[0];
                    var startSign = item.type ? '(+) ' : '(-) ';
                    var text = startSign;
                    if (item.type) {
                        userEarn += record.money;
                    } else {
                        userCost += record.money;
                    }
                    text += item.field + ':' + itemDetail.name + ' ' + record.money + '(CNY); ' + record.description;
                    allRecords.push({
                        'text': text,
                        'date': record.date,
                        'money': startSign + record.money,
                        'user': userName
                    });
                });
                userCostAndEarn.push({
                    'text': userName,
                    'totalCost': userCost,
                    'totalEarn': userEarn,
                    'revenue': (userEarn - userCost).toFixed(2)
                });
                totalCost += userCost;
                totalEarn += userEarn;
            });

            self.userFinacial([{
                'text': '合计',
                'totalCost': totalCost,
                'totalEarn': totalEarn,
                'revenue': (totalEarn - totalCost).toFixed(2)
            }].concat(userCostAndEarn));

            var sortedRecords = _.chain(allRecords)
                .sortBy(function (record) {
                    return record.date;
                })
                .reverse()
                .value();
            self.saleRecords(sortedRecords);
        };

        function getFieldByFieldID (fieldId){
            return _.filter(self.accountFieldArr, function(field){
                return field["ID"] === fieldId;
            });
        };

        function getFieldDetailByFieldDetailId (detailId){
            return _.filter(self.accountFieldDetailArr, function(field){
                return field["ID"] === detailId;
            });
        };
    };

    HomepageViewModel.prototype.initialise = function () {
        return sales_service.getAllActivities()
            .done(function (data) {
                console.log(data);
                self.cacheCaches(data);
                self.caculateRecords();
                self.isLoading(false);
            });
    };

    return HomepageViewModel;
})();
},{"../services/activity_service.js":10}],15:[function(_dereq_,module,exports){
var HomePageViewModel = _dereq_('./homepage_view_model');

module.exports = {
    applyToPage: function() {
        var sfView = document.getElementById('sf-view');
        ko.applyBindings(new HomePageViewModel(), sfView);
    }
};
},{"./homepage_view_model":16}],16:[function(_dereq_,module,exports){
var sales_service = _dereq_('../services/sales_service.js');

module.exports = (function () {
    'use strict';
    var self;

    function HomepageViewModel() {
        self = this;
        self.usersIdArr = null;
        self.usersDetailDic = null;
        self.usersSaleDic = null;
        self.accountFieldArr = null;
        self.accountFieldDetailArr = null;
        self.saleRecords = ko.observableArray([]);
        self.userFinacial = ko.observableArray([]);
        self.isLoading = ko.observable(true);

        self.initialise();

        self.cacheCaches = function(data){
            self.usersIdArr = data["users"].split(",");
            self.usersDetailDic = data["users_detail_info"];
            self.usersSaleDic = data["users_sale_records"];
            self.accountFieldArr = data["account_field"];
            self.accountFieldDetailArr = data["account_field_detail"];
        };

        self.caculateRecords = function(){
            var allRecords = [];
            var totalEarn = 0.0;
            var totalCost = 0.0;
            var userCostAndEarn = [];
            _.each(self.usersIdArr, function(userId){
                var userEarn = 0.0;
                var userCost = 0.0;
                var userName = self.usersDetailDic[userId]['user_nickname'];
                var personRecords = self.usersSaleDic[userId];
                _.each(personRecords, function (record) {
                    var item = getFieldByFieldID(record.field_id)[0];
                    var itemDetail = getFieldDetailByFieldDetailId(record.field_detail_id)[0];
                    var startSign = item.type ? '(+) ' : '(-) ';
                    var text = startSign;
                    if (item.type) {
                        userEarn += record.money;
                    } else {
                        userCost += record.money;
                    }
                    text += item.field + ':' + itemDetail.name + ' ' + record.money + '(CNY); ' + record.description;
                    allRecords.push({
                        'text': text,
                        'date': record.date,
                        'money': startSign + record.money,
                        'user': userName
                    });
                });
                userCostAndEarn.push({
                    'text': userName,
                    'totalCost': userCost,
                    'totalEarn': userEarn,
                    'revenue': (userEarn - userCost).toFixed(2)
                });
                totalCost += userCost;
                totalEarn += userEarn;
            });

            self.userFinacial([{
                'text': '合计',
                'totalCost': totalCost,
                'totalEarn': totalEarn,
                'revenue': (totalEarn - totalCost).toFixed(2)
            }].concat(userCostAndEarn));

            var sortedRecords = _.chain(allRecords)
                .sortBy(function (record) {
                    return record.date;
                })
                .reverse()
                .value();
            self.saleRecords(sortedRecords);
        };

        function getFieldByFieldID (fieldId){
            return _.filter(self.accountFieldArr, function(field){
                return field["ID"] === fieldId;
            });
        };

        function getFieldDetailByFieldDetailId (detailId){
            return _.filter(self.accountFieldDetailArr, function(field){
                return field["ID"] === detailId;
            });
        };
    };

    HomepageViewModel.prototype.initialise = function () {
        return sales_service.getAllSaleRecords()
            .done(function (data) {
                console.log(data);
                self.cacheCaches(data);
                self.caculateRecords();
                self.isLoading(false);
            });
    };

    return HomepageViewModel;
})();
},{"../services/sales_service.js":12}],17:[function(_dereq_,module,exports){
var JoinActivityPageViewModel = _dereq_('./joinactivitypage_view_model');

module.exports = {
    applyToPage: function(openId, activityId) {
        var sfView = document.getElementById('sf-view');
        var mainPage = document.getElementById('main-page');
        mainPage.innerHTML = sfView.innerHTML;
        ko.applyBindings(new JoinActivityPageViewModel(openId, activityId), mainPage);
    }
};
},{"./joinactivitypage_view_model":18}],18:[function(_dereq_,module,exports){
var sales_service = _dereq_('../services/join_activity_service.js');
var qrCode = _dereq_('qrcode-npm');

module.exports = (function () {
    'use strict';
    var self;

    function JoinactivitypageViewModel(openId, activityId) {

        self = this;
        self.openId = openId;
        self.activityId = activityId;

        this.ACTIVITY_IS_GOING = 600;
        this.ACTIVITY_NOT_FOUND = 601;
        this.ACTIVITY_IS_OVER = 602;
        this.ACTIVITY_NOT_START = 603;
        this.ACTIVITY_HAS_JOINED = 604;
        this.ACTIVITY_CREATE_SUCC = 900;

        self.shakeEvent = new Shake({threshold: 15});
        self.userActivity = {};
        self.prize = {};

        self.messageType = ko.observable();
        self.messageContent = ko.observable();
        self.couponId = ko.observable();
        self.prizeName = ko.observable();
        self.joinedTime = ko.observable();
        self.endDate = ko.observable();

        self.isLoading = ko.observable(true);
        self.isFirstTime = ko.observable(false);
        self.hasJoined = ko.observable(false);
        self.wonCoupon = ko.observable(false);
        self.showMessage = ko.observable(false);

        self.initialise();
    };

    JoinactivitypageViewModel.prototype.dispatcherWonPrize = function(){
        var self = this;
        self.isLoading(false);

        var status = self.prize.status;
        switch(status){
            case self.ACTIVITY_HAS_JOINED:
                self.showHasJoinedMessage();
                break;
            case self.ACTIVITY_CREATE_SUCC:
                self.wonPrize();
                break;
            default:

        }
    };

    JoinactivitypageViewModel.prototype.dispatcher = function(){
        var self = this;
        self.isLoading(false);

        var status = self.userActivity.status;
        switch(status){
            case self.ACTIVITY_IS_GOING:
                if(self.userActivity.go_shake == 'yes'){
                    self.showShake();
                }
                break;
            case self.ACTIVITY_NOT_FOUND:
                self.showNotFound();
                break;
            case self.ACTIVITY_IS_OVER:
                self.showActivityIsOver();
                break;
            case self.ACTIVITY_NOT_START:
                self.showActivityIsNotStartYet();
                break;
            case self.ACTIVITY_HAS_JOINED:
                self.showHasJoinedMessage();
                break;
            case self.ACTIVITY_CREATE_SUCC:
                self.wonPrize();
                break;
            default:

        }
    };

    JoinactivitypageViewModel.prototype.restore = function(){
        var self = this;
        self.isFirstTime(false);
        self.hasJoined(false);
        self.wonCoupon(false);
        self.showMessage(false);
    };

    JoinactivitypageViewModel.prototype.wonPrize = function(){
        var self = this;
        self.restore();
        self.wonCoupon(true);
        self.prizeName(self.prize.name);
        self.couponId(self.prize.code);
        self.endDate(self.prize.end_date);

        self.drawQRCode(self.prize.code);
    };

    JoinactivitypageViewModel.prototype.drawQRCode = function(code){
        var qr = qrCode.qrcode(10, 'H');
        qr.addData(code);
        qr.make();

        var imgTag = qr.createImgTag();
        document.getElementById("qrcode").innerHTML = imgTag;
    };

    JoinactivitypageViewModel.prototype.showShake = function(){
        console.log('showShake');
        var self = this;
        self.restore();
        self.isFirstTime(true);
        self.startShakeSubscriber();

        //$("#shakeButton").bind("click",function(){
        //    self.shakeEventDidOccur();
        //});
    };

    JoinactivitypageViewModel.prototype.shakeEventDidOccur = function(){
        var self = this;
        var audio = document.getElementById("shake-sound-male");
        if (audio.paused) {
            audio.play();
        } else {
            audio.currentTime = 0;
        }
        self.stopShakeSubscriber();

        self.drawForAPrice();
    };

    JoinactivitypageViewModel.prototype.startShakeSubscriber =  function(){
        var self = this;
        self.shakeEvent.start();
        window.addEventListener('shake', self.shakeEventDidOccur.bind(self), false);
    };

    JoinactivitypageViewModel.prototype.stopShakeSubscriber =  function(){
        var self = this;
        self.shakeEvent.stop();
        window.removeEventListener('shake', self.shakeEventDidOccur, false);
    };

    JoinactivitypageViewModel.prototype.showHasJoinedMessage = function(){
        var self = this;
        self.restore();
        self.hasJoined(true);
        self.prizeName(self.userActivity.coupon.name);
        self.couponId(self.userActivity.coupon.code);
        self.joinedTime(self.userActivity.coupon.start_date.replace('T', ' '));
    };

    JoinactivitypageViewModel.prototype.showUserMessage = function(type, content){
        var self = this;
        self.restore();
        self.showMessage(true);
        self.messageType(type);
        self.messageContent(content);
    };

    JoinactivitypageViewModel.prototype.showActivityIsNotStartYet = function(){
        var self = this;
        self.showUserMessage(
            "活动序号为：" + self.activityId + " 的活动还没有开始",
            "请回复数字：1 查询当前活动"
        );
    };

    JoinactivitypageViewModel.prototype.showActivityIsOver = function(){
        var self = this;
        self.showUserMessage(
            "活动序号为：" + self.activityId + " 的活动已经结束",
            "请回复数字：1 查询当前活动"
        );
    };

    JoinactivitypageViewModel.prototype.showNotFound = function(){
        var self = this;
        self.showUserMessage(
            "活动序号为：" + self.activityId + " 的活动不存在",
            "请回复数字：1 查询当前活动"
        );
    };

    JoinactivitypageViewModel.prototype.initialise = function () {
        if(self.openId == 'ihakula_create_coupon') {
            self.isLoading(false);
            var couponInfo = self.activityId.split(':');
            self.prize = {
                name: couponInfo[0],
                code: couponInfo[1],
                end_date: couponInfo[2],
                start_date: couponInfo[3]
            };
            self.wonPrize();
        } else {
            self.isLoading(true);
            return sales_service.getUserActivityStatus(self.openId, self.activityId)
                .done(function (data) {
                    self.userActivity = data;
                    self.dispatcher();
                });
        }
    };

    JoinactivitypageViewModel.prototype.drawForAPrice = function(){
        self.isLoading(true);
        return sales_service.drawPrize(self.openId, self.activityId)
            .done(function (data) {
                self.prize = data;
                self.dispatcherWonPrize();
            });
    };

    return JoinactivitypageViewModel;
})();
},{"../services/join_activity_service.js":11,"qrcode-npm":3}]},{},[9])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9DTnd3c3VuL1dvcmtzcGFjZS9pSGFrdWxhL3dvcmtzcGFjZS9SdWJ5L05vcnRoZXJuSGVtaXNwaGVyZS9ub2RlX21vZHVsZXMvZ3J1bnQtYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvYnJvd3NlcmlmeS9ub2RlX21vZHVsZXMvYnJvd3Nlci1wYWNrL19wcmVsdWRlLmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL25vZGVfbW9kdWxlcy9kaXJlY3Rvci9idWlsZC9kaXJlY3Rvci5qcyIsIi9Vc2Vycy9DTnd3c3VuL1dvcmtzcGFjZS9pSGFrdWxhL3dvcmtzcGFjZS9SdWJ5L05vcnRoZXJuSGVtaXNwaGVyZS9ub2RlX21vZHVsZXMvZG9tcmVhZHkvcmVhZHkuanMiLCIvVXNlcnMvQ053d3N1bi9Xb3Jrc3BhY2UvaUhha3VsYS93b3Jrc3BhY2UvUnVieS9Ob3J0aGVybkhlbWlzcGhlcmUvbm9kZV9tb2R1bGVzL3FyY29kZS1ucG0vcXJjb2RlLmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL3B1YmxpYy9qYXZhc2NyaXB0cy9hamF4X3dyYXBwZXIuanMiLCIvVXNlcnMvQ053d3N1bi9Xb3Jrc3BhY2UvaUhha3VsYS93b3Jrc3BhY2UvUnVieS9Ob3J0aGVybkhlbWlzcGhlcmUvcHVibGljL2phdmFzY3JpcHRzL2NvbmZpZy9yb3V0ZXMuanMiLCIvVXNlcnMvQ053d3N1bi9Xb3Jrc3BhY2UvaUhha3VsYS93b3Jrc3BhY2UvUnVieS9Ob3J0aGVybkhlbWlzcGhlcmUvcHVibGljL2phdmFzY3JpcHRzL2luZnJhc3RydWN0dXJlL3ZpZXdfZW5naW5lLmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL3B1YmxpYy9qYXZhc2NyaXB0cy9pbmZyYXN0cnVjdHVyZS92aWV3X21vZGVsX3Jlc29sdmVyLmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL3B1YmxpYy9qYXZhc2NyaXB0cy9pbmZyYXN0cnVjdHVyZS92aWV3X3Jlc29sdmVyLmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL3B1YmxpYy9qYXZhc2NyaXB0cy9tYWluLmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL3B1YmxpYy9qYXZhc2NyaXB0cy9zZXJ2aWNlcy9hY3Rpdml0eV9zZXJ2aWNlLmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL3B1YmxpYy9qYXZhc2NyaXB0cy9zZXJ2aWNlcy9qb2luX2FjdGl2aXR5X3NlcnZpY2UuanMiLCIvVXNlcnMvQ053d3N1bi9Xb3Jrc3BhY2UvaUhha3VsYS93b3Jrc3BhY2UvUnVieS9Ob3J0aGVybkhlbWlzcGhlcmUvcHVibGljL2phdmFzY3JpcHRzL3NlcnZpY2VzL3NhbGVzX3NlcnZpY2UuanMiLCIvVXNlcnMvQ053d3N1bi9Xb3Jrc3BhY2UvaUhha3VsYS93b3Jrc3BhY2UvUnVieS9Ob3J0aGVybkhlbWlzcGhlcmUvcHVibGljL2phdmFzY3JpcHRzL3ZpZXdfbW9kZWxzL2FjdGl2aXR5X3BhZ2Vfdmlld19tb2RlbF9mYWN0b3J5LmpzIiwiL1VzZXJzL0NOd3dzdW4vV29ya3NwYWNlL2lIYWt1bGEvd29ya3NwYWNlL1J1YnkvTm9ydGhlcm5IZW1pc3BoZXJlL3B1YmxpYy9qYXZhc2NyaXB0cy92aWV3X21vZGVscy9hY3Rpdml0eXBhZ2Vfdmlld19tb2RlbC5qcyIsIi9Vc2Vycy9DTnd3c3VuL1dvcmtzcGFjZS9pSGFrdWxhL3dvcmtzcGFjZS9SdWJ5L05vcnRoZXJuSGVtaXNwaGVyZS9wdWJsaWMvamF2YXNjcmlwdHMvdmlld19tb2RlbHMvaG9tZV9wYWdlX3ZpZXdfbW9kZWxfZmFjdG9yeS5qcyIsIi9Vc2Vycy9DTnd3c3VuL1dvcmtzcGFjZS9pSGFrdWxhL3dvcmtzcGFjZS9SdWJ5L05vcnRoZXJuSGVtaXNwaGVyZS9wdWJsaWMvamF2YXNjcmlwdHMvdmlld19tb2RlbHMvaG9tZXBhZ2Vfdmlld19tb2RlbC5qcyIsIi9Vc2Vycy9DTnd3c3VuL1dvcmtzcGFjZS9pSGFrdWxhL3dvcmtzcGFjZS9SdWJ5L05vcnRoZXJuSGVtaXNwaGVyZS9wdWJsaWMvamF2YXNjcmlwdHMvdmlld19tb2RlbHMvam9pbl9hY3Rpdml0eV9wYWdlX3ZpZXdfbW9kZWxfZmFjdG9yeS5qcyIsIi9Vc2Vycy9DTnd3c3VuL1dvcmtzcGFjZS9pSGFrdWxhL3dvcmtzcGFjZS9SdWJ5L05vcnRoZXJuSGVtaXNwaGVyZS9wdWJsaWMvamF2YXNjcmlwdHMvdmlld19tb2RlbHMvam9pbmFjdGl2aXR5cGFnZV92aWV3X21vZGVsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNwdEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbG1EQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM3QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDM0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN6R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDVEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiBlKHQsbixyKXtmdW5jdGlvbiBzKG8sdSl7aWYoIW5bb10pe2lmKCF0W29dKXt2YXIgYT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2lmKCF1JiZhKXJldHVybiBhKG8sITApO2lmKGkpcmV0dXJuIGkobywhMCk7dGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIitvK1wiJ1wiKX12YXIgZj1uW29dPXtleHBvcnRzOnt9fTt0W29dWzBdLmNhbGwoZi5leHBvcnRzLGZ1bmN0aW9uKGUpe3ZhciBuPXRbb11bMV1bZV07cmV0dXJuIHMobj9uOmUpfSxmLGYuZXhwb3J0cyxlLHQsbixyKX1yZXR1cm4gbltvXS5leHBvcnRzfXZhciBpPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7Zm9yKHZhciBvPTA7bzxyLmxlbmd0aDtvKyspcyhyW29dKTtyZXR1cm4gc30pIiwiXG5cbi8vXG4vLyBHZW5lcmF0ZWQgb24gVHVlIERlYyAxNiAyMDE0IDEyOjEzOjQ3IEdNVCswMTAwIChDRVQpIGJ5IENoYXJsaWUgUm9iYmlucywgUGFvbG8gRnJhZ29tZW5pICYgdGhlIENvbnRyaWJ1dG9ycyAoVXNpbmcgQ29kZXN1cmdlb24pLlxuLy8gVmVyc2lvbiAxLjIuNlxuLy9cblxuKGZ1bmN0aW9uIChleHBvcnRzKSB7XG5cbi8qXG4gKiBicm93c2VyLmpzOiBCcm93c2VyIHNwZWNpZmljIGZ1bmN0aW9uYWxpdHkgZm9yIGRpcmVjdG9yLlxuICpcbiAqIChDKSAyMDExLCBDaGFybGllIFJvYmJpbnMsIFBhb2xvIEZyYWdvbWVuaSwgJiB0aGUgQ29udHJpYnV0b3JzLlxuICogTUlUIExJQ0VOU0VcbiAqXG4gKi9cblxudmFyIGRsb2MgPSBkb2N1bWVudC5sb2NhdGlvbjtcblxuZnVuY3Rpb24gZGxvY0hhc2hFbXB0eSgpIHtcbiAgLy8gTm9uLUlFIGJyb3dzZXJzIHJldHVybiAnJyB3aGVuIHRoZSBhZGRyZXNzIGJhciBzaG93cyAnIyc7IERpcmVjdG9yJ3MgbG9naWNcbiAgLy8gYXNzdW1lcyBib3RoIG1lYW4gZW1wdHkuXG4gIHJldHVybiBkbG9jLmhhc2ggPT09ICcnIHx8IGRsb2MuaGFzaCA9PT0gJyMnO1xufVxuXG52YXIgbGlzdGVuZXIgPSB7XG4gIG1vZGU6ICdtb2Rlcm4nLFxuICBoYXNoOiBkbG9jLmhhc2gsXG4gIGhpc3Rvcnk6IGZhbHNlLFxuXG4gIGNoZWNrOiBmdW5jdGlvbiAoKSB7XG4gICAgdmFyIGggPSBkbG9jLmhhc2g7XG4gICAgaWYgKGggIT0gdGhpcy5oYXNoKSB7XG4gICAgICB0aGlzLmhhc2ggPSBoO1xuICAgICAgdGhpcy5vbkhhc2hDaGFuZ2VkKCk7XG4gICAgfVxuICB9LFxuXG4gIGZpcmU6IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5tb2RlID09PSAnbW9kZXJuJykge1xuICAgICAgdGhpcy5oaXN0b3J5ID09PSB0cnVlID8gd2luZG93Lm9ucG9wc3RhdGUoKSA6IHdpbmRvdy5vbmhhc2hjaGFuZ2UoKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICB0aGlzLm9uSGFzaENoYW5nZWQoKTtcbiAgICB9XG4gIH0sXG5cbiAgaW5pdDogZnVuY3Rpb24gKGZuLCBoaXN0b3J5KSB7XG4gICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgIHRoaXMuaGlzdG9yeSA9IGhpc3Rvcnk7XG5cbiAgICBpZiAoIVJvdXRlci5saXN0ZW5lcnMpIHtcbiAgICAgIFJvdXRlci5saXN0ZW5lcnMgPSBbXTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBvbmNoYW5nZShvbkNoYW5nZUV2ZW50KSB7XG4gICAgICBmb3IgKHZhciBpID0gMCwgbCA9IFJvdXRlci5saXN0ZW5lcnMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIFJvdXRlci5saXN0ZW5lcnNbaV0ob25DaGFuZ2VFdmVudCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy9ub3RlIElFOCBpcyBiZWluZyBjb3VudGVkIGFzICdtb2Rlcm4nIGJlY2F1c2UgaXQgaGFzIHRoZSBoYXNoY2hhbmdlIGV2ZW50XG4gICAgaWYgKCdvbmhhc2hjaGFuZ2UnIGluIHdpbmRvdyAmJiAoZG9jdW1lbnQuZG9jdW1lbnRNb2RlID09PSB1bmRlZmluZWRcbiAgICAgIHx8IGRvY3VtZW50LmRvY3VtZW50TW9kZSA+IDcpKSB7XG4gICAgICAvLyBBdCBsZWFzdCBmb3Igbm93IEhUTUw1IGhpc3RvcnkgaXMgYXZhaWxhYmxlIGZvciAnbW9kZXJuJyBicm93c2VycyBvbmx5XG4gICAgICBpZiAodGhpcy5oaXN0b3J5ID09PSB0cnVlKSB7XG4gICAgICAgIC8vIFRoZXJlIGlzIGFuIG9sZCBidWcgaW4gQ2hyb21lIHRoYXQgY2F1c2VzIG9ucG9wc3RhdGUgdG8gZmlyZSBldmVuXG4gICAgICAgIC8vIHVwb24gaW5pdGlhbCBwYWdlIGxvYWQuIFNpbmNlIHRoZSBoYW5kbGVyIGlzIHJ1biBtYW51YWxseSBpbiBpbml0KCksXG4gICAgICAgIC8vIHRoaXMgd291bGQgY2F1c2UgQ2hyb21lIHRvIHJ1biBpdCB0d2lzZS4gQ3VycmVudGx5IHRoZSBvbmx5XG4gICAgICAgIC8vIHdvcmthcm91bmQgc2VlbXMgdG8gYmUgdG8gc2V0IHRoZSBoYW5kbGVyIGFmdGVyIHRoZSBpbml0aWFsIHBhZ2UgbG9hZFxuICAgICAgICAvLyBodHRwOi8vY29kZS5nb29nbGUuY29tL3AvY2hyb21pdW0vaXNzdWVzL2RldGFpbD9pZD02MzA0MFxuICAgICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICAgIHdpbmRvdy5vbnBvcHN0YXRlID0gb25jaGFuZ2U7XG4gICAgICAgIH0sIDUwMCk7XG4gICAgICB9XG4gICAgICBlbHNlIHtcbiAgICAgICAgd2luZG93Lm9uaGFzaGNoYW5nZSA9IG9uY2hhbmdlO1xuICAgICAgfVxuICAgICAgdGhpcy5tb2RlID0gJ21vZGVybic7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgLy9cbiAgICAgIC8vIElFIHN1cHBvcnQsIGJhc2VkIG9uIGEgY29uY2VwdCBieSBFcmlrIEFydmlkc29uIC4uLlxuICAgICAgLy9cbiAgICAgIHZhciBmcmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpO1xuICAgICAgZnJhbWUuaWQgPSAnc3RhdGUtZnJhbWUnO1xuICAgICAgZnJhbWUuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZnJhbWUpO1xuICAgICAgdGhpcy53cml0ZUZyYW1lKCcnKTtcblxuICAgICAgaWYgKCdvbnByb3BlcnR5Y2hhbmdlJyBpbiBkb2N1bWVudCAmJiAnYXR0YWNoRXZlbnQnIGluIGRvY3VtZW50KSB7XG4gICAgICAgIGRvY3VtZW50LmF0dGFjaEV2ZW50KCdvbnByb3BlcnR5Y2hhbmdlJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmIChldmVudC5wcm9wZXJ0eU5hbWUgPT09ICdsb2NhdGlvbicpIHtcbiAgICAgICAgICAgIHNlbGYuY2hlY2soKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICB3aW5kb3cuc2V0SW50ZXJ2YWwoZnVuY3Rpb24gKCkgeyBzZWxmLmNoZWNrKCk7IH0sIDUwKTtcblxuICAgICAgdGhpcy5vbkhhc2hDaGFuZ2VkID0gb25jaGFuZ2U7XG4gICAgICB0aGlzLm1vZGUgPSAnbGVnYWN5JztcbiAgICB9XG5cbiAgICBSb3V0ZXIubGlzdGVuZXJzLnB1c2goZm4pO1xuXG4gICAgcmV0dXJuIHRoaXMubW9kZTtcbiAgfSxcblxuICBkZXN0cm95OiBmdW5jdGlvbiAoZm4pIHtcbiAgICBpZiAoIVJvdXRlciB8fCAhUm91dGVyLmxpc3RlbmVycykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHZhciBsaXN0ZW5lcnMgPSBSb3V0ZXIubGlzdGVuZXJzO1xuXG4gICAgZm9yICh2YXIgaSA9IGxpc3RlbmVycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgaWYgKGxpc3RlbmVyc1tpXSA9PT0gZm4pIHtcbiAgICAgICAgbGlzdGVuZXJzLnNwbGljZShpLCAxKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sXG5cbiAgc2V0SGFzaDogZnVuY3Rpb24gKHMpIHtcbiAgICAvLyBNb3ppbGxhIGFsd2F5cyBhZGRzIGFuIGVudHJ5IHRvIHRoZSBoaXN0b3J5XG4gICAgaWYgKHRoaXMubW9kZSA9PT0gJ2xlZ2FjeScpIHtcbiAgICAgIHRoaXMud3JpdGVGcmFtZShzKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5oaXN0b3J5ID09PSB0cnVlKSB7XG4gICAgICB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUoe30sIGRvY3VtZW50LnRpdGxlLCBzKTtcbiAgICAgIC8vIEZpcmUgYW4gb25wb3BzdGF0ZSBldmVudCBtYW51YWxseSBzaW5jZSBwdXNoaW5nIGRvZXMgbm90IG9idmlvdXNseVxuICAgICAgLy8gdHJpZ2dlciB0aGUgcG9wIGV2ZW50LlxuICAgICAgdGhpcy5maXJlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRsb2MuaGFzaCA9IChzWzBdID09PSAnLycpID8gcyA6ICcvJyArIHM7XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIHdyaXRlRnJhbWU6IGZ1bmN0aW9uIChzKSB7XG4gICAgLy8gSUUgc3VwcG9ydC4uLlxuICAgIHZhciBmID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3N0YXRlLWZyYW1lJyk7XG4gICAgdmFyIGQgPSBmLmNvbnRlbnREb2N1bWVudCB8fCBmLmNvbnRlbnRXaW5kb3cuZG9jdW1lbnQ7XG4gICAgZC5vcGVuKCk7XG4gICAgZC53cml0ZShcIjxzY3JpcHQ+X2hhc2ggPSAnXCIgKyBzICsgXCInOyBvbmxvYWQgPSBwYXJlbnQubGlzdGVuZXIuc3luY0hhc2g7PHNjcmlwdD5cIik7XG4gICAgZC5jbG9zZSgpO1xuICB9LFxuXG4gIHN5bmNIYXNoOiBmdW5jdGlvbiAoKSB7XG4gICAgLy8gSUUgc3VwcG9ydC4uLlxuICAgIHZhciBzID0gdGhpcy5faGFzaDtcbiAgICBpZiAocyAhPSBkbG9jLmhhc2gpIHtcbiAgICAgIGRsb2MuaGFzaCA9IHM7XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9LFxuXG4gIG9uSGFzaENoYW5nZWQ6IGZ1bmN0aW9uICgpIHt9XG59O1xuXG52YXIgUm91dGVyID0gZXhwb3J0cy5Sb3V0ZXIgPSBmdW5jdGlvbiAocm91dGVzKSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBSb3V0ZXIpKSByZXR1cm4gbmV3IFJvdXRlcihyb3V0ZXMpO1xuXG4gIHRoaXMucGFyYW1zICAgPSB7fTtcbiAgdGhpcy5yb3V0ZXMgICA9IHt9O1xuICB0aGlzLm1ldGhvZHMgID0gWydvbicsICdvbmNlJywgJ2FmdGVyJywgJ2JlZm9yZSddO1xuICB0aGlzLnNjb3BlICAgID0gW107XG4gIHRoaXMuX21ldGhvZHMgPSB7fTtcblxuICB0aGlzLl9pbnNlcnQgPSB0aGlzLmluc2VydDtcbiAgdGhpcy5pbnNlcnQgPSB0aGlzLmluc2VydEV4O1xuXG4gIHRoaXMuaGlzdG9yeVN1cHBvcnQgPSAod2luZG93Lmhpc3RvcnkgIT0gbnVsbCA/IHdpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZSA6IG51bGwpICE9IG51bGxcblxuICB0aGlzLmNvbmZpZ3VyZSgpO1xuICB0aGlzLm1vdW50KHJvdXRlcyB8fCB7fSk7XG59O1xuXG5Sb3V0ZXIucHJvdG90eXBlLmluaXQgPSBmdW5jdGlvbiAocikge1xuICB2YXIgc2VsZiA9IHRoaXNcbiAgICAsIHJvdXRlVG87XG4gIHRoaXMuaGFuZGxlciA9IGZ1bmN0aW9uKG9uQ2hhbmdlRXZlbnQpIHtcbiAgICB2YXIgbmV3VVJMID0gb25DaGFuZ2VFdmVudCAmJiBvbkNoYW5nZUV2ZW50Lm5ld1VSTCB8fCB3aW5kb3cubG9jYXRpb24uaGFzaDtcbiAgICB2YXIgdXJsID0gc2VsZi5oaXN0b3J5ID09PSB0cnVlID8gc2VsZi5nZXRQYXRoKCkgOiBuZXdVUkwucmVwbGFjZSgvLiojLywgJycpO1xuICAgIHNlbGYuZGlzcGF0Y2goJ29uJywgdXJsLmNoYXJBdCgwKSA9PT0gJy8nID8gdXJsIDogJy8nICsgdXJsKTtcbiAgfTtcblxuICBsaXN0ZW5lci5pbml0KHRoaXMuaGFuZGxlciwgdGhpcy5oaXN0b3J5KTtcblxuICBpZiAodGhpcy5oaXN0b3J5ID09PSBmYWxzZSkge1xuICAgIGlmIChkbG9jSGFzaEVtcHR5KCkgJiYgcikge1xuICAgICAgZGxvYy5oYXNoID0gcjtcbiAgICB9IGVsc2UgaWYgKCFkbG9jSGFzaEVtcHR5KCkpIHtcbiAgICAgIHNlbGYuZGlzcGF0Y2goJ29uJywgJy8nICsgZGxvYy5oYXNoLnJlcGxhY2UoL14oI1xcL3wjfFxcLykvLCAnJykpO1xuICAgIH1cbiAgfVxuICBlbHNlIHtcbiAgICBpZiAodGhpcy5jb252ZXJ0X2hhc2hfaW5faW5pdCkge1xuICAgICAgLy8gVXNlIGhhc2ggYXMgcm91dGVcbiAgICAgIHJvdXRlVG8gPSBkbG9jSGFzaEVtcHR5KCkgJiYgciA/IHIgOiAhZGxvY0hhc2hFbXB0eSgpID8gZGxvYy5oYXNoLnJlcGxhY2UoL14jLywgJycpIDogbnVsbDtcbiAgICAgIGlmIChyb3V0ZVRvKSB7XG4gICAgICAgIHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSh7fSwgZG9jdW1lbnQudGl0bGUsIHJvdXRlVG8pO1xuICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgIC8vIFVzZSBjYW5vbmljYWwgdXJsXG4gICAgICByb3V0ZVRvID0gdGhpcy5nZXRQYXRoKCk7XG4gICAgfVxuXG4gICAgLy8gUm91dGVyIGhhcyBiZWVuIGluaXRpYWxpemVkLCBidXQgZHVlIHRvIHRoZSBjaHJvbWUgYnVnIGl0IHdpbGwgbm90XG4gICAgLy8geWV0IGFjdHVhbGx5IHJvdXRlIEhUTUw1IGhpc3Rvcnkgc3RhdGUgY2hhbmdlcy4gVGh1cywgZGVjaWRlIGlmIHNob3VsZCByb3V0ZS5cbiAgICBpZiAocm91dGVUbyB8fCB0aGlzLnJ1bl9pbl9pbml0ID09PSB0cnVlKSB7XG4gICAgICB0aGlzLmhhbmRsZXIoKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdGhpcztcbn07XG5cblJvdXRlci5wcm90b3R5cGUuZXhwbG9kZSA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHYgPSB0aGlzLmhpc3RvcnkgPT09IHRydWUgPyB0aGlzLmdldFBhdGgoKSA6IGRsb2MuaGFzaDtcbiAgaWYgKHYuY2hhckF0KDEpID09PSAnLycpIHsgdj12LnNsaWNlKDEpIH1cbiAgcmV0dXJuIHYuc2xpY2UoMSwgdi5sZW5ndGgpLnNwbGl0KFwiL1wiKTtcbn07XG5cblJvdXRlci5wcm90b3R5cGUuc2V0Um91dGUgPSBmdW5jdGlvbiAoaSwgdiwgdmFsKSB7XG4gIHZhciB1cmwgPSB0aGlzLmV4cGxvZGUoKTtcblxuICBpZiAodHlwZW9mIGkgPT09ICdudW1iZXInICYmIHR5cGVvZiB2ID09PSAnc3RyaW5nJykge1xuICAgIHVybFtpXSA9IHY7XG4gIH1cbiAgZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gJ3N0cmluZycpIHtcbiAgICB1cmwuc3BsaWNlKGksIHYsIHMpO1xuICB9XG4gIGVsc2Uge1xuICAgIHVybCA9IFtpXTtcbiAgfVxuXG4gIGxpc3RlbmVyLnNldEhhc2godXJsLmpvaW4oJy8nKSk7XG4gIHJldHVybiB1cmw7XG59O1xuXG4vL1xuLy8gIyMjIGZ1bmN0aW9uIGluc2VydEV4KG1ldGhvZCwgcGF0aCwgcm91dGUsIHBhcmVudClcbi8vICMjIyMgQG1ldGhvZCB7c3RyaW5nfSBNZXRob2QgdG8gaW5zZXJ0IHRoZSBzcGVjaWZpYyBgcm91dGVgLlxuLy8gIyMjIyBAcGF0aCB7QXJyYXl9IFBhcnNlZCBwYXRoIHRvIGluc2VydCB0aGUgYHJvdXRlYCBhdC5cbi8vICMjIyMgQHJvdXRlIHtBcnJheXxmdW5jdGlvbn0gUm91dGUgaGFuZGxlcnMgdG8gaW5zZXJ0LlxuLy8gIyMjIyBAcGFyZW50IHtPYmplY3R9ICoqT3B0aW9uYWwqKiBQYXJlbnQgXCJyb3V0ZXNcIiB0byBpbnNlcnQgaW50by5cbi8vIGluc2VydCBhIGNhbGxiYWNrIHRoYXQgd2lsbCBvbmx5IG9jY3VyIG9uY2UgcGVyIHRoZSBtYXRjaGVkIHJvdXRlLlxuLy9cblJvdXRlci5wcm90b3R5cGUuaW5zZXJ0RXggPSBmdW5jdGlvbihtZXRob2QsIHBhdGgsIHJvdXRlLCBwYXJlbnQpIHtcbiAgaWYgKG1ldGhvZCA9PT0gXCJvbmNlXCIpIHtcbiAgICBtZXRob2QgPSBcIm9uXCI7XG4gICAgcm91dGUgPSBmdW5jdGlvbihyb3V0ZSkge1xuICAgICAgdmFyIG9uY2UgPSBmYWxzZTtcbiAgICAgIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKG9uY2UpIHJldHVybjtcbiAgICAgICAgb25jZSA9IHRydWU7XG4gICAgICAgIHJldHVybiByb3V0ZS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgfTtcbiAgICB9KHJvdXRlKTtcbiAgfVxuICByZXR1cm4gdGhpcy5faW5zZXJ0KG1ldGhvZCwgcGF0aCwgcm91dGUsIHBhcmVudCk7XG59O1xuXG5Sb3V0ZXIucHJvdG90eXBlLmdldFJvdXRlID0gZnVuY3Rpb24gKHYpIHtcbiAgdmFyIHJldCA9IHY7XG5cbiAgaWYgKHR5cGVvZiB2ID09PSBcIm51bWJlclwiKSB7XG4gICAgcmV0ID0gdGhpcy5leHBsb2RlKClbdl07XG4gIH1cbiAgZWxzZSBpZiAodHlwZW9mIHYgPT09IFwic3RyaW5nXCIpe1xuICAgIHZhciBoID0gdGhpcy5leHBsb2RlKCk7XG4gICAgcmV0ID0gaC5pbmRleE9mKHYpO1xuICB9XG4gIGVsc2Uge1xuICAgIHJldCA9IHRoaXMuZXhwbG9kZSgpO1xuICB9XG5cbiAgcmV0dXJuIHJldDtcbn07XG5cblJvdXRlci5wcm90b3R5cGUuZGVzdHJveSA9IGZ1bmN0aW9uICgpIHtcbiAgbGlzdGVuZXIuZGVzdHJveSh0aGlzLmhhbmRsZXIpO1xuICByZXR1cm4gdGhpcztcbn07XG5cblJvdXRlci5wcm90b3R5cGUuZ2V0UGF0aCA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIHBhdGggPSB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWU7XG4gIGlmIChwYXRoLnN1YnN0cigwLCAxKSAhPT0gJy8nKSB7XG4gICAgcGF0aCA9ICcvJyArIHBhdGg7XG4gIH1cbiAgcmV0dXJuIHBhdGg7XG59O1xuZnVuY3Rpb24gX2V2ZXJ5KGFyciwgaXRlcmF0b3IpIHtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcnIubGVuZ3RoOyBpICs9IDEpIHtcbiAgICBpZiAoaXRlcmF0b3IoYXJyW2ldLCBpLCBhcnIpID09PSBmYWxzZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBfZmxhdHRlbihhcnIpIHtcbiAgdmFyIGZsYXQgPSBbXTtcbiAgZm9yICh2YXIgaSA9IDAsIG4gPSBhcnIubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgZmxhdCA9IGZsYXQuY29uY2F0KGFycltpXSk7XG4gIH1cbiAgcmV0dXJuIGZsYXQ7XG59XG5cbmZ1bmN0aW9uIF9hc3luY0V2ZXJ5U2VyaWVzKGFyciwgaXRlcmF0b3IsIGNhbGxiYWNrKSB7XG4gIGlmICghYXJyLmxlbmd0aCkge1xuICAgIHJldHVybiBjYWxsYmFjaygpO1xuICB9XG4gIHZhciBjb21wbGV0ZWQgPSAwO1xuICAoZnVuY3Rpb24gaXRlcmF0ZSgpIHtcbiAgICBpdGVyYXRvcihhcnJbY29tcGxldGVkXSwgZnVuY3Rpb24oZXJyKSB7XG4gICAgICBpZiAoZXJyIHx8IGVyciA9PT0gZmFsc2UpIHtcbiAgICAgICAgY2FsbGJhY2soZXJyKTtcbiAgICAgICAgY2FsbGJhY2sgPSBmdW5jdGlvbigpIHt9O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29tcGxldGVkICs9IDE7XG4gICAgICAgIGlmIChjb21wbGV0ZWQgPT09IGFyci5sZW5ndGgpIHtcbiAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGl0ZXJhdGUoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9KSgpO1xufVxuXG5mdW5jdGlvbiBwYXJhbWlmeVN0cmluZyhzdHIsIHBhcmFtcywgbW9kKSB7XG4gIG1vZCA9IHN0cjtcbiAgZm9yICh2YXIgcGFyYW0gaW4gcGFyYW1zKSB7XG4gICAgaWYgKHBhcmFtcy5oYXNPd25Qcm9wZXJ0eShwYXJhbSkpIHtcbiAgICAgIG1vZCA9IHBhcmFtc1twYXJhbV0oc3RyKTtcbiAgICAgIGlmIChtb2QgIT09IHN0cikge1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIG1vZCA9PT0gc3RyID8gXCIoWy5fYS16QS1aMC05LSUoKV0rKVwiIDogbW9kO1xufVxuXG5mdW5jdGlvbiByZWdpZnlTdHJpbmcoc3RyLCBwYXJhbXMpIHtcbiAgdmFyIG1hdGNoZXMsIGxhc3QgPSAwLCBvdXQgPSBcIlwiO1xuICB3aGlsZSAobWF0Y2hlcyA9IHN0ci5zdWJzdHIobGFzdCkubWF0Y2goL1teXFx3XFxkXFwtICVAJl0qXFwqW15cXHdcXGRcXC0gJUAmXSovKSkge1xuICAgIGxhc3QgPSBtYXRjaGVzLmluZGV4ICsgbWF0Y2hlc1swXS5sZW5ndGg7XG4gICAgbWF0Y2hlc1swXSA9IG1hdGNoZXNbMF0ucmVwbGFjZSgvXlxcKi8sIFwiKFtfLigpIVxcXFwgJUAmYS16QS1aMC05LV0rKVwiKTtcbiAgICBvdXQgKz0gc3RyLnN1YnN0cigwLCBtYXRjaGVzLmluZGV4KSArIG1hdGNoZXNbMF07XG4gIH1cbiAgc3RyID0gb3V0ICs9IHN0ci5zdWJzdHIobGFzdCk7XG4gIHZhciBjYXB0dXJlcyA9IHN0ci5tYXRjaCgvOihbXlxcL10rKS9pZyksIGNhcHR1cmUsIGxlbmd0aDtcbiAgaWYgKGNhcHR1cmVzKSB7XG4gICAgbGVuZ3RoID0gY2FwdHVyZXMubGVuZ3RoO1xuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIGNhcHR1cmUgPSBjYXB0dXJlc1tpXTtcbiAgICAgIGlmIChjYXB0dXJlLnNsaWNlKDAsIDIpID09PSBcIjo6XCIpIHtcbiAgICAgICAgc3RyID0gY2FwdHVyZS5zbGljZSgxKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN0ciA9IHN0ci5yZXBsYWNlKGNhcHR1cmUsIHBhcmFtaWZ5U3RyaW5nKGNhcHR1cmUsIHBhcmFtcykpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gc3RyO1xufVxuXG5mdW5jdGlvbiB0ZXJtaW5hdG9yKHJvdXRlcywgZGVsaW1pdGVyLCBzdGFydCwgc3RvcCkge1xuICB2YXIgbGFzdCA9IDAsIGxlZnQgPSAwLCByaWdodCA9IDAsIHN0YXJ0ID0gKHN0YXJ0IHx8IFwiKFwiKS50b1N0cmluZygpLCBzdG9wID0gKHN0b3AgfHwgXCIpXCIpLnRvU3RyaW5nKCksIGk7XG4gIGZvciAoaSA9IDA7IGkgPCByb3V0ZXMubGVuZ3RoOyBpKyspIHtcbiAgICB2YXIgY2h1bmsgPSByb3V0ZXNbaV07XG4gICAgaWYgKGNodW5rLmluZGV4T2Yoc3RhcnQsIGxhc3QpID4gY2h1bmsuaW5kZXhPZihzdG9wLCBsYXN0KSB8fCB+Y2h1bmsuaW5kZXhPZihzdGFydCwgbGFzdCkgJiYgIX5jaHVuay5pbmRleE9mKHN0b3AsIGxhc3QpIHx8ICF+Y2h1bmsuaW5kZXhPZihzdGFydCwgbGFzdCkgJiYgfmNodW5rLmluZGV4T2Yoc3RvcCwgbGFzdCkpIHtcbiAgICAgIGxlZnQgPSBjaHVuay5pbmRleE9mKHN0YXJ0LCBsYXN0KTtcbiAgICAgIHJpZ2h0ID0gY2h1bmsuaW5kZXhPZihzdG9wLCBsYXN0KTtcbiAgICAgIGlmICh+bGVmdCAmJiAhfnJpZ2h0IHx8ICF+bGVmdCAmJiB+cmlnaHQpIHtcbiAgICAgICAgdmFyIHRtcCA9IHJvdXRlcy5zbGljZSgwLCAoaSB8fCAxKSArIDEpLmpvaW4oZGVsaW1pdGVyKTtcbiAgICAgICAgcm91dGVzID0gWyB0bXAgXS5jb25jYXQocm91dGVzLnNsaWNlKChpIHx8IDEpICsgMSkpO1xuICAgICAgfVxuICAgICAgbGFzdCA9IChyaWdodCA+IGxlZnQgPyByaWdodCA6IGxlZnQpICsgMTtcbiAgICAgIGkgPSAwO1xuICAgIH0gZWxzZSB7XG4gICAgICBsYXN0ID0gMDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJvdXRlcztcbn1cblxudmFyIFFVRVJZX1NFUEFSQVRPUiA9IC9cXD8uKi87XG5cblJvdXRlci5wcm90b3R5cGUuY29uZmlndXJlID0gZnVuY3Rpb24ob3B0aW9ucykge1xuICBvcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcbiAgZm9yICh2YXIgaSA9IDA7IGkgPCB0aGlzLm1ldGhvZHMubGVuZ3RoOyBpKyspIHtcbiAgICB0aGlzLl9tZXRob2RzW3RoaXMubWV0aG9kc1tpXV0gPSB0cnVlO1xuICB9XG4gIHRoaXMucmVjdXJzZSA9IG9wdGlvbnMucmVjdXJzZSB8fCB0aGlzLnJlY3Vyc2UgfHwgZmFsc2U7XG4gIHRoaXMuYXN5bmMgPSBvcHRpb25zLmFzeW5jIHx8IGZhbHNlO1xuICB0aGlzLmRlbGltaXRlciA9IG9wdGlvbnMuZGVsaW1pdGVyIHx8IFwiL1wiO1xuICB0aGlzLnN0cmljdCA9IHR5cGVvZiBvcHRpb25zLnN0cmljdCA9PT0gXCJ1bmRlZmluZWRcIiA/IHRydWUgOiBvcHRpb25zLnN0cmljdDtcbiAgdGhpcy5ub3Rmb3VuZCA9IG9wdGlvbnMubm90Zm91bmQ7XG4gIHRoaXMucmVzb3VyY2UgPSBvcHRpb25zLnJlc291cmNlO1xuICB0aGlzLmhpc3RvcnkgPSBvcHRpb25zLmh0bWw1aGlzdG9yeSAmJiB0aGlzLmhpc3RvcnlTdXBwb3J0IHx8IGZhbHNlO1xuICB0aGlzLnJ1bl9pbl9pbml0ID0gdGhpcy5oaXN0b3J5ID09PSB0cnVlICYmIG9wdGlvbnMucnVuX2hhbmRsZXJfaW5faW5pdCAhPT0gZmFsc2U7XG4gIHRoaXMuY29udmVydF9oYXNoX2luX2luaXQgPSB0aGlzLmhpc3RvcnkgPT09IHRydWUgJiYgb3B0aW9ucy5jb252ZXJ0X2hhc2hfaW5faW5pdCAhPT0gZmFsc2U7XG4gIHRoaXMuZXZlcnkgPSB7XG4gICAgYWZ0ZXI6IG9wdGlvbnMuYWZ0ZXIgfHwgbnVsbCxcbiAgICBiZWZvcmU6IG9wdGlvbnMuYmVmb3JlIHx8IG51bGwsXG4gICAgb246IG9wdGlvbnMub24gfHwgbnVsbFxuICB9O1xuICByZXR1cm4gdGhpcztcbn07XG5cblJvdXRlci5wcm90b3R5cGUucGFyYW0gPSBmdW5jdGlvbih0b2tlbiwgbWF0Y2hlcikge1xuICBpZiAodG9rZW5bMF0gIT09IFwiOlwiKSB7XG4gICAgdG9rZW4gPSBcIjpcIiArIHRva2VuO1xuICB9XG4gIHZhciBjb21waWxlZCA9IG5ldyBSZWdFeHAodG9rZW4sIFwiZ1wiKTtcbiAgdGhpcy5wYXJhbXNbdG9rZW5dID0gZnVuY3Rpb24oc3RyKSB7XG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKGNvbXBpbGVkLCBtYXRjaGVyLnNvdXJjZSB8fCBtYXRjaGVyKTtcbiAgfTtcbiAgcmV0dXJuIHRoaXM7XG59O1xuXG5Sb3V0ZXIucHJvdG90eXBlLm9uID0gUm91dGVyLnByb3RvdHlwZS5yb3V0ZSA9IGZ1bmN0aW9uKG1ldGhvZCwgcGF0aCwgcm91dGUpIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBpZiAoIXJvdXRlICYmIHR5cGVvZiBwYXRoID09IFwiZnVuY3Rpb25cIikge1xuICAgIHJvdXRlID0gcGF0aDtcbiAgICBwYXRoID0gbWV0aG9kO1xuICAgIG1ldGhvZCA9IFwib25cIjtcbiAgfVxuICBpZiAoQXJyYXkuaXNBcnJheShwYXRoKSkge1xuICAgIHJldHVybiBwYXRoLmZvckVhY2goZnVuY3Rpb24ocCkge1xuICAgICAgc2VsZi5vbihtZXRob2QsIHAsIHJvdXRlKTtcbiAgICB9KTtcbiAgfVxuICBpZiAocGF0aC5zb3VyY2UpIHtcbiAgICBwYXRoID0gcGF0aC5zb3VyY2UucmVwbGFjZSgvXFxcXFxcLy9pZywgXCIvXCIpO1xuICB9XG4gIGlmIChBcnJheS5pc0FycmF5KG1ldGhvZCkpIHtcbiAgICByZXR1cm4gbWV0aG9kLmZvckVhY2goZnVuY3Rpb24obSkge1xuICAgICAgc2VsZi5vbihtLnRvTG93ZXJDYXNlKCksIHBhdGgsIHJvdXRlKTtcbiAgICB9KTtcbiAgfVxuICBwYXRoID0gcGF0aC5zcGxpdChuZXcgUmVnRXhwKHRoaXMuZGVsaW1pdGVyKSk7XG4gIHBhdGggPSB0ZXJtaW5hdG9yKHBhdGgsIHRoaXMuZGVsaW1pdGVyKTtcbiAgdGhpcy5pbnNlcnQobWV0aG9kLCB0aGlzLnNjb3BlLmNvbmNhdChwYXRoKSwgcm91dGUpO1xufTtcblxuUm91dGVyLnByb3RvdHlwZS5wYXRoID0gZnVuY3Rpb24ocGF0aCwgcm91dGVzRm4pIHtcbiAgdmFyIHNlbGYgPSB0aGlzLCBsZW5ndGggPSB0aGlzLnNjb3BlLmxlbmd0aDtcbiAgaWYgKHBhdGguc291cmNlKSB7XG4gICAgcGF0aCA9IHBhdGguc291cmNlLnJlcGxhY2UoL1xcXFxcXC8vaWcsIFwiL1wiKTtcbiAgfVxuICBwYXRoID0gcGF0aC5zcGxpdChuZXcgUmVnRXhwKHRoaXMuZGVsaW1pdGVyKSk7XG4gIHBhdGggPSB0ZXJtaW5hdG9yKHBhdGgsIHRoaXMuZGVsaW1pdGVyKTtcbiAgdGhpcy5zY29wZSA9IHRoaXMuc2NvcGUuY29uY2F0KHBhdGgpO1xuICByb3V0ZXNGbi5jYWxsKHRoaXMsIHRoaXMpO1xuICB0aGlzLnNjb3BlLnNwbGljZShsZW5ndGgsIHBhdGgubGVuZ3RoKTtcbn07XG5cblJvdXRlci5wcm90b3R5cGUuZGlzcGF0Y2ggPSBmdW5jdGlvbihtZXRob2QsIHBhdGgsIGNhbGxiYWNrKSB7XG4gIHZhciBzZWxmID0gdGhpcywgZm5zID0gdGhpcy50cmF2ZXJzZShtZXRob2QsIHBhdGgucmVwbGFjZShRVUVSWV9TRVBBUkFUT1IsIFwiXCIpLCB0aGlzLnJvdXRlcywgXCJcIiksIGludm9rZWQgPSB0aGlzLl9pbnZva2VkLCBhZnRlcjtcbiAgdGhpcy5faW52b2tlZCA9IHRydWU7XG4gIGlmICghZm5zIHx8IGZucy5sZW5ndGggPT09IDApIHtcbiAgICB0aGlzLmxhc3QgPSBbXTtcbiAgICBpZiAodHlwZW9mIHRoaXMubm90Zm91bmQgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhpcy5pbnZva2UoWyB0aGlzLm5vdGZvdW5kIF0sIHtcbiAgICAgICAgbWV0aG9kOiBtZXRob2QsXG4gICAgICAgIHBhdGg6IHBhdGhcbiAgICAgIH0sIGNhbGxiYWNrKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh0aGlzLnJlY3Vyc2UgPT09IFwiZm9yd2FyZFwiKSB7XG4gICAgZm5zID0gZm5zLnJldmVyc2UoKTtcbiAgfVxuICBmdW5jdGlvbiB1cGRhdGVBbmRJbnZva2UoKSB7XG4gICAgc2VsZi5sYXN0ID0gZm5zLmFmdGVyO1xuICAgIHNlbGYuaW52b2tlKHNlbGYucnVubGlzdChmbnMpLCBzZWxmLCBjYWxsYmFjayk7XG4gIH1cbiAgYWZ0ZXIgPSB0aGlzLmV2ZXJ5ICYmIHRoaXMuZXZlcnkuYWZ0ZXIgPyBbIHRoaXMuZXZlcnkuYWZ0ZXIgXS5jb25jYXQodGhpcy5sYXN0KSA6IFsgdGhpcy5sYXN0IF07XG4gIGlmIChhZnRlciAmJiBhZnRlci5sZW5ndGggPiAwICYmIGludm9rZWQpIHtcbiAgICBpZiAodGhpcy5hc3luYykge1xuICAgICAgdGhpcy5pbnZva2UoYWZ0ZXIsIHRoaXMsIHVwZGF0ZUFuZEludm9rZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuaW52b2tlKGFmdGVyLCB0aGlzKTtcbiAgICAgIHVwZGF0ZUFuZEludm9rZSgpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICB1cGRhdGVBbmRJbnZva2UoKTtcbiAgcmV0dXJuIHRydWU7XG59O1xuXG5Sb3V0ZXIucHJvdG90eXBlLmludm9rZSA9IGZ1bmN0aW9uKGZucywgdGhpc0FyZywgY2FsbGJhY2spIHtcbiAgdmFyIHNlbGYgPSB0aGlzO1xuICB2YXIgYXBwbHk7XG4gIGlmICh0aGlzLmFzeW5jKSB7XG4gICAgYXBwbHkgPSBmdW5jdGlvbihmbiwgbmV4dCkge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZm4pKSB7XG4gICAgICAgIHJldHVybiBfYXN5bmNFdmVyeVNlcmllcyhmbiwgYXBwbHksIG5leHQpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgZm4gPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIGZuLmFwcGx5KHRoaXNBcmcsIChmbnMuY2FwdHVyZXMgfHwgW10pLmNvbmNhdChuZXh0KSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBfYXN5bmNFdmVyeVNlcmllcyhmbnMsIGFwcGx5LCBmdW5jdGlvbigpIHtcbiAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICBjYWxsYmFjay5hcHBseSh0aGlzQXJnLCBhcmd1bWVudHMpO1xuICAgICAgfVxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIGFwcGx5ID0gZnVuY3Rpb24oZm4pIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGZuKSkge1xuICAgICAgICByZXR1cm4gX2V2ZXJ5KGZuLCBhcHBseSk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBmbiA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHJldHVybiBmbi5hcHBseSh0aGlzQXJnLCBmbnMuY2FwdHVyZXMgfHwgW10pO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgZm4gPT09IFwic3RyaW5nXCIgJiYgc2VsZi5yZXNvdXJjZSkge1xuICAgICAgICBzZWxmLnJlc291cmNlW2ZuXS5hcHBseSh0aGlzQXJnLCBmbnMuY2FwdHVyZXMgfHwgW10pO1xuICAgICAgfVxuICAgIH07XG4gICAgX2V2ZXJ5KGZucywgYXBwbHkpO1xuICB9XG59O1xuXG5Sb3V0ZXIucHJvdG90eXBlLnRyYXZlcnNlID0gZnVuY3Rpb24obWV0aG9kLCBwYXRoLCByb3V0ZXMsIHJlZ2V4cCwgZmlsdGVyKSB7XG4gIHZhciBmbnMgPSBbXSwgY3VycmVudCwgZXhhY3QsIG1hdGNoLCBuZXh0LCB0aGF0O1xuICBmdW5jdGlvbiBmaWx0ZXJSb3V0ZXMocm91dGVzKSB7XG4gICAgaWYgKCFmaWx0ZXIpIHtcbiAgICAgIHJldHVybiByb3V0ZXM7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGRlZXBDb3B5KHNvdXJjZSkge1xuICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzb3VyY2UubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgcmVzdWx0W2ldID0gQXJyYXkuaXNBcnJheShzb3VyY2VbaV0pID8gZGVlcENvcHkoc291cmNlW2ldKSA6IHNvdXJjZVtpXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGFwcGx5RmlsdGVyKGZucykge1xuICAgICAgZm9yICh2YXIgaSA9IGZucy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShmbnNbaV0pKSB7XG4gICAgICAgICAgYXBwbHlGaWx0ZXIoZm5zW2ldKTtcbiAgICAgICAgICBpZiAoZm5zW2ldLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgZm5zLnNwbGljZShpLCAxKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKCFmaWx0ZXIoZm5zW2ldKSkge1xuICAgICAgICAgICAgZm5zLnNwbGljZShpLCAxKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgdmFyIG5ld1JvdXRlcyA9IGRlZXBDb3B5KHJvdXRlcyk7XG4gICAgbmV3Um91dGVzLm1hdGNoZWQgPSByb3V0ZXMubWF0Y2hlZDtcbiAgICBuZXdSb3V0ZXMuY2FwdHVyZXMgPSByb3V0ZXMuY2FwdHVyZXM7XG4gICAgbmV3Um91dGVzLmFmdGVyID0gcm91dGVzLmFmdGVyLmZpbHRlcihmaWx0ZXIpO1xuICAgIGFwcGx5RmlsdGVyKG5ld1JvdXRlcyk7XG4gICAgcmV0dXJuIG5ld1JvdXRlcztcbiAgfVxuICBpZiAocGF0aCA9PT0gdGhpcy5kZWxpbWl0ZXIgJiYgcm91dGVzW21ldGhvZF0pIHtcbiAgICBuZXh0ID0gWyBbIHJvdXRlcy5iZWZvcmUsIHJvdXRlc1ttZXRob2RdIF0uZmlsdGVyKEJvb2xlYW4pIF07XG4gICAgbmV4dC5hZnRlciA9IFsgcm91dGVzLmFmdGVyIF0uZmlsdGVyKEJvb2xlYW4pO1xuICAgIG5leHQubWF0Y2hlZCA9IHRydWU7XG4gICAgbmV4dC5jYXB0dXJlcyA9IFtdO1xuICAgIHJldHVybiBmaWx0ZXJSb3V0ZXMobmV4dCk7XG4gIH1cbiAgZm9yICh2YXIgciBpbiByb3V0ZXMpIHtcbiAgICBpZiAocm91dGVzLmhhc093blByb3BlcnR5KHIpICYmICghdGhpcy5fbWV0aG9kc1tyXSB8fCB0aGlzLl9tZXRob2RzW3JdICYmIHR5cGVvZiByb3V0ZXNbcl0gPT09IFwib2JqZWN0XCIgJiYgIUFycmF5LmlzQXJyYXkocm91dGVzW3JdKSkpIHtcbiAgICAgIGN1cnJlbnQgPSBleGFjdCA9IHJlZ2V4cCArIHRoaXMuZGVsaW1pdGVyICsgcjtcbiAgICAgIGlmICghdGhpcy5zdHJpY3QpIHtcbiAgICAgICAgZXhhY3QgKz0gXCJbXCIgKyB0aGlzLmRlbGltaXRlciArIFwiXT9cIjtcbiAgICAgIH1cbiAgICAgIG1hdGNoID0gcGF0aC5tYXRjaChuZXcgUmVnRXhwKFwiXlwiICsgZXhhY3QpKTtcbiAgICAgIGlmICghbWF0Y2gpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAobWF0Y2hbMF0gJiYgbWF0Y2hbMF0gPT0gcGF0aCAmJiByb3V0ZXNbcl1bbWV0aG9kXSkge1xuICAgICAgICBuZXh0ID0gWyBbIHJvdXRlc1tyXS5iZWZvcmUsIHJvdXRlc1tyXVttZXRob2RdIF0uZmlsdGVyKEJvb2xlYW4pIF07XG4gICAgICAgIG5leHQuYWZ0ZXIgPSBbIHJvdXRlc1tyXS5hZnRlciBdLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgbmV4dC5tYXRjaGVkID0gdHJ1ZTtcbiAgICAgICAgbmV4dC5jYXB0dXJlcyA9IG1hdGNoLnNsaWNlKDEpO1xuICAgICAgICBpZiAodGhpcy5yZWN1cnNlICYmIHJvdXRlcyA9PT0gdGhpcy5yb3V0ZXMpIHtcbiAgICAgICAgICBuZXh0LnB1c2goWyByb3V0ZXMuYmVmb3JlLCByb3V0ZXMub24gXS5maWx0ZXIoQm9vbGVhbikpO1xuICAgICAgICAgIG5leHQuYWZ0ZXIgPSBuZXh0LmFmdGVyLmNvbmNhdChbIHJvdXRlcy5hZnRlciBdLmZpbHRlcihCb29sZWFuKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZpbHRlclJvdXRlcyhuZXh0KTtcbiAgICAgIH1cbiAgICAgIG5leHQgPSB0aGlzLnRyYXZlcnNlKG1ldGhvZCwgcGF0aCwgcm91dGVzW3JdLCBjdXJyZW50KTtcbiAgICAgIGlmIChuZXh0Lm1hdGNoZWQpIHtcbiAgICAgICAgaWYgKG5leHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGZucyA9IGZucy5jb25jYXQobmV4dCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMucmVjdXJzZSkge1xuICAgICAgICAgIGZucy5wdXNoKFsgcm91dGVzW3JdLmJlZm9yZSwgcm91dGVzW3JdLm9uIF0uZmlsdGVyKEJvb2xlYW4pKTtcbiAgICAgICAgICBuZXh0LmFmdGVyID0gbmV4dC5hZnRlci5jb25jYXQoWyByb3V0ZXNbcl0uYWZ0ZXIgXS5maWx0ZXIoQm9vbGVhbikpO1xuICAgICAgICAgIGlmIChyb3V0ZXMgPT09IHRoaXMucm91dGVzKSB7XG4gICAgICAgICAgICBmbnMucHVzaChbIHJvdXRlc1tcImJlZm9yZVwiXSwgcm91dGVzW1wib25cIl0gXS5maWx0ZXIoQm9vbGVhbikpO1xuICAgICAgICAgICAgbmV4dC5hZnRlciA9IG5leHQuYWZ0ZXIuY29uY2F0KFsgcm91dGVzW1wiYWZ0ZXJcIl0gXS5maWx0ZXIoQm9vbGVhbikpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmbnMubWF0Y2hlZCA9IHRydWU7XG4gICAgICAgIGZucy5jYXB0dXJlcyA9IG5leHQuY2FwdHVyZXM7XG4gICAgICAgIGZucy5hZnRlciA9IG5leHQuYWZ0ZXI7XG4gICAgICAgIHJldHVybiBmaWx0ZXJSb3V0ZXMoZm5zKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufTtcblxuUm91dGVyLnByb3RvdHlwZS5pbnNlcnQgPSBmdW5jdGlvbihtZXRob2QsIHBhdGgsIHJvdXRlLCBwYXJlbnQpIHtcbiAgdmFyIG1ldGhvZFR5cGUsIHBhcmVudFR5cGUsIGlzQXJyYXksIG5lc3RlZCwgcGFydDtcbiAgcGF0aCA9IHBhdGguZmlsdGVyKGZ1bmN0aW9uKHApIHtcbiAgICByZXR1cm4gcCAmJiBwLmxlbmd0aCA+IDA7XG4gIH0pO1xuICBwYXJlbnQgPSBwYXJlbnQgfHwgdGhpcy5yb3V0ZXM7XG4gIHBhcnQgPSBwYXRoLnNoaWZ0KCk7XG4gIGlmICgvXFw6fFxcKi8udGVzdChwYXJ0KSAmJiAhL1xcXFxkfFxcXFx3Ly50ZXN0KHBhcnQpKSB7XG4gICAgcGFydCA9IHJlZ2lmeVN0cmluZyhwYXJ0LCB0aGlzLnBhcmFtcyk7XG4gIH1cbiAgaWYgKHBhdGgubGVuZ3RoID4gMCkge1xuICAgIHBhcmVudFtwYXJ0XSA9IHBhcmVudFtwYXJ0XSB8fCB7fTtcbiAgICByZXR1cm4gdGhpcy5pbnNlcnQobWV0aG9kLCBwYXRoLCByb3V0ZSwgcGFyZW50W3BhcnRdKTtcbiAgfVxuICBpZiAoIXBhcnQgJiYgIXBhdGgubGVuZ3RoICYmIHBhcmVudCA9PT0gdGhpcy5yb3V0ZXMpIHtcbiAgICBtZXRob2RUeXBlID0gdHlwZW9mIHBhcmVudFttZXRob2RdO1xuICAgIHN3aXRjaCAobWV0aG9kVHlwZSkge1xuICAgICBjYXNlIFwiZnVuY3Rpb25cIjpcbiAgICAgIHBhcmVudFttZXRob2RdID0gWyBwYXJlbnRbbWV0aG9kXSwgcm91dGUgXTtcbiAgICAgIHJldHVybjtcbiAgICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgcGFyZW50W21ldGhvZF0ucHVzaChyb3V0ZSk7XG4gICAgICByZXR1cm47XG4gICAgIGNhc2UgXCJ1bmRlZmluZWRcIjpcbiAgICAgIHBhcmVudFttZXRob2RdID0gcm91dGU7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuICBwYXJlbnRUeXBlID0gdHlwZW9mIHBhcmVudFtwYXJ0XTtcbiAgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkocGFyZW50W3BhcnRdKTtcbiAgaWYgKHBhcmVudFtwYXJ0XSAmJiAhaXNBcnJheSAmJiBwYXJlbnRUeXBlID09IFwib2JqZWN0XCIpIHtcbiAgICBtZXRob2RUeXBlID0gdHlwZW9mIHBhcmVudFtwYXJ0XVttZXRob2RdO1xuICAgIHN3aXRjaCAobWV0aG9kVHlwZSkge1xuICAgICBjYXNlIFwiZnVuY3Rpb25cIjpcbiAgICAgIHBhcmVudFtwYXJ0XVttZXRob2RdID0gWyBwYXJlbnRbcGFydF1bbWV0aG9kXSwgcm91dGUgXTtcbiAgICAgIHJldHVybjtcbiAgICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgcGFyZW50W3BhcnRdW21ldGhvZF0ucHVzaChyb3V0ZSk7XG4gICAgICByZXR1cm47XG4gICAgIGNhc2UgXCJ1bmRlZmluZWRcIjpcbiAgICAgIHBhcmVudFtwYXJ0XVttZXRob2RdID0gcm91dGU7XG4gICAgICByZXR1cm47XG4gICAgfVxuICB9IGVsc2UgaWYgKHBhcmVudFR5cGUgPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIG5lc3RlZCA9IHt9O1xuICAgIG5lc3RlZFttZXRob2RdID0gcm91dGU7XG4gICAgcGFyZW50W3BhcnRdID0gbmVzdGVkO1xuICAgIHJldHVybjtcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHJvdXRlIGNvbnRleHQ6IFwiICsgcGFyZW50VHlwZSk7XG59O1xuXG5cblxuUm91dGVyLnByb3RvdHlwZS5leHRlbmQgPSBmdW5jdGlvbihtZXRob2RzKSB7XG4gIHZhciBzZWxmID0gdGhpcywgbGVuID0gbWV0aG9kcy5sZW5ndGgsIGk7XG4gIGZ1bmN0aW9uIGV4dGVuZChtZXRob2QpIHtcbiAgICBzZWxmLl9tZXRob2RzW21ldGhvZF0gPSB0cnVlO1xuICAgIHNlbGZbbWV0aG9kXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgdmFyIGV4dHJhID0gYXJndW1lbnRzLmxlbmd0aCA9PT0gMSA/IFsgbWV0aG9kLCBcIlwiIF0gOiBbIG1ldGhvZCBdO1xuICAgICAgc2VsZi5vbi5hcHBseShzZWxmLCBleHRyYS5jb25jYXQoQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKSkpO1xuICAgIH07XG4gIH1cbiAgZm9yIChpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgZXh0ZW5kKG1ldGhvZHNbaV0pO1xuICB9XG59O1xuXG5Sb3V0ZXIucHJvdG90eXBlLnJ1bmxpc3QgPSBmdW5jdGlvbihmbnMpIHtcbiAgdmFyIHJ1bmxpc3QgPSB0aGlzLmV2ZXJ5ICYmIHRoaXMuZXZlcnkuYmVmb3JlID8gWyB0aGlzLmV2ZXJ5LmJlZm9yZSBdLmNvbmNhdChfZmxhdHRlbihmbnMpKSA6IF9mbGF0dGVuKGZucyk7XG4gIGlmICh0aGlzLmV2ZXJ5ICYmIHRoaXMuZXZlcnkub24pIHtcbiAgICBydW5saXN0LnB1c2godGhpcy5ldmVyeS5vbik7XG4gIH1cbiAgcnVubGlzdC5jYXB0dXJlcyA9IGZucy5jYXB0dXJlcztcbiAgcnVubGlzdC5zb3VyY2UgPSBmbnMuc291cmNlO1xuICByZXR1cm4gcnVubGlzdDtcbn07XG5cblJvdXRlci5wcm90b3R5cGUubW91bnQgPSBmdW5jdGlvbihyb3V0ZXMsIHBhdGgpIHtcbiAgaWYgKCFyb3V0ZXMgfHwgdHlwZW9mIHJvdXRlcyAhPT0gXCJvYmplY3RcIiB8fCBBcnJheS5pc0FycmF5KHJvdXRlcykpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgdmFyIHNlbGYgPSB0aGlzO1xuICBwYXRoID0gcGF0aCB8fCBbXTtcbiAgaWYgKCFBcnJheS5pc0FycmF5KHBhdGgpKSB7XG4gICAgcGF0aCA9IHBhdGguc3BsaXQoc2VsZi5kZWxpbWl0ZXIpO1xuICB9XG4gIGZ1bmN0aW9uIGluc2VydE9yTW91bnQocm91dGUsIGxvY2FsKSB7XG4gICAgdmFyIHJlbmFtZSA9IHJvdXRlLCBwYXJ0cyA9IHJvdXRlLnNwbGl0KHNlbGYuZGVsaW1pdGVyKSwgcm91dGVUeXBlID0gdHlwZW9mIHJvdXRlc1tyb3V0ZV0sIGlzUm91dGUgPSBwYXJ0c1swXSA9PT0gXCJcIiB8fCAhc2VsZi5fbWV0aG9kc1twYXJ0c1swXV0sIGV2ZW50ID0gaXNSb3V0ZSA/IFwib25cIiA6IHJlbmFtZTtcbiAgICBpZiAoaXNSb3V0ZSkge1xuICAgICAgcmVuYW1lID0gcmVuYW1lLnNsaWNlKChyZW5hbWUubWF0Y2gobmV3IFJlZ0V4cChcIl5cIiArIHNlbGYuZGVsaW1pdGVyKSkgfHwgWyBcIlwiIF0pWzBdLmxlbmd0aCk7XG4gICAgICBwYXJ0cy5zaGlmdCgpO1xuICAgIH1cbiAgICBpZiAoaXNSb3V0ZSAmJiByb3V0ZVR5cGUgPT09IFwib2JqZWN0XCIgJiYgIUFycmF5LmlzQXJyYXkocm91dGVzW3JvdXRlXSkpIHtcbiAgICAgIGxvY2FsID0gbG9jYWwuY29uY2F0KHBhcnRzKTtcbiAgICAgIHNlbGYubW91bnQocm91dGVzW3JvdXRlXSwgbG9jYWwpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoaXNSb3V0ZSkge1xuICAgICAgbG9jYWwgPSBsb2NhbC5jb25jYXQocmVuYW1lLnNwbGl0KHNlbGYuZGVsaW1pdGVyKSk7XG4gICAgICBsb2NhbCA9IHRlcm1pbmF0b3IobG9jYWwsIHNlbGYuZGVsaW1pdGVyKTtcbiAgICB9XG4gICAgc2VsZi5pbnNlcnQoZXZlbnQsIGxvY2FsLCByb3V0ZXNbcm91dGVdKTtcbiAgfVxuICBmb3IgKHZhciByb3V0ZSBpbiByb3V0ZXMpIHtcbiAgICBpZiAocm91dGVzLmhhc093blByb3BlcnR5KHJvdXRlKSkge1xuICAgICAgaW5zZXJ0T3JNb3VudChyb3V0ZSwgcGF0aC5zbGljZSgwKSk7XG4gICAgfVxuICB9XG59O1xuXG5cblxufSh0eXBlb2YgZXhwb3J0cyA9PT0gXCJvYmplY3RcIiA/IGV4cG9ydHMgOiB3aW5kb3cpKTsiLCIvKiFcbiAgKiBkb21yZWFkeSAoYykgRHVzdGluIERpYXogMjAxNCAtIExpY2Vuc2UgTUlUXG4gICovXG4hZnVuY3Rpb24gKG5hbWUsIGRlZmluaXRpb24pIHtcblxuICBpZiAodHlwZW9mIG1vZHVsZSAhPSAndW5kZWZpbmVkJykgbW9kdWxlLmV4cG9ydHMgPSBkZWZpbml0aW9uKClcbiAgZWxzZSBpZiAodHlwZW9mIGRlZmluZSA9PSAnZnVuY3Rpb24nICYmIHR5cGVvZiBkZWZpbmUuYW1kID09ICdvYmplY3QnKSBkZWZpbmUoZGVmaW5pdGlvbilcbiAgZWxzZSB0aGlzW25hbWVdID0gZGVmaW5pdGlvbigpXG5cbn0oJ2RvbXJlYWR5JywgZnVuY3Rpb24gKCkge1xuXG4gIHZhciBmbnMgPSBbXSwgbGlzdGVuZXJcbiAgICAsIGRvYyA9IGRvY3VtZW50XG4gICAgLCBoYWNrID0gZG9jLmRvY3VtZW50RWxlbWVudC5kb1Njcm9sbFxuICAgICwgZG9tQ29udGVudExvYWRlZCA9ICdET01Db250ZW50TG9hZGVkJ1xuICAgICwgbG9hZGVkID0gKGhhY2sgPyAvXmxvYWRlZHxeYy8gOiAvXmxvYWRlZHxeaXxeYy8pLnRlc3QoZG9jLnJlYWR5U3RhdGUpXG5cblxuICBpZiAoIWxvYWRlZClcbiAgZG9jLmFkZEV2ZW50TGlzdGVuZXIoZG9tQ29udGVudExvYWRlZCwgbGlzdGVuZXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgZG9jLnJlbW92ZUV2ZW50TGlzdGVuZXIoZG9tQ29udGVudExvYWRlZCwgbGlzdGVuZXIpXG4gICAgbG9hZGVkID0gMVxuICAgIHdoaWxlIChsaXN0ZW5lciA9IGZucy5zaGlmdCgpKSBsaXN0ZW5lcigpXG4gIH0pXG5cbiAgcmV0dXJuIGZ1bmN0aW9uIChmbikge1xuICAgIGxvYWRlZCA/IHNldFRpbWVvdXQoZm4sIDApIDogZm5zLnB1c2goZm4pXG4gIH1cblxufSk7XG4iLCIvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy9cbi8vIFFSIENvZGUgR2VuZXJhdG9yIGZvciBKYXZhU2NyaXB0XG4vL1xuLy8gQ29weXJpZ2h0IChjKSAyMDA5IEthenVoaWtvIEFyYXNlXG4vL1xuLy8gVVJMOiBodHRwOi8vd3d3LmQtcHJvamVjdC5jb20vXG4vL1xuLy8gTGljZW5zZWQgdW5kZXIgdGhlIE1JVCBsaWNlbnNlOlxuLy9cdGh0dHA6Ly93d3cub3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvbWl0LWxpY2Vuc2UucGhwXG4vL1xuLy8gVGhlIHdvcmQgJ1FSIENvZGUnIGlzIHJlZ2lzdGVyZWQgdHJhZGVtYXJrIG9mXG4vLyBERU5TTyBXQVZFIElOQ09SUE9SQVRFRFxuLy9cdGh0dHA6Ly93d3cuZGVuc28td2F2ZS5jb20vcXJjb2RlL2ZhcXBhdGVudC1lLmh0bWxcbi8vXG4vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5leHBvcnRzLnFyY29kZSA9IGZ1bmN0aW9uKCkge1xuXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIHFyY29kZVxuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdC8qKlxuXHQgKiBxcmNvZGVcblx0ICogQHBhcmFtIHR5cGVOdW1iZXIgMSB0byAxMFxuXHQgKiBAcGFyYW0gZXJyb3JDb3JyZWN0TGV2ZWwgJ0wnLCdNJywnUScsJ0gnXG5cdCAqL1xuXHR2YXIgcXJjb2RlID0gZnVuY3Rpb24odHlwZU51bWJlciwgZXJyb3JDb3JyZWN0TGV2ZWwpIHtcblxuXHRcdHZhciBQQUQwID0gMHhFQztcblx0XHR2YXIgUEFEMSA9IDB4MTE7XG5cblx0XHR2YXIgX3R5cGVOdW1iZXIgPSB0eXBlTnVtYmVyO1xuXHRcdHZhciBfZXJyb3JDb3JyZWN0TGV2ZWwgPSBRUkVycm9yQ29ycmVjdExldmVsW2Vycm9yQ29ycmVjdExldmVsXTtcblx0XHR2YXIgX21vZHVsZXMgPSBudWxsO1xuXHRcdHZhciBfbW9kdWxlQ291bnQgPSAwO1xuXHRcdHZhciBfZGF0YUNhY2hlID0gbnVsbDtcblx0XHR2YXIgX2RhdGFMaXN0ID0gbmV3IEFycmF5KCk7XG5cblx0XHR2YXIgX3RoaXMgPSB7fTtcblxuXHRcdHZhciBtYWtlSW1wbCA9IGZ1bmN0aW9uKHRlc3QsIG1hc2tQYXR0ZXJuKSB7XG5cblx0XHRcdF9tb2R1bGVDb3VudCA9IF90eXBlTnVtYmVyICogNCArIDE3O1xuXHRcdFx0X21vZHVsZXMgPSBmdW5jdGlvbihtb2R1bGVDb3VudCkge1xuXHRcdFx0XHR2YXIgbW9kdWxlcyA9IG5ldyBBcnJheShtb2R1bGVDb3VudCk7XG5cdFx0XHRcdGZvciAodmFyIHJvdyA9IDA7IHJvdyA8IG1vZHVsZUNvdW50OyByb3cgKz0gMSkge1xuXHRcdFx0XHRcdG1vZHVsZXNbcm93XSA9IG5ldyBBcnJheShtb2R1bGVDb3VudCk7XG5cdFx0XHRcdFx0Zm9yICh2YXIgY29sID0gMDsgY29sIDwgbW9kdWxlQ291bnQ7IGNvbCArPSAxKSB7XG5cdFx0XHRcdFx0XHRtb2R1bGVzW3Jvd11bY29sXSA9IG51bGw7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBtb2R1bGVzO1xuXHRcdFx0fShfbW9kdWxlQ291bnQpO1xuXG5cdFx0XHRzZXR1cFBvc2l0aW9uUHJvYmVQYXR0ZXJuKDAsIDApO1xuXHRcdFx0c2V0dXBQb3NpdGlvblByb2JlUGF0dGVybihfbW9kdWxlQ291bnQgLSA3LCAwKTtcblx0XHRcdHNldHVwUG9zaXRpb25Qcm9iZVBhdHRlcm4oMCwgX21vZHVsZUNvdW50IC0gNyk7XG5cdFx0XHRzZXR1cFBvc2l0aW9uQWRqdXN0UGF0dGVybigpO1xuXHRcdFx0c2V0dXBUaW1pbmdQYXR0ZXJuKCk7XG5cdFx0XHRzZXR1cFR5cGVJbmZvKHRlc3QsIG1hc2tQYXR0ZXJuKTtcblxuXHRcdFx0aWYgKF90eXBlTnVtYmVyID49IDcpIHtcblx0XHRcdFx0c2V0dXBUeXBlTnVtYmVyKHRlc3QpO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoX2RhdGFDYWNoZSA9PSBudWxsKSB7XG5cdFx0XHRcdF9kYXRhQ2FjaGUgPSBjcmVhdGVEYXRhKF90eXBlTnVtYmVyLCBfZXJyb3JDb3JyZWN0TGV2ZWwsIF9kYXRhTGlzdCk7XG5cdFx0XHR9XG5cblx0XHRcdG1hcERhdGEoX2RhdGFDYWNoZSwgbWFza1BhdHRlcm4pO1xuXHRcdH07XG5cblx0XHR2YXIgc2V0dXBQb3NpdGlvblByb2JlUGF0dGVybiA9IGZ1bmN0aW9uKHJvdywgY29sKSB7XG5cblx0XHRcdGZvciAodmFyIHIgPSAtMTsgciA8PSA3OyByICs9IDEpIHtcblxuXHRcdFx0XHRpZiAocm93ICsgciA8PSAtMSB8fCBfbW9kdWxlQ291bnQgPD0gcm93ICsgcikgY29udGludWU7XG5cblx0XHRcdFx0Zm9yICh2YXIgYyA9IC0xOyBjIDw9IDc7IGMgKz0gMSkge1xuXG5cdFx0XHRcdFx0aWYgKGNvbCArIGMgPD0gLTEgfHwgX21vZHVsZUNvdW50IDw9IGNvbCArIGMpIGNvbnRpbnVlO1xuXG5cdFx0XHRcdFx0aWYgKCAoMCA8PSByICYmIHIgPD0gNiAmJiAoYyA9PSAwIHx8IGMgPT0gNikgKVxuXHRcdFx0XHRcdFx0XHR8fCAoMCA8PSBjICYmIGMgPD0gNiAmJiAociA9PSAwIHx8IHIgPT0gNikgKVxuXHRcdFx0XHRcdFx0XHR8fCAoMiA8PSByICYmIHIgPD0gNCAmJiAyIDw9IGMgJiYgYyA8PSA0KSApIHtcblx0XHRcdFx0XHRcdF9tb2R1bGVzW3JvdyArIHJdW2NvbCArIGNdID0gdHJ1ZTtcblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0X21vZHVsZXNbcm93ICsgcl1bY29sICsgY10gPSBmYWxzZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0dmFyIGdldEJlc3RNYXNrUGF0dGVybiA9IGZ1bmN0aW9uKCkge1xuXG5cdFx0XHR2YXIgbWluTG9zdFBvaW50ID0gMDtcblx0XHRcdHZhciBwYXR0ZXJuID0gMDtcblxuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCA4OyBpICs9IDEpIHtcblxuXHRcdFx0XHRtYWtlSW1wbCh0cnVlLCBpKTtcblxuXHRcdFx0XHR2YXIgbG9zdFBvaW50ID0gUVJVdGlsLmdldExvc3RQb2ludChfdGhpcyk7XG5cblx0XHRcdFx0aWYgKGkgPT0gMCB8fCBtaW5Mb3N0UG9pbnQgPiBsb3N0UG9pbnQpIHtcblx0XHRcdFx0XHRtaW5Mb3N0UG9pbnQgPSBsb3N0UG9pbnQ7XG5cdFx0XHRcdFx0cGF0dGVybiA9IGk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0cmV0dXJuIHBhdHRlcm47XG5cdFx0fTtcblxuXHRcdHZhciBzZXR1cFRpbWluZ1BhdHRlcm4gPSBmdW5jdGlvbigpIHtcblxuXHRcdFx0Zm9yICh2YXIgciA9IDg7IHIgPCBfbW9kdWxlQ291bnQgLSA4OyByICs9IDEpIHtcblx0XHRcdFx0aWYgKF9tb2R1bGVzW3JdWzZdICE9IG51bGwpIHtcblx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0fVxuXHRcdFx0XHRfbW9kdWxlc1tyXVs2XSA9IChyICUgMiA9PSAwKTtcblx0XHRcdH1cblxuXHRcdFx0Zm9yICh2YXIgYyA9IDg7IGMgPCBfbW9kdWxlQ291bnQgLSA4OyBjICs9IDEpIHtcblx0XHRcdFx0aWYgKF9tb2R1bGVzWzZdW2NdICE9IG51bGwpIHtcblx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0fVxuXHRcdFx0XHRfbW9kdWxlc1s2XVtjXSA9IChjICUgMiA9PSAwKTtcblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0dmFyIHNldHVwUG9zaXRpb25BZGp1c3RQYXR0ZXJuID0gZnVuY3Rpb24oKSB7XG5cblx0XHRcdHZhciBwb3MgPSBRUlV0aWwuZ2V0UGF0dGVyblBvc2l0aW9uKF90eXBlTnVtYmVyKTtcblxuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBwb3MubGVuZ3RoOyBpICs9IDEpIHtcblxuXHRcdFx0XHRmb3IgKHZhciBqID0gMDsgaiA8IHBvcy5sZW5ndGg7IGogKz0gMSkge1xuXG5cdFx0XHRcdFx0dmFyIHJvdyA9IHBvc1tpXTtcblx0XHRcdFx0XHR2YXIgY29sID0gcG9zW2pdO1xuXG5cdFx0XHRcdFx0aWYgKF9tb2R1bGVzW3Jvd11bY29sXSAhPSBudWxsKSB7XG5cdFx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRmb3IgKHZhciByID0gLTI7IHIgPD0gMjsgciArPSAxKSB7XG5cblx0XHRcdFx0XHRcdGZvciAodmFyIGMgPSAtMjsgYyA8PSAyOyBjICs9IDEpIHtcblxuXHRcdFx0XHRcdFx0XHRpZiAociA9PSAtMiB8fCByID09IDIgfHwgYyA9PSAtMiB8fCBjID09IDJcblx0XHRcdFx0XHRcdFx0XHRcdHx8IChyID09IDAgJiYgYyA9PSAwKSApIHtcblx0XHRcdFx0XHRcdFx0XHRfbW9kdWxlc1tyb3cgKyByXVtjb2wgKyBjXSA9IHRydWU7XG5cdFx0XHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRcdFx0X21vZHVsZXNbcm93ICsgcl1bY29sICsgY10gPSBmYWxzZTtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH07XG5cblx0XHR2YXIgc2V0dXBUeXBlTnVtYmVyID0gZnVuY3Rpb24odGVzdCkge1xuXG5cdFx0XHR2YXIgYml0cyA9IFFSVXRpbC5nZXRCQ0hUeXBlTnVtYmVyKF90eXBlTnVtYmVyKTtcblxuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCAxODsgaSArPSAxKSB7XG5cdFx0XHRcdHZhciBtb2QgPSAoIXRlc3QgJiYgKCAoYml0cyA+PiBpKSAmIDEpID09IDEpO1xuXHRcdFx0XHRfbW9kdWxlc1tNYXRoLmZsb29yKGkgLyAzKV1baSAlIDMgKyBfbW9kdWxlQ291bnQgLSA4IC0gM10gPSBtb2Q7XG5cdFx0XHR9XG5cblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgMTg7IGkgKz0gMSkge1xuXHRcdFx0XHR2YXIgbW9kID0gKCF0ZXN0ICYmICggKGJpdHMgPj4gaSkgJiAxKSA9PSAxKTtcblx0XHRcdFx0X21vZHVsZXNbaSAlIDMgKyBfbW9kdWxlQ291bnQgLSA4IC0gM11bTWF0aC5mbG9vcihpIC8gMyldID0gbW9kO1xuXHRcdFx0fVxuXHRcdH07XG5cblx0XHR2YXIgc2V0dXBUeXBlSW5mbyA9IGZ1bmN0aW9uKHRlc3QsIG1hc2tQYXR0ZXJuKSB7XG5cblx0XHRcdHZhciBkYXRhID0gKF9lcnJvckNvcnJlY3RMZXZlbCA8PCAzKSB8IG1hc2tQYXR0ZXJuO1xuXHRcdFx0dmFyIGJpdHMgPSBRUlV0aWwuZ2V0QkNIVHlwZUluZm8oZGF0YSk7XG5cblx0XHRcdC8vIHZlcnRpY2FsXG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IDE1OyBpICs9IDEpIHtcblxuXHRcdFx0XHR2YXIgbW9kID0gKCF0ZXN0ICYmICggKGJpdHMgPj4gaSkgJiAxKSA9PSAxKTtcblxuXHRcdFx0XHRpZiAoaSA8IDYpIHtcblx0XHRcdFx0XHRfbW9kdWxlc1tpXVs4XSA9IG1vZDtcblx0XHRcdFx0fSBlbHNlIGlmIChpIDwgOCkge1xuXHRcdFx0XHRcdF9tb2R1bGVzW2kgKyAxXVs4XSA9IG1vZDtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRfbW9kdWxlc1tfbW9kdWxlQ291bnQgLSAxNSArIGldWzhdID0gbW9kO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIGhvcml6b250YWxcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgMTU7IGkgKz0gMSkge1xuXG5cdFx0XHRcdHZhciBtb2QgPSAoIXRlc3QgJiYgKCAoYml0cyA+PiBpKSAmIDEpID09IDEpO1xuXG5cdFx0XHRcdGlmIChpIDwgOCkge1xuXHRcdFx0XHRcdF9tb2R1bGVzWzhdW19tb2R1bGVDb3VudCAtIGkgLSAxXSA9IG1vZDtcblx0XHRcdFx0fSBlbHNlIGlmIChpIDwgOSkge1xuXHRcdFx0XHRcdF9tb2R1bGVzWzhdWzE1IC0gaSAtIDEgKyAxXSA9IG1vZDtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRfbW9kdWxlc1s4XVsxNSAtIGkgLSAxXSA9IG1vZDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQvLyBmaXhlZCBtb2R1bGVcblx0XHRcdF9tb2R1bGVzW19tb2R1bGVDb3VudCAtIDhdWzhdID0gKCF0ZXN0KTtcblx0XHR9O1xuXG5cdFx0dmFyIG1hcERhdGEgPSBmdW5jdGlvbihkYXRhLCBtYXNrUGF0dGVybikge1xuXG5cdFx0XHR2YXIgaW5jID0gLTE7XG5cdFx0XHR2YXIgcm93ID0gX21vZHVsZUNvdW50IC0gMTtcblx0XHRcdHZhciBiaXRJbmRleCA9IDc7XG5cdFx0XHR2YXIgYnl0ZUluZGV4ID0gMDtcblx0XHRcdHZhciBtYXNrRnVuYyA9IFFSVXRpbC5nZXRNYXNrRnVuY3Rpb24obWFza1BhdHRlcm4pO1xuXG5cdFx0XHRmb3IgKHZhciBjb2wgPSBfbW9kdWxlQ291bnQgLSAxOyBjb2wgPiAwOyBjb2wgLT0gMikge1xuXG5cdFx0XHRcdGlmIChjb2wgPT0gNikgY29sIC09IDE7XG5cblx0XHRcdFx0d2hpbGUgKHRydWUpIHtcblxuXHRcdFx0XHRcdGZvciAodmFyIGMgPSAwOyBjIDwgMjsgYyArPSAxKSB7XG5cblx0XHRcdFx0XHRcdGlmIChfbW9kdWxlc1tyb3ddW2NvbCAtIGNdID09IG51bGwpIHtcblxuXHRcdFx0XHRcdFx0XHR2YXIgZGFyayA9IGZhbHNlO1xuXG5cdFx0XHRcdFx0XHRcdGlmIChieXRlSW5kZXggPCBkYXRhLmxlbmd0aCkge1xuXHRcdFx0XHRcdFx0XHRcdGRhcmsgPSAoICggKGRhdGFbYnl0ZUluZGV4XSA+Pj4gYml0SW5kZXgpICYgMSkgPT0gMSk7XG5cdFx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0XHR2YXIgbWFzayA9IG1hc2tGdW5jKHJvdywgY29sIC0gYyk7XG5cblx0XHRcdFx0XHRcdFx0aWYgKG1hc2spIHtcblx0XHRcdFx0XHRcdFx0XHRkYXJrID0gIWRhcms7XG5cdFx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0XHRfbW9kdWxlc1tyb3ddW2NvbCAtIGNdID0gZGFyaztcblx0XHRcdFx0XHRcdFx0Yml0SW5kZXggLT0gMTtcblxuXHRcdFx0XHRcdFx0XHRpZiAoYml0SW5kZXggPT0gLTEpIHtcblx0XHRcdFx0XHRcdFx0XHRieXRlSW5kZXggKz0gMTtcblx0XHRcdFx0XHRcdFx0XHRiaXRJbmRleCA9IDc7XG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRyb3cgKz0gaW5jO1xuXG5cdFx0XHRcdFx0aWYgKHJvdyA8IDAgfHwgX21vZHVsZUNvdW50IDw9IHJvdykge1xuXHRcdFx0XHRcdFx0cm93IC09IGluYztcblx0XHRcdFx0XHRcdGluYyA9IC1pbmM7XG5cdFx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0dmFyIGNyZWF0ZUJ5dGVzID0gZnVuY3Rpb24oYnVmZmVyLCByc0Jsb2Nrcykge1xuXG5cdFx0XHR2YXIgb2Zmc2V0ID0gMDtcblxuXHRcdFx0dmFyIG1heERjQ291bnQgPSAwO1xuXHRcdFx0dmFyIG1heEVjQ291bnQgPSAwO1xuXG5cdFx0XHR2YXIgZGNkYXRhID0gbmV3IEFycmF5KHJzQmxvY2tzLmxlbmd0aCk7XG5cdFx0XHR2YXIgZWNkYXRhID0gbmV3IEFycmF5KHJzQmxvY2tzLmxlbmd0aCk7XG5cblx0XHRcdGZvciAodmFyIHIgPSAwOyByIDwgcnNCbG9ja3MubGVuZ3RoOyByICs9IDEpIHtcblxuXHRcdFx0XHR2YXIgZGNDb3VudCA9IHJzQmxvY2tzW3JdLmRhdGFDb3VudDtcblx0XHRcdFx0dmFyIGVjQ291bnQgPSByc0Jsb2Nrc1tyXS50b3RhbENvdW50IC0gZGNDb3VudDtcblxuXHRcdFx0XHRtYXhEY0NvdW50ID0gTWF0aC5tYXgobWF4RGNDb3VudCwgZGNDb3VudCk7XG5cdFx0XHRcdG1heEVjQ291bnQgPSBNYXRoLm1heChtYXhFY0NvdW50LCBlY0NvdW50KTtcblxuXHRcdFx0XHRkY2RhdGFbcl0gPSBuZXcgQXJyYXkoZGNDb3VudCk7XG5cblx0XHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBkY2RhdGFbcl0ubGVuZ3RoOyBpICs9IDEpIHtcblx0XHRcdFx0XHRkY2RhdGFbcl1baV0gPSAweGZmICYgYnVmZmVyLmdldEJ1ZmZlcigpW2kgKyBvZmZzZXRdO1xuXHRcdFx0XHR9XG5cdFx0XHRcdG9mZnNldCArPSBkY0NvdW50O1xuXG5cdFx0XHRcdHZhciByc1BvbHkgPSBRUlV0aWwuZ2V0RXJyb3JDb3JyZWN0UG9seW5vbWlhbChlY0NvdW50KTtcblx0XHRcdFx0dmFyIHJhd1BvbHkgPSBxclBvbHlub21pYWwoZGNkYXRhW3JdLCByc1BvbHkuZ2V0TGVuZ3RoKCkgLSAxKTtcblxuXHRcdFx0XHR2YXIgbW9kUG9seSA9IHJhd1BvbHkubW9kKHJzUG9seSk7XG5cdFx0XHRcdGVjZGF0YVtyXSA9IG5ldyBBcnJheShyc1BvbHkuZ2V0TGVuZ3RoKCkgLSAxKTtcblx0XHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBlY2RhdGFbcl0ubGVuZ3RoOyBpICs9IDEpIHtcblx0XHRcdFx0XHR2YXIgbW9kSW5kZXggPSBpICsgbW9kUG9seS5nZXRMZW5ndGgoKSAtIGVjZGF0YVtyXS5sZW5ndGg7XG5cdFx0XHRcdFx0ZWNkYXRhW3JdW2ldID0gKG1vZEluZGV4ID49IDApPyBtb2RQb2x5LmdldChtb2RJbmRleCkgOiAwO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdHZhciB0b3RhbENvZGVDb3VudCA9IDA7XG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHJzQmxvY2tzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRcdHRvdGFsQ29kZUNvdW50ICs9IHJzQmxvY2tzW2ldLnRvdGFsQ291bnQ7XG5cdFx0XHR9XG5cblx0XHRcdHZhciBkYXRhID0gbmV3IEFycmF5KHRvdGFsQ29kZUNvdW50KTtcblx0XHRcdHZhciBpbmRleCA9IDA7XG5cblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgbWF4RGNDb3VudDsgaSArPSAxKSB7XG5cdFx0XHRcdGZvciAodmFyIHIgPSAwOyByIDwgcnNCbG9ja3MubGVuZ3RoOyByICs9IDEpIHtcblx0XHRcdFx0XHRpZiAoaSA8IGRjZGF0YVtyXS5sZW5ndGgpIHtcblx0XHRcdFx0XHRcdGRhdGFbaW5kZXhdID0gZGNkYXRhW3JdW2ldO1xuXHRcdFx0XHRcdFx0aW5kZXggKz0gMTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBtYXhFY0NvdW50OyBpICs9IDEpIHtcblx0XHRcdFx0Zm9yICh2YXIgciA9IDA7IHIgPCByc0Jsb2Nrcy5sZW5ndGg7IHIgKz0gMSkge1xuXHRcdFx0XHRcdGlmIChpIDwgZWNkYXRhW3JdLmxlbmd0aCkge1xuXHRcdFx0XHRcdFx0ZGF0YVtpbmRleF0gPSBlY2RhdGFbcl1baV07XG5cdFx0XHRcdFx0XHRpbmRleCArPSAxO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gZGF0YTtcblx0XHR9O1xuXG5cdFx0dmFyIGNyZWF0ZURhdGEgPSBmdW5jdGlvbih0eXBlTnVtYmVyLCBlcnJvckNvcnJlY3RMZXZlbCwgZGF0YUxpc3QpIHtcblxuXHRcdFx0dmFyIHJzQmxvY2tzID0gUVJSU0Jsb2NrLmdldFJTQmxvY2tzKHR5cGVOdW1iZXIsIGVycm9yQ29ycmVjdExldmVsKTtcblxuXHRcdFx0dmFyIGJ1ZmZlciA9IHFyQml0QnVmZmVyKCk7XG5cblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgZGF0YUxpc3QubGVuZ3RoOyBpICs9IDEpIHtcblx0XHRcdFx0dmFyIGRhdGEgPSBkYXRhTGlzdFtpXTtcblx0XHRcdFx0YnVmZmVyLnB1dChkYXRhLmdldE1vZGUoKSwgNCk7XG5cdFx0XHRcdGJ1ZmZlci5wdXQoZGF0YS5nZXRMZW5ndGgoKSwgUVJVdGlsLmdldExlbmd0aEluQml0cyhkYXRhLmdldE1vZGUoKSwgdHlwZU51bWJlcikgKTtcblx0XHRcdFx0ZGF0YS53cml0ZShidWZmZXIpO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBjYWxjIG51bSBtYXggZGF0YS5cblx0XHRcdHZhciB0b3RhbERhdGFDb3VudCA9IDA7XG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHJzQmxvY2tzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRcdHRvdGFsRGF0YUNvdW50ICs9IHJzQmxvY2tzW2ldLmRhdGFDb3VudDtcblx0XHRcdH1cblxuXHRcdFx0aWYgKGJ1ZmZlci5nZXRMZW5ndGhJbkJpdHMoKSA+IHRvdGFsRGF0YUNvdW50ICogOCkge1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ2NvZGUgbGVuZ3RoIG92ZXJmbG93LiAoJ1xuXHRcdFx0XHRcdCsgYnVmZmVyLmdldExlbmd0aEluQml0cygpXG5cdFx0XHRcdFx0KyAnPidcblx0XHRcdFx0XHQrIHRvdGFsRGF0YUNvdW50ICogOFxuXHRcdFx0XHRcdCsgJyknKTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gZW5kIGNvZGVcblx0XHRcdGlmIChidWZmZXIuZ2V0TGVuZ3RoSW5CaXRzKCkgKyA0IDw9IHRvdGFsRGF0YUNvdW50ICogOCkge1xuXHRcdFx0XHRidWZmZXIucHV0KDAsIDQpO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBwYWRkaW5nXG5cdFx0XHR3aGlsZSAoYnVmZmVyLmdldExlbmd0aEluQml0cygpICUgOCAhPSAwKSB7XG5cdFx0XHRcdGJ1ZmZlci5wdXRCaXQoZmFsc2UpO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBwYWRkaW5nXG5cdFx0XHR3aGlsZSAodHJ1ZSkge1xuXG5cdFx0XHRcdGlmIChidWZmZXIuZ2V0TGVuZ3RoSW5CaXRzKCkgPj0gdG90YWxEYXRhQ291bnQgKiA4KSB7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdH1cblx0XHRcdFx0YnVmZmVyLnB1dChQQUQwLCA4KTtcblxuXHRcdFx0XHRpZiAoYnVmZmVyLmdldExlbmd0aEluQml0cygpID49IHRvdGFsRGF0YUNvdW50ICogOCkge1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGJ1ZmZlci5wdXQoUEFEMSwgOCk7XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiBjcmVhdGVCeXRlcyhidWZmZXIsIHJzQmxvY2tzKTtcblx0XHR9O1xuXG5cdFx0X3RoaXMuYWRkRGF0YSA9IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRcdHZhciBuZXdEYXRhID0gcXI4Qml0Qnl0ZShkYXRhKTtcblx0XHRcdF9kYXRhTGlzdC5wdXNoKG5ld0RhdGEpO1xuXHRcdFx0X2RhdGFDYWNoZSA9IG51bGw7XG5cdFx0fTtcblxuXHRcdF90aGlzLmlzRGFyayA9IGZ1bmN0aW9uKHJvdywgY29sKSB7XG5cdFx0XHRpZiAocm93IDwgMCB8fCBfbW9kdWxlQ291bnQgPD0gcm93IHx8IGNvbCA8IDAgfHwgX21vZHVsZUNvdW50IDw9IGNvbCkge1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3Iocm93ICsgJywnICsgY29sKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBfbW9kdWxlc1tyb3ddW2NvbF07XG5cdFx0fTtcblxuXHRcdF90aGlzLmdldE1vZHVsZUNvdW50ID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRyZXR1cm4gX21vZHVsZUNvdW50O1xuXHRcdH07XG5cblx0XHRfdGhpcy5tYWtlID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRtYWtlSW1wbChmYWxzZSwgZ2V0QmVzdE1hc2tQYXR0ZXJuKCkgKTtcblx0XHR9O1xuXG5cdFx0X3RoaXMuY3JlYXRlVGFibGVUYWcgPSBmdW5jdGlvbihjZWxsU2l6ZSwgbWFyZ2luKSB7XG5cblx0XHRcdGNlbGxTaXplID0gY2VsbFNpemUgfHwgMjtcblx0XHRcdG1hcmdpbiA9ICh0eXBlb2YgbWFyZ2luID09ICd1bmRlZmluZWQnKT8gY2VsbFNpemUgKiA0IDogbWFyZ2luO1xuXG5cdFx0XHR2YXIgcXJIdG1sID0gJyc7XG5cblx0XHRcdHFySHRtbCArPSAnPHRhYmxlIHN0eWxlPVwiJztcblx0XHRcdHFySHRtbCArPSAnIGJvcmRlci13aWR0aDogMHB4OyBib3JkZXItc3R5bGU6IG5vbmU7Jztcblx0XHRcdHFySHRtbCArPSAnIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7Jztcblx0XHRcdHFySHRtbCArPSAnIHBhZGRpbmc6IDBweDsgbWFyZ2luOiAnICsgbWFyZ2luICsgJ3B4Oyc7XG5cdFx0XHRxckh0bWwgKz0gJ1wiPic7XG5cdFx0XHRxckh0bWwgKz0gJzx0Ym9keT4nO1xuXG5cdFx0XHRmb3IgKHZhciByID0gMDsgciA8IF90aGlzLmdldE1vZHVsZUNvdW50KCk7IHIgKz0gMSkge1xuXG5cdFx0XHRcdHFySHRtbCArPSAnPHRyPic7XG5cblx0XHRcdFx0Zm9yICh2YXIgYyA9IDA7IGMgPCBfdGhpcy5nZXRNb2R1bGVDb3VudCgpOyBjICs9IDEpIHtcblx0XHRcdFx0XHRxckh0bWwgKz0gJzx0ZCBzdHlsZT1cIic7XG5cdFx0XHRcdFx0cXJIdG1sICs9ICcgYm9yZGVyLXdpZHRoOiAwcHg7IGJvcmRlci1zdHlsZTogbm9uZTsnO1xuXHRcdFx0XHRcdHFySHRtbCArPSAnIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7Jztcblx0XHRcdFx0XHRxckh0bWwgKz0gJyBwYWRkaW5nOiAwcHg7IG1hcmdpbjogMHB4Oyc7XG5cdFx0XHRcdFx0cXJIdG1sICs9ICcgd2lkdGg6ICcgKyBjZWxsU2l6ZSArICdweDsnO1xuXHRcdFx0XHRcdHFySHRtbCArPSAnIGhlaWdodDogJyArIGNlbGxTaXplICsgJ3B4Oyc7XG5cdFx0XHRcdFx0cXJIdG1sICs9ICcgYmFja2dyb3VuZC1jb2xvcjogJztcblx0XHRcdFx0XHRxckh0bWwgKz0gX3RoaXMuaXNEYXJrKHIsIGMpPyAnIzAwMDAwMCcgOiAnI2ZmZmZmZic7XG5cdFx0XHRcdFx0cXJIdG1sICs9ICc7Jztcblx0XHRcdFx0XHRxckh0bWwgKz0gJ1wiLz4nO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cXJIdG1sICs9ICc8L3RyPic7XG5cdFx0XHR9XG5cblx0XHRcdHFySHRtbCArPSAnPC90Ym9keT4nO1xuXHRcdFx0cXJIdG1sICs9ICc8L3RhYmxlPic7XG5cblx0XHRcdHJldHVybiBxckh0bWw7XG5cdFx0fTtcblxuXHRcdF90aGlzLmNyZWF0ZUltZ1RhZyA9IGZ1bmN0aW9uKGNlbGxTaXplLCBtYXJnaW4pIHtcblxuXHRcdFx0Y2VsbFNpemUgPSBjZWxsU2l6ZSB8fCAyO1xuXHRcdFx0bWFyZ2luID0gKHR5cGVvZiBtYXJnaW4gPT0gJ3VuZGVmaW5lZCcpPyBjZWxsU2l6ZSAqIDQgOiBtYXJnaW47XG5cblx0XHRcdHZhciBzaXplID0gX3RoaXMuZ2V0TW9kdWxlQ291bnQoKSAqIGNlbGxTaXplICsgbWFyZ2luICogMjtcblx0XHRcdHZhciBtaW4gPSBtYXJnaW47XG5cdFx0XHR2YXIgbWF4ID0gc2l6ZSAtIG1hcmdpbjtcblxuXHRcdFx0cmV0dXJuIGNyZWF0ZUltZ1RhZyhzaXplLCBzaXplLCBmdW5jdGlvbih4LCB5KSB7XG5cdFx0XHRcdGlmIChtaW4gPD0geCAmJiB4IDwgbWF4ICYmIG1pbiA8PSB5ICYmIHkgPCBtYXgpIHtcblx0XHRcdFx0XHR2YXIgYyA9IE1hdGguZmxvb3IoICh4IC0gbWluKSAvIGNlbGxTaXplKTtcblx0XHRcdFx0XHR2YXIgciA9IE1hdGguZmxvb3IoICh5IC0gbWluKSAvIGNlbGxTaXplKTtcblx0XHRcdFx0XHRyZXR1cm4gX3RoaXMuaXNEYXJrKHIsIGMpPyAwIDogMTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRyZXR1cm4gMTtcblx0XHRcdFx0fVxuXHRcdFx0fSApO1xuXHRcdH07XG5cblx0XHRyZXR1cm4gX3RoaXM7XG5cdH07XG5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gcXJjb2RlLnN0cmluZ1RvQnl0ZXNcblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRxcmNvZGUuc3RyaW5nVG9CeXRlcyA9IGZ1bmN0aW9uKHMpIHtcblx0XHR2YXIgYnl0ZXMgPSBuZXcgQXJyYXkoKTtcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHMubGVuZ3RoOyBpICs9IDEpIHtcblx0XHRcdHZhciBjID0gcy5jaGFyQ29kZUF0KGkpO1xuXHRcdFx0Ynl0ZXMucHVzaChjICYgMHhmZik7XG5cdFx0fVxuXHRcdHJldHVybiBieXRlcztcblx0fTtcblxuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBxcmNvZGUuY3JlYXRlU3RyaW5nVG9CeXRlc1xuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdC8qKlxuXHQgKiBAcGFyYW0gdW5pY29kZURhdGEgYmFzZTY0IHN0cmluZyBvZiBieXRlIGFycmF5LlxuXHQgKiBbMTZiaXQgVW5pY29kZV0sWzE2Yml0IEJ5dGVzXSwgLi4uXG5cdCAqIEBwYXJhbSBudW1DaGFyc1xuXHQgKi9cblx0cXJjb2RlLmNyZWF0ZVN0cmluZ1RvQnl0ZXMgPSBmdW5jdGlvbih1bmljb2RlRGF0YSwgbnVtQ2hhcnMpIHtcblxuXHRcdC8vIGNyZWF0ZSBjb252ZXJzaW9uIG1hcC5cblxuXHRcdHZhciB1bmljb2RlTWFwID0gZnVuY3Rpb24oKSB7XG5cblx0XHRcdHZhciBiaW4gPSBiYXNlNjREZWNvZGVJbnB1dFN0cmVhbSh1bmljb2RlRGF0YSk7XG5cdFx0XHR2YXIgcmVhZCA9IGZ1bmN0aW9uKCkge1xuXHRcdFx0XHR2YXIgYiA9IGJpbi5yZWFkKCk7XG5cdFx0XHRcdGlmIChiID09IC0xKSB0aHJvdyBuZXcgRXJyb3IoKTtcblx0XHRcdFx0cmV0dXJuIGI7XG5cdFx0XHR9O1xuXG5cdFx0XHR2YXIgY291bnQgPSAwO1xuXHRcdFx0dmFyIHVuaWNvZGVNYXAgPSB7fTtcblx0XHRcdHdoaWxlICh0cnVlKSB7XG5cdFx0XHRcdHZhciBiMCA9IGJpbi5yZWFkKCk7XG5cdFx0XHRcdGlmIChiMCA9PSAtMSkgYnJlYWs7XG5cdFx0XHRcdHZhciBiMSA9IHJlYWQoKTtcblx0XHRcdFx0dmFyIGIyID0gcmVhZCgpO1xuXHRcdFx0XHR2YXIgYjMgPSByZWFkKCk7XG5cdFx0XHRcdHZhciBrID0gU3RyaW5nLmZyb21DaGFyQ29kZSggKGIwIDw8IDgpIHwgYjEpO1xuXHRcdFx0XHR2YXIgdiA9IChiMiA8PCA4KSB8IGIzO1xuXHRcdFx0XHR1bmljb2RlTWFwW2tdID0gdjtcblx0XHRcdFx0Y291bnQgKz0gMTtcblx0XHRcdH1cblx0XHRcdGlmIChjb3VudCAhPSBudW1DaGFycykge1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoY291bnQgKyAnICE9ICcgKyBudW1DaGFycyk7XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiB1bmljb2RlTWFwO1xuXHRcdH0oKTtcblxuXHRcdHZhciB1bmtub3duQ2hhciA9ICc/Jy5jaGFyQ29kZUF0KDApO1xuXG5cdFx0cmV0dXJuIGZ1bmN0aW9uKHMpIHtcblx0XHRcdHZhciBieXRlcyA9IG5ldyBBcnJheSgpO1xuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRcdHZhciBjID0gcy5jaGFyQ29kZUF0KGkpO1xuXHRcdFx0XHRpZiAoYyA8IDEyOCkge1xuXHRcdFx0XHRcdGJ5dGVzLnB1c2goYyk7XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0dmFyIGIgPSB1bmljb2RlTWFwW3MuY2hhckF0KGkpXTtcblx0XHRcdFx0XHRpZiAodHlwZW9mIGIgPT0gJ251bWJlcicpIHtcblx0XHRcdFx0XHRcdGlmICggKGIgJiAweGZmKSA9PSBiKSB7XG5cdFx0XHRcdFx0XHRcdC8vIDFieXRlXG5cdFx0XHRcdFx0XHRcdGJ5dGVzLnB1c2goYik7XG5cdFx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0XHQvLyAyYnl0ZXNcblx0XHRcdFx0XHRcdFx0Ynl0ZXMucHVzaChiID4+PiA4KTtcblx0XHRcdFx0XHRcdFx0Ynl0ZXMucHVzaChiICYgMHhmZik7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGJ5dGVzLnB1c2godW5rbm93bkNoYXIpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGJ5dGVzO1xuXHRcdH07XG5cdH07XG5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gUVJNb2RlXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0dmFyIFFSTW9kZSA9IHtcblx0XHRNT0RFX05VTUJFUiA6XHRcdDEgPDwgMCxcblx0XHRNT0RFX0FMUEhBX05VTSA6IFx0MSA8PCAxLFxuXHRcdE1PREVfOEJJVF9CWVRFIDogXHQxIDw8IDIsXG5cdFx0TU9ERV9LQU5KSSA6XHRcdDEgPDwgM1xuXHR9O1xuXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFFSRXJyb3JDb3JyZWN0TGV2ZWxcblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR2YXIgUVJFcnJvckNvcnJlY3RMZXZlbCA9IHtcblx0XHRMIDogMSxcblx0XHRNIDogMCxcblx0XHRRIDogMyxcblx0XHRIIDogMlxuXHR9O1xuXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFFSTWFza1BhdHRlcm5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR2YXIgUVJNYXNrUGF0dGVybiA9IHtcblx0XHRQQVRURVJOMDAwIDogMCxcblx0XHRQQVRURVJOMDAxIDogMSxcblx0XHRQQVRURVJOMDEwIDogMixcblx0XHRQQVRURVJOMDExIDogMyxcblx0XHRQQVRURVJOMTAwIDogNCxcblx0XHRQQVRURVJOMTAxIDogNSxcblx0XHRQQVRURVJOMTEwIDogNixcblx0XHRQQVRURVJOMTExIDogN1xuXHR9O1xuXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFFSVXRpbFxuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdHZhciBRUlV0aWwgPSBmdW5jdGlvbigpIHtcblxuXHRcdHZhciBQQVRURVJOX1BPU0lUSU9OX1RBQkxFID0gW1xuXHRcdFx0W10sXG5cdFx0XHRbNiwgMThdLFxuXHRcdFx0WzYsIDIyXSxcblx0XHRcdFs2LCAyNl0sXG5cdFx0XHRbNiwgMzBdLFxuXHRcdFx0WzYsIDM0XSxcblx0XHRcdFs2LCAyMiwgMzhdLFxuXHRcdFx0WzYsIDI0LCA0Ml0sXG5cdFx0XHRbNiwgMjYsIDQ2XSxcblx0XHRcdFs2LCAyOCwgNTBdLFxuXHRcdFx0WzYsIDMwLCA1NF0sXG5cdFx0XHRbNiwgMzIsIDU4XSxcblx0XHRcdFs2LCAzNCwgNjJdLFxuXHRcdFx0WzYsIDI2LCA0NiwgNjZdLFxuXHRcdFx0WzYsIDI2LCA0OCwgNzBdLFxuXHRcdFx0WzYsIDI2LCA1MCwgNzRdLFxuXHRcdFx0WzYsIDMwLCA1NCwgNzhdLFxuXHRcdFx0WzYsIDMwLCA1NiwgODJdLFxuXHRcdFx0WzYsIDMwLCA1OCwgODZdLFxuXHRcdFx0WzYsIDM0LCA2MiwgOTBdLFxuXHRcdFx0WzYsIDI4LCA1MCwgNzIsIDk0XSxcblx0XHRcdFs2LCAyNiwgNTAsIDc0LCA5OF0sXG5cdFx0XHRbNiwgMzAsIDU0LCA3OCwgMTAyXSxcblx0XHRcdFs2LCAyOCwgNTQsIDgwLCAxMDZdLFxuXHRcdFx0WzYsIDMyLCA1OCwgODQsIDExMF0sXG5cdFx0XHRbNiwgMzAsIDU4LCA4NiwgMTE0XSxcblx0XHRcdFs2LCAzNCwgNjIsIDkwLCAxMThdLFxuXHRcdFx0WzYsIDI2LCA1MCwgNzQsIDk4LCAxMjJdLFxuXHRcdFx0WzYsIDMwLCA1NCwgNzgsIDEwMiwgMTI2XSxcblx0XHRcdFs2LCAyNiwgNTIsIDc4LCAxMDQsIDEzMF0sXG5cdFx0XHRbNiwgMzAsIDU2LCA4MiwgMTA4LCAxMzRdLFxuXHRcdFx0WzYsIDM0LCA2MCwgODYsIDExMiwgMTM4XSxcblx0XHRcdFs2LCAzMCwgNTgsIDg2LCAxMTQsIDE0Ml0sXG5cdFx0XHRbNiwgMzQsIDYyLCA5MCwgMTE4LCAxNDZdLFxuXHRcdFx0WzYsIDMwLCA1NCwgNzgsIDEwMiwgMTI2LCAxNTBdLFxuXHRcdFx0WzYsIDI0LCA1MCwgNzYsIDEwMiwgMTI4LCAxNTRdLFxuXHRcdFx0WzYsIDI4LCA1NCwgODAsIDEwNiwgMTMyLCAxNThdLFxuXHRcdFx0WzYsIDMyLCA1OCwgODQsIDExMCwgMTM2LCAxNjJdLFxuXHRcdFx0WzYsIDI2LCA1NCwgODIsIDExMCwgMTM4LCAxNjZdLFxuXHRcdFx0WzYsIDMwLCA1OCwgODYsIDExNCwgMTQyLCAxNzBdXG5cdFx0XTtcblx0XHR2YXIgRzE1ID0gKDEgPDwgMTApIHwgKDEgPDwgOCkgfCAoMSA8PCA1KSB8ICgxIDw8IDQpIHwgKDEgPDwgMikgfCAoMSA8PCAxKSB8ICgxIDw8IDApO1xuXHRcdHZhciBHMTggPSAoMSA8PCAxMikgfCAoMSA8PCAxMSkgfCAoMSA8PCAxMCkgfCAoMSA8PCA5KSB8ICgxIDw8IDgpIHwgKDEgPDwgNSkgfCAoMSA8PCAyKSB8ICgxIDw8IDApO1xuXHRcdHZhciBHMTVfTUFTSyA9ICgxIDw8IDE0KSB8ICgxIDw8IDEyKSB8ICgxIDw8IDEwKSB8ICgxIDw8IDQpIHwgKDEgPDwgMSk7XG5cblx0XHR2YXIgX3RoaXMgPSB7fTtcblxuXHRcdHZhciBnZXRCQ0hEaWdpdCA9IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRcdHZhciBkaWdpdCA9IDA7XG5cdFx0XHR3aGlsZSAoZGF0YSAhPSAwKSB7XG5cdFx0XHRcdGRpZ2l0ICs9IDE7XG5cdFx0XHRcdGRhdGEgPj4+PSAxO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGRpZ2l0O1xuXHRcdH07XG5cblx0XHRfdGhpcy5nZXRCQ0hUeXBlSW5mbyA9IGZ1bmN0aW9uKGRhdGEpIHtcblx0XHRcdHZhciBkID0gZGF0YSA8PCAxMDtcblx0XHRcdHdoaWxlIChnZXRCQ0hEaWdpdChkKSAtIGdldEJDSERpZ2l0KEcxNSkgPj0gMCkge1xuXHRcdFx0XHRkIF49IChHMTUgPDwgKGdldEJDSERpZ2l0KGQpIC0gZ2V0QkNIRGlnaXQoRzE1KSApICk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gKCAoZGF0YSA8PCAxMCkgfCBkKSBeIEcxNV9NQVNLO1xuXHRcdH07XG5cblx0XHRfdGhpcy5nZXRCQ0hUeXBlTnVtYmVyID0gZnVuY3Rpb24oZGF0YSkge1xuXHRcdFx0dmFyIGQgPSBkYXRhIDw8IDEyO1xuXHRcdFx0d2hpbGUgKGdldEJDSERpZ2l0KGQpIC0gZ2V0QkNIRGlnaXQoRzE4KSA+PSAwKSB7XG5cdFx0XHRcdGQgXj0gKEcxOCA8PCAoZ2V0QkNIRGlnaXQoZCkgLSBnZXRCQ0hEaWdpdChHMTgpICkgKTtcblx0XHRcdH1cblx0XHRcdHJldHVybiAoZGF0YSA8PCAxMikgfCBkO1xuXHRcdH07XG5cblx0XHRfdGhpcy5nZXRQYXR0ZXJuUG9zaXRpb24gPSBmdW5jdGlvbih0eXBlTnVtYmVyKSB7XG5cdFx0XHRyZXR1cm4gUEFUVEVSTl9QT1NJVElPTl9UQUJMRVt0eXBlTnVtYmVyIC0gMV07XG5cdFx0fTtcblxuXHRcdF90aGlzLmdldE1hc2tGdW5jdGlvbiA9IGZ1bmN0aW9uKG1hc2tQYXR0ZXJuKSB7XG5cblx0XHRcdHN3aXRjaCAobWFza1BhdHRlcm4pIHtcblxuXHRcdFx0Y2FzZSBRUk1hc2tQYXR0ZXJuLlBBVFRFUk4wMDAgOlxuXHRcdFx0XHRyZXR1cm4gZnVuY3Rpb24oaSwgaikgeyByZXR1cm4gKGkgKyBqKSAlIDIgPT0gMDsgfTtcblx0XHRcdGNhc2UgUVJNYXNrUGF0dGVybi5QQVRURVJOMDAxIDpcblx0XHRcdFx0cmV0dXJuIGZ1bmN0aW9uKGksIGopIHsgcmV0dXJuIGkgJSAyID09IDA7IH07XG5cdFx0XHRjYXNlIFFSTWFza1BhdHRlcm4uUEFUVEVSTjAxMCA6XG5cdFx0XHRcdHJldHVybiBmdW5jdGlvbihpLCBqKSB7IHJldHVybiBqICUgMyA9PSAwOyB9O1xuXHRcdFx0Y2FzZSBRUk1hc2tQYXR0ZXJuLlBBVFRFUk4wMTEgOlxuXHRcdFx0XHRyZXR1cm4gZnVuY3Rpb24oaSwgaikgeyByZXR1cm4gKGkgKyBqKSAlIDMgPT0gMDsgfTtcblx0XHRcdGNhc2UgUVJNYXNrUGF0dGVybi5QQVRURVJOMTAwIDpcblx0XHRcdFx0cmV0dXJuIGZ1bmN0aW9uKGksIGopIHsgcmV0dXJuIChNYXRoLmZsb29yKGkgLyAyKSArIE1hdGguZmxvb3IoaiAvIDMpICkgJSAyID09IDA7IH07XG5cdFx0XHRjYXNlIFFSTWFza1BhdHRlcm4uUEFUVEVSTjEwMSA6XG5cdFx0XHRcdHJldHVybiBmdW5jdGlvbihpLCBqKSB7IHJldHVybiAoaSAqIGopICUgMiArIChpICogaikgJSAzID09IDA7IH07XG5cdFx0XHRjYXNlIFFSTWFza1BhdHRlcm4uUEFUVEVSTjExMCA6XG5cdFx0XHRcdHJldHVybiBmdW5jdGlvbihpLCBqKSB7IHJldHVybiAoIChpICogaikgJSAyICsgKGkgKiBqKSAlIDMpICUgMiA9PSAwOyB9O1xuXHRcdFx0Y2FzZSBRUk1hc2tQYXR0ZXJuLlBBVFRFUk4xMTEgOlxuXHRcdFx0XHRyZXR1cm4gZnVuY3Rpb24oaSwgaikgeyByZXR1cm4gKCAoaSAqIGopICUgMyArIChpICsgaikgJSAyKSAlIDIgPT0gMDsgfTtcblxuXHRcdFx0ZGVmYXVsdCA6XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcignYmFkIG1hc2tQYXR0ZXJuOicgKyBtYXNrUGF0dGVybik7XG5cdFx0XHR9XG5cdFx0fTtcblxuXHRcdF90aGlzLmdldEVycm9yQ29ycmVjdFBvbHlub21pYWwgPSBmdW5jdGlvbihlcnJvckNvcnJlY3RMZW5ndGgpIHtcblx0XHRcdHZhciBhID0gcXJQb2x5bm9taWFsKFsxXSwgMCk7XG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGVycm9yQ29ycmVjdExlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRcdGEgPSBhLm11bHRpcGx5KHFyUG9seW5vbWlhbChbMSwgUVJNYXRoLmdleHAoaSldLCAwKSApO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGE7XG5cdFx0fTtcblxuXHRcdF90aGlzLmdldExlbmd0aEluQml0cyA9IGZ1bmN0aW9uKG1vZGUsIHR5cGUpIHtcblxuXHRcdFx0aWYgKDEgPD0gdHlwZSAmJiB0eXBlIDwgMTApIHtcblxuXHRcdFx0XHQvLyAxIC0gOVxuXG5cdFx0XHRcdHN3aXRjaChtb2RlKSB7XG5cdFx0XHRcdGNhc2UgUVJNb2RlLk1PREVfTlVNQkVSIFx0OiByZXR1cm4gMTA7XG5cdFx0XHRcdGNhc2UgUVJNb2RlLk1PREVfQUxQSEFfTlVNIFx0OiByZXR1cm4gOTtcblx0XHRcdFx0Y2FzZSBRUk1vZGUuTU9ERV84QklUX0JZVEVcdDogcmV0dXJuIDg7XG5cdFx0XHRcdGNhc2UgUVJNb2RlLk1PREVfS0FOSklcdFx0OiByZXR1cm4gODtcblx0XHRcdFx0ZGVmYXVsdCA6XG5cdFx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKCdtb2RlOicgKyBtb2RlKTtcblx0XHRcdFx0fVxuXG5cdFx0XHR9IGVsc2UgaWYgKHR5cGUgPCAyNykge1xuXG5cdFx0XHRcdC8vIDEwIC0gMjZcblxuXHRcdFx0XHRzd2l0Y2gobW9kZSkge1xuXHRcdFx0XHRjYXNlIFFSTW9kZS5NT0RFX05VTUJFUiBcdDogcmV0dXJuIDEyO1xuXHRcdFx0XHRjYXNlIFFSTW9kZS5NT0RFX0FMUEhBX05VTSBcdDogcmV0dXJuIDExO1xuXHRcdFx0XHRjYXNlIFFSTW9kZS5NT0RFXzhCSVRfQllURVx0OiByZXR1cm4gMTY7XG5cdFx0XHRcdGNhc2UgUVJNb2RlLk1PREVfS0FOSklcdFx0OiByZXR1cm4gMTA7XG5cdFx0XHRcdGRlZmF1bHQgOlxuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcignbW9kZTonICsgbW9kZSk7XG5cdFx0XHRcdH1cblxuXHRcdFx0fSBlbHNlIGlmICh0eXBlIDwgNDEpIHtcblxuXHRcdFx0XHQvLyAyNyAtIDQwXG5cblx0XHRcdFx0c3dpdGNoKG1vZGUpIHtcblx0XHRcdFx0Y2FzZSBRUk1vZGUuTU9ERV9OVU1CRVIgXHQ6IHJldHVybiAxNDtcblx0XHRcdFx0Y2FzZSBRUk1vZGUuTU9ERV9BTFBIQV9OVU1cdDogcmV0dXJuIDEzO1xuXHRcdFx0XHRjYXNlIFFSTW9kZS5NT0RFXzhCSVRfQllURVx0OiByZXR1cm4gMTY7XG5cdFx0XHRcdGNhc2UgUVJNb2RlLk1PREVfS0FOSklcdFx0OiByZXR1cm4gMTI7XG5cdFx0XHRcdGRlZmF1bHQgOlxuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcignbW9kZTonICsgbW9kZSk7XG5cdFx0XHRcdH1cblxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKCd0eXBlOicgKyB0eXBlKTtcblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0X3RoaXMuZ2V0TG9zdFBvaW50ID0gZnVuY3Rpb24ocXJjb2RlKSB7XG5cblx0XHRcdHZhciBtb2R1bGVDb3VudCA9IHFyY29kZS5nZXRNb2R1bGVDb3VudCgpO1xuXG5cdFx0XHR2YXIgbG9zdFBvaW50ID0gMDtcblxuXHRcdFx0Ly8gTEVWRUwxXG5cblx0XHRcdGZvciAodmFyIHJvdyA9IDA7IHJvdyA8IG1vZHVsZUNvdW50OyByb3cgKz0gMSkge1xuXHRcdFx0XHRmb3IgKHZhciBjb2wgPSAwOyBjb2wgPCBtb2R1bGVDb3VudDsgY29sICs9IDEpIHtcblxuXHRcdFx0XHRcdHZhciBzYW1lQ291bnQgPSAwO1xuXHRcdFx0XHRcdHZhciBkYXJrID0gcXJjb2RlLmlzRGFyayhyb3csIGNvbCk7XG5cblx0XHRcdFx0XHRmb3IgKHZhciByID0gLTE7IHIgPD0gMTsgciArPSAxKSB7XG5cblx0XHRcdFx0XHRcdGlmIChyb3cgKyByIDwgMCB8fCBtb2R1bGVDb3VudCA8PSByb3cgKyByKSB7XG5cdFx0XHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHRmb3IgKHZhciBjID0gLTE7IGMgPD0gMTsgYyArPSAxKSB7XG5cblx0XHRcdFx0XHRcdFx0aWYgKGNvbCArIGMgPCAwIHx8IG1vZHVsZUNvdW50IDw9IGNvbCArIGMpIHtcblx0XHRcdFx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHRcdGlmIChyID09IDAgJiYgYyA9PSAwKSB7XG5cdFx0XHRcdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0XHRpZiAoZGFyayA9PSBxcmNvZGUuaXNEYXJrKHJvdyArIHIsIGNvbCArIGMpICkge1xuXHRcdFx0XHRcdFx0XHRcdHNhbWVDb3VudCArPSAxO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0aWYgKHNhbWVDb3VudCA+IDUpIHtcblx0XHRcdFx0XHRcdGxvc3RQb2ludCArPSAoMyArIHNhbWVDb3VudCAtIDUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fTtcblxuXHRcdFx0Ly8gTEVWRUwyXG5cblx0XHRcdGZvciAodmFyIHJvdyA9IDA7IHJvdyA8IG1vZHVsZUNvdW50IC0gMTsgcm93ICs9IDEpIHtcblx0XHRcdFx0Zm9yICh2YXIgY29sID0gMDsgY29sIDwgbW9kdWxlQ291bnQgLSAxOyBjb2wgKz0gMSkge1xuXHRcdFx0XHRcdHZhciBjb3VudCA9IDA7XG5cdFx0XHRcdFx0aWYgKHFyY29kZS5pc0Rhcmsocm93LCBjb2wpICkgY291bnQgKz0gMTtcblx0XHRcdFx0XHRpZiAocXJjb2RlLmlzRGFyayhyb3cgKyAxLCBjb2wpICkgY291bnQgKz0gMTtcblx0XHRcdFx0XHRpZiAocXJjb2RlLmlzRGFyayhyb3csIGNvbCArIDEpICkgY291bnQgKz0gMTtcblx0XHRcdFx0XHRpZiAocXJjb2RlLmlzRGFyayhyb3cgKyAxLCBjb2wgKyAxKSApIGNvdW50ICs9IDE7XG5cdFx0XHRcdFx0aWYgKGNvdW50ID09IDAgfHwgY291bnQgPT0gNCkge1xuXHRcdFx0XHRcdFx0bG9zdFBvaW50ICs9IDM7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIExFVkVMM1xuXG5cdFx0XHRmb3IgKHZhciByb3cgPSAwOyByb3cgPCBtb2R1bGVDb3VudDsgcm93ICs9IDEpIHtcblx0XHRcdFx0Zm9yICh2YXIgY29sID0gMDsgY29sIDwgbW9kdWxlQ291bnQgLSA2OyBjb2wgKz0gMSkge1xuXHRcdFx0XHRcdGlmIChxcmNvZGUuaXNEYXJrKHJvdywgY29sKVxuXHRcdFx0XHRcdFx0XHQmJiAhcXJjb2RlLmlzRGFyayhyb3csIGNvbCArIDEpXG5cdFx0XHRcdFx0XHRcdCYmICBxcmNvZGUuaXNEYXJrKHJvdywgY29sICsgMilcblx0XHRcdFx0XHRcdFx0JiYgIHFyY29kZS5pc0Rhcmsocm93LCBjb2wgKyAzKVxuXHRcdFx0XHRcdFx0XHQmJiAgcXJjb2RlLmlzRGFyayhyb3csIGNvbCArIDQpXG5cdFx0XHRcdFx0XHRcdCYmICFxcmNvZGUuaXNEYXJrKHJvdywgY29sICsgNSlcblx0XHRcdFx0XHRcdFx0JiYgIHFyY29kZS5pc0Rhcmsocm93LCBjb2wgKyA2KSApIHtcblx0XHRcdFx0XHRcdGxvc3RQb2ludCArPSA0MDtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Zm9yICh2YXIgY29sID0gMDsgY29sIDwgbW9kdWxlQ291bnQ7IGNvbCArPSAxKSB7XG5cdFx0XHRcdGZvciAodmFyIHJvdyA9IDA7IHJvdyA8IG1vZHVsZUNvdW50IC0gNjsgcm93ICs9IDEpIHtcblx0XHRcdFx0XHRpZiAocXJjb2RlLmlzRGFyayhyb3csIGNvbClcblx0XHRcdFx0XHRcdFx0JiYgIXFyY29kZS5pc0Rhcmsocm93ICsgMSwgY29sKVxuXHRcdFx0XHRcdFx0XHQmJiAgcXJjb2RlLmlzRGFyayhyb3cgKyAyLCBjb2wpXG5cdFx0XHRcdFx0XHRcdCYmICBxcmNvZGUuaXNEYXJrKHJvdyArIDMsIGNvbClcblx0XHRcdFx0XHRcdFx0JiYgIHFyY29kZS5pc0Rhcmsocm93ICsgNCwgY29sKVxuXHRcdFx0XHRcdFx0XHQmJiAhcXJjb2RlLmlzRGFyayhyb3cgKyA1LCBjb2wpXG5cdFx0XHRcdFx0XHRcdCYmICBxcmNvZGUuaXNEYXJrKHJvdyArIDYsIGNvbCkgKSB7XG5cdFx0XHRcdFx0XHRsb3N0UG9pbnQgKz0gNDA7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdC8vIExFVkVMNFxuXG5cdFx0XHR2YXIgZGFya0NvdW50ID0gMDtcblxuXHRcdFx0Zm9yICh2YXIgY29sID0gMDsgY29sIDwgbW9kdWxlQ291bnQ7IGNvbCArPSAxKSB7XG5cdFx0XHRcdGZvciAodmFyIHJvdyA9IDA7IHJvdyA8IG1vZHVsZUNvdW50OyByb3cgKz0gMSkge1xuXHRcdFx0XHRcdGlmIChxcmNvZGUuaXNEYXJrKHJvdywgY29sKSApIHtcblx0XHRcdFx0XHRcdGRhcmtDb3VudCArPSAxO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHR2YXIgcmF0aW8gPSBNYXRoLmFicygxMDAgKiBkYXJrQ291bnQgLyBtb2R1bGVDb3VudCAvIG1vZHVsZUNvdW50IC0gNTApIC8gNTtcblx0XHRcdGxvc3RQb2ludCArPSByYXRpbyAqIDEwO1xuXG5cdFx0XHRyZXR1cm4gbG9zdFBvaW50O1xuXHRcdH07XG5cblx0XHRyZXR1cm4gX3RoaXM7XG5cdH0oKTtcblxuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBRUk1hdGhcblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR2YXIgUVJNYXRoID0gZnVuY3Rpb24oKSB7XG5cblx0XHR2YXIgRVhQX1RBQkxFID0gbmV3IEFycmF5KDI1Nik7XG5cdFx0dmFyIExPR19UQUJMRSA9IG5ldyBBcnJheSgyNTYpO1xuXG5cdFx0Ly8gaW5pdGlhbGl6ZSB0YWJsZXNcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IDg7IGkgKz0gMSkge1xuXHRcdFx0RVhQX1RBQkxFW2ldID0gMSA8PCBpO1xuXHRcdH1cblx0XHRmb3IgKHZhciBpID0gODsgaSA8IDI1NjsgaSArPSAxKSB7XG5cdFx0XHRFWFBfVEFCTEVbaV0gPSBFWFBfVEFCTEVbaSAtIDRdXG5cdFx0XHRcdF4gRVhQX1RBQkxFW2kgLSA1XVxuXHRcdFx0XHReIEVYUF9UQUJMRVtpIC0gNl1cblx0XHRcdFx0XiBFWFBfVEFCTEVbaSAtIDhdO1xuXHRcdH1cblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IDI1NTsgaSArPSAxKSB7XG5cdFx0XHRMT0dfVEFCTEVbRVhQX1RBQkxFW2ldIF0gPSBpO1xuXHRcdH1cblxuXHRcdHZhciBfdGhpcyA9IHt9O1xuXG5cdFx0X3RoaXMuZ2xvZyA9IGZ1bmN0aW9uKG4pIHtcblxuXHRcdFx0aWYgKG4gPCAxKSB7XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcignZ2xvZygnICsgbiArICcpJyk7XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiBMT0dfVEFCTEVbbl07XG5cdFx0fTtcblxuXHRcdF90aGlzLmdleHAgPSBmdW5jdGlvbihuKSB7XG5cblx0XHRcdHdoaWxlIChuIDwgMCkge1xuXHRcdFx0XHRuICs9IDI1NTtcblx0XHRcdH1cblxuXHRcdFx0d2hpbGUgKG4gPj0gMjU2KSB7XG5cdFx0XHRcdG4gLT0gMjU1O1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gRVhQX1RBQkxFW25dO1xuXHRcdH07XG5cblx0XHRyZXR1cm4gX3RoaXM7XG5cdH0oKTtcblxuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBxclBvbHlub21pYWxcblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHRmdW5jdGlvbiBxclBvbHlub21pYWwobnVtLCBzaGlmdCkge1xuXG5cdFx0aWYgKHR5cGVvZiBudW0ubGVuZ3RoID09ICd1bmRlZmluZWQnKSB7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IobnVtLmxlbmd0aCArICcvJyArIHNoaWZ0KTtcblx0XHR9XG5cblx0XHR2YXIgX251bSA9IGZ1bmN0aW9uKCkge1xuXHRcdFx0dmFyIG9mZnNldCA9IDA7XG5cdFx0XHR3aGlsZSAob2Zmc2V0IDwgbnVtLmxlbmd0aCAmJiBudW1bb2Zmc2V0XSA9PSAwKSB7XG5cdFx0XHRcdG9mZnNldCArPSAxO1xuXHRcdFx0fVxuXHRcdFx0dmFyIF9udW0gPSBuZXcgQXJyYXkobnVtLmxlbmd0aCAtIG9mZnNldCArIHNoaWZ0KTtcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgbnVtLmxlbmd0aCAtIG9mZnNldDsgaSArPSAxKSB7XG5cdFx0XHRcdF9udW1baV0gPSBudW1baSArIG9mZnNldF07XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gX251bTtcblx0XHR9KCk7XG5cblx0XHR2YXIgX3RoaXMgPSB7fTtcblxuXHRcdF90aGlzLmdldCA9IGZ1bmN0aW9uKGluZGV4KSB7XG5cdFx0XHRyZXR1cm4gX251bVtpbmRleF07XG5cdFx0fTtcblxuXHRcdF90aGlzLmdldExlbmd0aCA9IGZ1bmN0aW9uKCkge1xuXHRcdFx0cmV0dXJuIF9udW0ubGVuZ3RoO1xuXHRcdH07XG5cblx0XHRfdGhpcy5tdWx0aXBseSA9IGZ1bmN0aW9uKGUpIHtcblxuXHRcdFx0dmFyIG51bSA9IG5ldyBBcnJheShfdGhpcy5nZXRMZW5ndGgoKSArIGUuZ2V0TGVuZ3RoKCkgLSAxKTtcblxuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBfdGhpcy5nZXRMZW5ndGgoKTsgaSArPSAxKSB7XG5cdFx0XHRcdGZvciAodmFyIGogPSAwOyBqIDwgZS5nZXRMZW5ndGgoKTsgaiArPSAxKSB7XG5cdFx0XHRcdFx0bnVtW2kgKyBqXSBePSBRUk1hdGguZ2V4cChRUk1hdGguZ2xvZyhfdGhpcy5nZXQoaSkgKSArIFFSTWF0aC5nbG9nKGUuZ2V0KGopICkgKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gcXJQb2x5bm9taWFsKG51bSwgMCk7XG5cdFx0fTtcblxuXHRcdF90aGlzLm1vZCA9IGZ1bmN0aW9uKGUpIHtcblxuXHRcdFx0aWYgKF90aGlzLmdldExlbmd0aCgpIC0gZS5nZXRMZW5ndGgoKSA8IDApIHtcblx0XHRcdFx0cmV0dXJuIF90aGlzO1xuXHRcdFx0fVxuXG5cdFx0XHR2YXIgcmF0aW8gPSBRUk1hdGguZ2xvZyhfdGhpcy5nZXQoMCkgKSAtIFFSTWF0aC5nbG9nKGUuZ2V0KDApICk7XG5cblx0XHRcdHZhciBudW0gPSBuZXcgQXJyYXkoX3RoaXMuZ2V0TGVuZ3RoKCkgKTtcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgX3RoaXMuZ2V0TGVuZ3RoKCk7IGkgKz0gMSkge1xuXHRcdFx0XHRudW1baV0gPSBfdGhpcy5nZXQoaSk7XG5cdFx0XHR9XG5cblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgZS5nZXRMZW5ndGgoKTsgaSArPSAxKSB7XG5cdFx0XHRcdG51bVtpXSBePSBRUk1hdGguZ2V4cChRUk1hdGguZ2xvZyhlLmdldChpKSApICsgcmF0aW8pO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyByZWN1cnNpdmUgY2FsbFxuXHRcdFx0cmV0dXJuIHFyUG9seW5vbWlhbChudW0sIDApLm1vZChlKTtcblx0XHR9O1xuXG5cdFx0cmV0dXJuIF90aGlzO1xuXHR9O1xuXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdC8vIFFSUlNCbG9ja1xuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG5cdHZhciBRUlJTQmxvY2sgPSBmdW5jdGlvbigpIHtcblxuXHRcdHZhciBSU19CTE9DS19UQUJMRSA9IFtcblxuXHRcdFx0Ly8gTFxuXHRcdFx0Ly8gTVxuXHRcdFx0Ly8gUVxuXHRcdFx0Ly8gSFxuXG5cdFx0XHQvLyAxXG5cdFx0XHRbMSwgMjYsIDE5XSxcblx0XHRcdFsxLCAyNiwgMTZdLFxuXHRcdFx0WzEsIDI2LCAxM10sXG5cdFx0XHRbMSwgMjYsIDldLFxuXG5cdFx0XHQvLyAyXG5cdFx0XHRbMSwgNDQsIDM0XSxcblx0XHRcdFsxLCA0NCwgMjhdLFxuXHRcdFx0WzEsIDQ0LCAyMl0sXG5cdFx0XHRbMSwgNDQsIDE2XSxcblxuXHRcdFx0Ly8gM1xuXHRcdFx0WzEsIDcwLCA1NV0sXG5cdFx0XHRbMSwgNzAsIDQ0XSxcblx0XHRcdFsyLCAzNSwgMTddLFxuXHRcdFx0WzIsIDM1LCAxM10sXG5cblx0XHRcdC8vIDRcblx0XHRcdFsxLCAxMDAsIDgwXSxcblx0XHRcdFsyLCA1MCwgMzJdLFxuXHRcdFx0WzIsIDUwLCAyNF0sXG5cdFx0XHRbNCwgMjUsIDldLFxuXG5cdFx0XHQvLyA1XG5cdFx0XHRbMSwgMTM0LCAxMDhdLFxuXHRcdFx0WzIsIDY3LCA0M10sXG5cdFx0XHRbMiwgMzMsIDE1LCAyLCAzNCwgMTZdLFxuXHRcdFx0WzIsIDMzLCAxMSwgMiwgMzQsIDEyXSxcblxuXHRcdFx0Ly8gNlxuXHRcdFx0WzIsIDg2LCA2OF0sXG5cdFx0XHRbNCwgNDMsIDI3XSxcblx0XHRcdFs0LCA0MywgMTldLFxuXHRcdFx0WzQsIDQzLCAxNV0sXG5cblx0XHRcdC8vIDdcblx0XHRcdFsyLCA5OCwgNzhdLFxuXHRcdFx0WzQsIDQ5LCAzMV0sXG5cdFx0XHRbMiwgMzIsIDE0LCA0LCAzMywgMTVdLFxuXHRcdFx0WzQsIDM5LCAxMywgMSwgNDAsIDE0XSxcblxuXHRcdFx0Ly8gOFxuXHRcdFx0WzIsIDEyMSwgOTddLFxuXHRcdFx0WzIsIDYwLCAzOCwgMiwgNjEsIDM5XSxcblx0XHRcdFs0LCA0MCwgMTgsIDIsIDQxLCAxOV0sXG5cdFx0XHRbNCwgNDAsIDE0LCAyLCA0MSwgMTVdLFxuXG5cdFx0XHQvLyA5XG5cdFx0XHRbMiwgMTQ2LCAxMTZdLFxuXHRcdFx0WzMsIDU4LCAzNiwgMiwgNTksIDM3XSxcblx0XHRcdFs0LCAzNiwgMTYsIDQsIDM3LCAxN10sXG5cdFx0XHRbNCwgMzYsIDEyLCA0LCAzNywgMTNdLFxuXG5cdFx0XHQvLyAxMFxuXHRcdFx0WzIsIDg2LCA2OCwgMiwgODcsIDY5XSxcblx0XHRcdFs0LCA2OSwgNDMsIDEsIDcwLCA0NF0sXG5cdFx0XHRbNiwgNDMsIDE5LCAyLCA0NCwgMjBdLFxuXHRcdFx0WzYsIDQzLCAxNSwgMiwgNDQsIDE2XVxuXHRcdF07XG5cblx0XHR2YXIgcXJSU0Jsb2NrID0gZnVuY3Rpb24odG90YWxDb3VudCwgZGF0YUNvdW50KSB7XG5cdFx0XHR2YXIgX3RoaXMgPSB7fTtcblx0XHRcdF90aGlzLnRvdGFsQ291bnQgPSB0b3RhbENvdW50O1xuXHRcdFx0X3RoaXMuZGF0YUNvdW50ID0gZGF0YUNvdW50O1xuXHRcdFx0cmV0dXJuIF90aGlzO1xuXHRcdH07XG5cblx0XHR2YXIgX3RoaXMgPSB7fTtcblxuXHRcdHZhciBnZXRSc0Jsb2NrVGFibGUgPSBmdW5jdGlvbih0eXBlTnVtYmVyLCBlcnJvckNvcnJlY3RMZXZlbCkge1xuXG5cdFx0XHRzd2l0Y2goZXJyb3JDb3JyZWN0TGV2ZWwpIHtcblx0XHRcdGNhc2UgUVJFcnJvckNvcnJlY3RMZXZlbC5MIDpcblx0XHRcdFx0cmV0dXJuIFJTX0JMT0NLX1RBQkxFWyh0eXBlTnVtYmVyIC0gMSkgKiA0ICsgMF07XG5cdFx0XHRjYXNlIFFSRXJyb3JDb3JyZWN0TGV2ZWwuTSA6XG5cdFx0XHRcdHJldHVybiBSU19CTE9DS19UQUJMRVsodHlwZU51bWJlciAtIDEpICogNCArIDFdO1xuXHRcdFx0Y2FzZSBRUkVycm9yQ29ycmVjdExldmVsLlEgOlxuXHRcdFx0XHRyZXR1cm4gUlNfQkxPQ0tfVEFCTEVbKHR5cGVOdW1iZXIgLSAxKSAqIDQgKyAyXTtcblx0XHRcdGNhc2UgUVJFcnJvckNvcnJlY3RMZXZlbC5IIDpcblx0XHRcdFx0cmV0dXJuIFJTX0JMT0NLX1RBQkxFWyh0eXBlTnVtYmVyIC0gMSkgKiA0ICsgM107XG5cdFx0XHRkZWZhdWx0IDpcblx0XHRcdFx0cmV0dXJuIHVuZGVmaW5lZDtcblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0X3RoaXMuZ2V0UlNCbG9ja3MgPSBmdW5jdGlvbih0eXBlTnVtYmVyLCBlcnJvckNvcnJlY3RMZXZlbCkge1xuXG5cdFx0XHR2YXIgcnNCbG9jayA9IGdldFJzQmxvY2tUYWJsZSh0eXBlTnVtYmVyLCBlcnJvckNvcnJlY3RMZXZlbCk7XG5cblx0XHRcdGlmICh0eXBlb2YgcnNCbG9jayA9PSAndW5kZWZpbmVkJykge1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ2JhZCBycyBibG9jayBAIHR5cGVOdW1iZXI6JyArIHR5cGVOdW1iZXIgK1xuXHRcdFx0XHRcdFx0Jy9lcnJvckNvcnJlY3RMZXZlbDonICsgZXJyb3JDb3JyZWN0TGV2ZWwpO1xuXHRcdFx0fVxuXG5cdFx0XHR2YXIgbGVuZ3RoID0gcnNCbG9jay5sZW5ndGggLyAzO1xuXG5cdFx0XHR2YXIgbGlzdCA9IG5ldyBBcnJheSgpO1xuXG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSArPSAxKSB7XG5cblx0XHRcdFx0dmFyIGNvdW50ID0gcnNCbG9ja1tpICogMyArIDBdO1xuXHRcdFx0XHR2YXIgdG90YWxDb3VudCA9IHJzQmxvY2tbaSAqIDMgKyAxXTtcblx0XHRcdFx0dmFyIGRhdGFDb3VudCA9IHJzQmxvY2tbaSAqIDMgKyAyXTtcblxuXHRcdFx0XHRmb3IgKHZhciBqID0gMDsgaiA8IGNvdW50OyBqICs9IDEpIHtcblx0XHRcdFx0XHRsaXN0LnB1c2gocXJSU0Jsb2NrKHRvdGFsQ291bnQsIGRhdGFDb3VudCkgKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gbGlzdDtcblx0XHR9O1xuXG5cdFx0cmV0dXJuIF90aGlzO1xuXHR9KCk7XG5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gcXJCaXRCdWZmZXJcblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR2YXIgcXJCaXRCdWZmZXIgPSBmdW5jdGlvbigpIHtcblxuXHRcdHZhciBfYnVmZmVyID0gbmV3IEFycmF5KCk7XG5cdFx0dmFyIF9sZW5ndGggPSAwO1xuXG5cdFx0dmFyIF90aGlzID0ge307XG5cblx0XHRfdGhpcy5nZXRCdWZmZXIgPSBmdW5jdGlvbigpIHtcblx0XHRcdHJldHVybiBfYnVmZmVyO1xuXHRcdH07XG5cblx0XHRfdGhpcy5nZXQgPSBmdW5jdGlvbihpbmRleCkge1xuXHRcdFx0dmFyIGJ1ZkluZGV4ID0gTWF0aC5mbG9vcihpbmRleCAvIDgpO1xuXHRcdFx0cmV0dXJuICggKF9idWZmZXJbYnVmSW5kZXhdID4+PiAoNyAtIGluZGV4ICUgOCkgKSAmIDEpID09IDE7XG5cdFx0fTtcblxuXHRcdF90aGlzLnB1dCA9IGZ1bmN0aW9uKG51bSwgbGVuZ3RoKSB7XG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGxlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRcdF90aGlzLnB1dEJpdCggKCAobnVtID4+PiAobGVuZ3RoIC0gaSAtIDEpICkgJiAxKSA9PSAxKTtcblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0X3RoaXMuZ2V0TGVuZ3RoSW5CaXRzID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRyZXR1cm4gX2xlbmd0aDtcblx0XHR9O1xuXG5cdFx0X3RoaXMucHV0Qml0ID0gZnVuY3Rpb24oYml0KSB7XG5cblx0XHRcdHZhciBidWZJbmRleCA9IE1hdGguZmxvb3IoX2xlbmd0aCAvIDgpO1xuXHRcdFx0aWYgKF9idWZmZXIubGVuZ3RoIDw9IGJ1ZkluZGV4KSB7XG5cdFx0XHRcdF9idWZmZXIucHVzaCgwKTtcblx0XHRcdH1cblxuXHRcdFx0aWYgKGJpdCkge1xuXHRcdFx0XHRfYnVmZmVyW2J1ZkluZGV4XSB8PSAoMHg4MCA+Pj4gKF9sZW5ndGggJSA4KSApO1xuXHRcdFx0fVxuXG5cdFx0XHRfbGVuZ3RoICs9IDE7XG5cdFx0fTtcblxuXHRcdHJldHVybiBfdGhpcztcblx0fTtcblxuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBxcjhCaXRCeXRlXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0dmFyIHFyOEJpdEJ5dGUgPSBmdW5jdGlvbihkYXRhKSB7XG5cblx0XHR2YXIgX21vZGUgPSBRUk1vZGUuTU9ERV84QklUX0JZVEU7XG5cdFx0dmFyIF9kYXRhID0gZGF0YTtcblx0XHR2YXIgX2J5dGVzID0gcXJjb2RlLnN0cmluZ1RvQnl0ZXMoZGF0YSk7XG5cblx0XHR2YXIgX3RoaXMgPSB7fTtcblxuXHRcdF90aGlzLmdldE1vZGUgPSBmdW5jdGlvbigpIHtcblx0XHRcdHJldHVybiBfbW9kZTtcblx0XHR9O1xuXG5cdFx0X3RoaXMuZ2V0TGVuZ3RoID0gZnVuY3Rpb24oYnVmZmVyKSB7XG5cdFx0XHRyZXR1cm4gX2J5dGVzLmxlbmd0aDtcblx0XHR9O1xuXG5cdFx0X3RoaXMud3JpdGUgPSBmdW5jdGlvbihidWZmZXIpIHtcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgX2J5dGVzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRcdGJ1ZmZlci5wdXQoX2J5dGVzW2ldLCA4KTtcblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0cmV0dXJuIF90aGlzO1xuXHR9O1xuXG5cdC8vPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5cdC8vIEdJRiBTdXBwb3J0IGV0Yy5cblx0Ly9cblxuXHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHQvLyBieXRlQXJyYXlPdXRwdXRTdHJlYW1cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR2YXIgYnl0ZUFycmF5T3V0cHV0U3RyZWFtID0gZnVuY3Rpb24oKSB7XG5cblx0XHR2YXIgX2J5dGVzID0gbmV3IEFycmF5KCk7XG5cblx0XHR2YXIgX3RoaXMgPSB7fTtcblxuXHRcdF90aGlzLndyaXRlQnl0ZSA9IGZ1bmN0aW9uKGIpIHtcblx0XHRcdF9ieXRlcy5wdXNoKGIgJiAweGZmKTtcblx0XHR9O1xuXG5cdFx0X3RoaXMud3JpdGVTaG9ydCA9IGZ1bmN0aW9uKGkpIHtcblx0XHRcdF90aGlzLndyaXRlQnl0ZShpKTtcblx0XHRcdF90aGlzLndyaXRlQnl0ZShpID4+PiA4KTtcblx0XHR9O1xuXG5cdFx0X3RoaXMud3JpdGVCeXRlcyA9IGZ1bmN0aW9uKGIsIG9mZiwgbGVuKSB7XG5cdFx0XHRvZmYgPSBvZmYgfHwgMDtcblx0XHRcdGxlbiA9IGxlbiB8fCBiLmxlbmd0aDtcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyBpICs9IDEpIHtcblx0XHRcdFx0X3RoaXMud3JpdGVCeXRlKGJbaSArIG9mZl0pO1xuXHRcdFx0fVxuXHRcdH07XG5cblx0XHRfdGhpcy53cml0ZVN0cmluZyA9IGZ1bmN0aW9uKHMpIHtcblx0XHRcdGZvciAodmFyIGkgPSAwOyBpIDwgcy5sZW5ndGg7IGkgKz0gMSkge1xuXHRcdFx0XHRfdGhpcy53cml0ZUJ5dGUocy5jaGFyQ29kZUF0KGkpICk7XG5cdFx0XHR9XG5cdFx0fTtcblxuXHRcdF90aGlzLnRvQnl0ZUFycmF5ID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRyZXR1cm4gX2J5dGVzO1xuXHRcdH07XG5cblx0XHRfdGhpcy50b1N0cmluZyA9IGZ1bmN0aW9uKCkge1xuXHRcdFx0dmFyIHMgPSAnJztcblx0XHRcdHMgKz0gJ1snO1xuXHRcdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBfYnl0ZXMubGVuZ3RoOyBpICs9IDEpIHtcblx0XHRcdFx0aWYgKGkgPiAwKSB7XG5cdFx0XHRcdFx0cyArPSAnLCc7XG5cdFx0XHRcdH1cblx0XHRcdFx0cyArPSBfYnl0ZXNbaV07XG5cdFx0XHR9XG5cdFx0XHRzICs9ICddJztcblx0XHRcdHJldHVybiBzO1xuXHRcdH07XG5cblx0XHRyZXR1cm4gX3RoaXM7XG5cdH07XG5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gYmFzZTY0RW5jb2RlT3V0cHV0U3RyZWFtXG5cdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cblx0dmFyIGJhc2U2NEVuY29kZU91dHB1dFN0cmVhbSA9IGZ1bmN0aW9uKCkge1xuXG5cdFx0dmFyIF9idWZmZXIgPSAwO1xuXHRcdHZhciBfYnVmbGVuID0gMDtcblx0XHR2YXIgX2xlbmd0aCA9IDA7XG5cdFx0dmFyIF9iYXNlNjQgPSAnJztcblxuXHRcdHZhciBfdGhpcyA9IHt9O1xuXG5cdFx0dmFyIHdyaXRlRW5jb2RlZCA9IGZ1bmN0aW9uKGIpIHtcblx0XHRcdF9iYXNlNjQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShlbmNvZGUoYiAmIDB4M2YpICk7XG5cdFx0fTtcblxuXHRcdHZhciBlbmNvZGUgPSBmdW5jdGlvbihuKSB7XG5cdFx0XHRpZiAobiA8IDApIHtcblx0XHRcdFx0Ly8gZXJyb3IuXG5cdFx0XHR9IGVsc2UgaWYgKG4gPCAyNikge1xuXHRcdFx0XHRyZXR1cm4gMHg0MSArIG47XG5cdFx0XHR9IGVsc2UgaWYgKG4gPCA1Mikge1xuXHRcdFx0XHRyZXR1cm4gMHg2MSArIChuIC0gMjYpO1xuXHRcdFx0fSBlbHNlIGlmIChuIDwgNjIpIHtcblx0XHRcdFx0cmV0dXJuIDB4MzAgKyAobiAtIDUyKTtcblx0XHRcdH0gZWxzZSBpZiAobiA9PSA2Mikge1xuXHRcdFx0XHRyZXR1cm4gMHgyYjtcblx0XHRcdH0gZWxzZSBpZiAobiA9PSA2Mykge1xuXHRcdFx0XHRyZXR1cm4gMHgyZjtcblx0XHRcdH1cblx0XHRcdHRocm93IG5ldyBFcnJvcignbjonICsgbik7XG5cdFx0fTtcblxuXHRcdF90aGlzLndyaXRlQnl0ZSA9IGZ1bmN0aW9uKG4pIHtcblxuXHRcdFx0X2J1ZmZlciA9IChfYnVmZmVyIDw8IDgpIHwgKG4gJiAweGZmKTtcblx0XHRcdF9idWZsZW4gKz0gODtcblx0XHRcdF9sZW5ndGggKz0gMTtcblxuXHRcdFx0d2hpbGUgKF9idWZsZW4gPj0gNikge1xuXHRcdFx0XHR3cml0ZUVuY29kZWQoX2J1ZmZlciA+Pj4gKF9idWZsZW4gLSA2KSApO1xuXHRcdFx0XHRfYnVmbGVuIC09IDY7XG5cdFx0XHR9XG5cdFx0fTtcblxuXHRcdF90aGlzLmZsdXNoID0gZnVuY3Rpb24oKSB7XG5cblx0XHRcdGlmIChfYnVmbGVuID4gMCkge1xuXHRcdFx0XHR3cml0ZUVuY29kZWQoX2J1ZmZlciA8PCAoNiAtIF9idWZsZW4pICk7XG5cdFx0XHRcdF9idWZmZXIgPSAwO1xuXHRcdFx0XHRfYnVmbGVuID0gMDtcblx0XHRcdH1cblxuXHRcdFx0aWYgKF9sZW5ndGggJSAzICE9IDApIHtcblx0XHRcdFx0Ly8gcGFkZGluZ1xuXHRcdFx0XHR2YXIgcGFkbGVuID0gMyAtIF9sZW5ndGggJSAzO1xuXHRcdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHBhZGxlbjsgaSArPSAxKSB7XG5cdFx0XHRcdFx0X2Jhc2U2NCArPSAnPSc7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9O1xuXG5cdFx0X3RoaXMudG9TdHJpbmcgPSBmdW5jdGlvbigpIHtcblx0XHRcdHJldHVybiBfYmFzZTY0O1xuXHRcdH07XG5cblx0XHRyZXR1cm4gX3RoaXM7XG5cdH07XG5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gYmFzZTY0RGVjb2RlSW5wdXRTdHJlYW1cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR2YXIgYmFzZTY0RGVjb2RlSW5wdXRTdHJlYW0gPSBmdW5jdGlvbihzdHIpIHtcblxuXHRcdHZhciBfc3RyID0gc3RyO1xuXHRcdHZhciBfcG9zID0gMDtcblx0XHR2YXIgX2J1ZmZlciA9IDA7XG5cdFx0dmFyIF9idWZsZW4gPSAwO1xuXG5cdFx0dmFyIF90aGlzID0ge307XG5cblx0XHRfdGhpcy5yZWFkID0gZnVuY3Rpb24oKSB7XG5cblx0XHRcdHdoaWxlIChfYnVmbGVuIDwgOCkge1xuXG5cdFx0XHRcdGlmIChfcG9zID49IF9zdHIubGVuZ3RoKSB7XG5cdFx0XHRcdFx0aWYgKF9idWZsZW4gPT0gMCkge1xuXHRcdFx0XHRcdFx0cmV0dXJuIC0xO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ3VuZXhwZWN0ZWQgZW5kIG9mIGZpbGUuLycgKyBfYnVmbGVuKTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHZhciBjID0gX3N0ci5jaGFyQXQoX3Bvcyk7XG5cdFx0XHRcdF9wb3MgKz0gMTtcblxuXHRcdFx0XHRpZiAoYyA9PSAnPScpIHtcblx0XHRcdFx0XHRfYnVmbGVuID0gMDtcblx0XHRcdFx0XHRyZXR1cm4gLTE7XG5cdFx0XHRcdH0gZWxzZSBpZiAoYy5tYXRjaCgvXlxccyQvKSApIHtcblx0XHRcdFx0XHQvLyBpZ25vcmUgaWYgd2hpdGVzcGFjZS5cblx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdF9idWZmZXIgPSAoX2J1ZmZlciA8PCA2KSB8IGRlY29kZShjLmNoYXJDb2RlQXQoMCkgKTtcblx0XHRcdFx0X2J1ZmxlbiArPSA2O1xuXHRcdFx0fVxuXG5cdFx0XHR2YXIgbiA9IChfYnVmZmVyID4+PiAoX2J1ZmxlbiAtIDgpICkgJiAweGZmO1xuXHRcdFx0X2J1ZmxlbiAtPSA4O1xuXHRcdFx0cmV0dXJuIG47XG5cdFx0fTtcblxuXHRcdHZhciBkZWNvZGUgPSBmdW5jdGlvbihjKSB7XG5cdFx0XHRpZiAoMHg0MSA8PSBjICYmIGMgPD0gMHg1YSkge1xuXHRcdFx0XHRyZXR1cm4gYyAtIDB4NDE7XG5cdFx0XHR9IGVsc2UgaWYgKDB4NjEgPD0gYyAmJiBjIDw9IDB4N2EpIHtcblx0XHRcdFx0cmV0dXJuIGMgLSAweDYxICsgMjY7XG5cdFx0XHR9IGVsc2UgaWYgKDB4MzAgPD0gYyAmJiBjIDw9IDB4MzkpIHtcblx0XHRcdFx0cmV0dXJuIGMgLSAweDMwICsgNTI7XG5cdFx0XHR9IGVsc2UgaWYgKGMgPT0gMHgyYikge1xuXHRcdFx0XHRyZXR1cm4gNjI7XG5cdFx0XHR9IGVsc2UgaWYgKGMgPT0gMHgyZikge1xuXHRcdFx0XHRyZXR1cm4gNjM7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ2M6JyArIGMpO1xuXHRcdFx0fVxuXHRcdH07XG5cblx0XHRyZXR1cm4gX3RoaXM7XG5cdH07XG5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gZ2lmSW1hZ2UgKEIvVylcblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuXHR2YXIgZ2lmSW1hZ2UgPSBmdW5jdGlvbih3aWR0aCwgaGVpZ2h0KSB7XG5cblx0XHR2YXIgX3dpZHRoID0gd2lkdGg7XG5cdFx0dmFyIF9oZWlnaHQgPSBoZWlnaHQ7XG5cdFx0dmFyIF9kYXRhID0gbmV3IEFycmF5KHdpZHRoICogaGVpZ2h0KTtcblxuXHRcdHZhciBfdGhpcyA9IHt9O1xuXG5cdFx0X3RoaXMuc2V0UGl4ZWwgPSBmdW5jdGlvbih4LCB5LCBwaXhlbCkge1xuXHRcdFx0X2RhdGFbeSAqIF93aWR0aCArIHhdID0gcGl4ZWw7XG5cdFx0fTtcblxuXHRcdF90aGlzLndyaXRlID0gZnVuY3Rpb24ob3V0KSB7XG5cblx0XHRcdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdFx0XHQvLyBHSUYgU2lnbmF0dXJlXG5cblx0XHRcdG91dC53cml0ZVN0cmluZygnR0lGODdhJyk7XG5cblx0XHRcdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdFx0XHQvLyBTY3JlZW4gRGVzY3JpcHRvclxuXG5cdFx0XHRvdXQud3JpdGVTaG9ydChfd2lkdGgpO1xuXHRcdFx0b3V0LndyaXRlU2hvcnQoX2hlaWdodCk7XG5cblx0XHRcdG91dC53cml0ZUJ5dGUoMHg4MCk7IC8vIDJiaXRcblx0XHRcdG91dC53cml0ZUJ5dGUoMCk7XG5cdFx0XHRvdXQud3JpdGVCeXRlKDApO1xuXG5cdFx0XHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRcdFx0Ly8gR2xvYmFsIENvbG9yIE1hcFxuXG5cdFx0XHQvLyBibGFja1xuXHRcdFx0b3V0LndyaXRlQnl0ZSgweDAwKTtcblx0XHRcdG91dC53cml0ZUJ5dGUoMHgwMCk7XG5cdFx0XHRvdXQud3JpdGVCeXRlKDB4MDApO1xuXG5cdFx0XHQvLyB3aGl0ZVxuXHRcdFx0b3V0LndyaXRlQnl0ZSgweGZmKTtcblx0XHRcdG91dC53cml0ZUJ5dGUoMHhmZik7XG5cdFx0XHRvdXQud3JpdGVCeXRlKDB4ZmYpO1xuXG5cdFx0XHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRcdFx0Ly8gSW1hZ2UgRGVzY3JpcHRvclxuXG5cdFx0XHRvdXQud3JpdGVTdHJpbmcoJywnKTtcblx0XHRcdG91dC53cml0ZVNob3J0KDApO1xuXHRcdFx0b3V0LndyaXRlU2hvcnQoMCk7XG5cdFx0XHRvdXQud3JpdGVTaG9ydChfd2lkdGgpO1xuXHRcdFx0b3V0LndyaXRlU2hvcnQoX2hlaWdodCk7XG5cdFx0XHRvdXQud3JpdGVCeXRlKDApO1xuXG5cdFx0XHQvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXHRcdFx0Ly8gTG9jYWwgQ29sb3IgTWFwXG5cblx0XHRcdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdFx0XHQvLyBSYXN0ZXIgRGF0YVxuXG5cdFx0XHR2YXIgbHp3TWluQ29kZVNpemUgPSAyO1xuXHRcdFx0dmFyIHJhc3RlciA9IGdldExaV1Jhc3RlcihsendNaW5Db2RlU2l6ZSk7XG5cblx0XHRcdG91dC53cml0ZUJ5dGUobHp3TWluQ29kZVNpemUpO1xuXG5cdFx0XHR2YXIgb2Zmc2V0ID0gMDtcblxuXHRcdFx0d2hpbGUgKHJhc3Rlci5sZW5ndGggLSBvZmZzZXQgPiAyNTUpIHtcblx0XHRcdFx0b3V0LndyaXRlQnl0ZSgyNTUpO1xuXHRcdFx0XHRvdXQud3JpdGVCeXRlcyhyYXN0ZXIsIG9mZnNldCwgMjU1KTtcblx0XHRcdFx0b2Zmc2V0ICs9IDI1NTtcblx0XHRcdH1cblxuXHRcdFx0b3V0LndyaXRlQnl0ZShyYXN0ZXIubGVuZ3RoIC0gb2Zmc2V0KTtcblx0XHRcdG91dC53cml0ZUJ5dGVzKHJhc3Rlciwgb2Zmc2V0LCByYXN0ZXIubGVuZ3RoIC0gb2Zmc2V0KTtcblx0XHRcdG91dC53cml0ZUJ5dGUoMHgwMCk7XG5cblx0XHRcdC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cdFx0XHQvLyBHSUYgVGVybWluYXRvclxuXHRcdFx0b3V0LndyaXRlU3RyaW5nKCc7Jyk7XG5cdFx0fTtcblxuXHRcdHZhciBiaXRPdXRwdXRTdHJlYW0gPSBmdW5jdGlvbihvdXQpIHtcblxuXHRcdFx0dmFyIF9vdXQgPSBvdXQ7XG5cdFx0XHR2YXIgX2JpdExlbmd0aCA9IDA7XG5cdFx0XHR2YXIgX2JpdEJ1ZmZlciA9IDA7XG5cblx0XHRcdHZhciBfdGhpcyA9IHt9O1xuXG5cdFx0XHRfdGhpcy53cml0ZSA9IGZ1bmN0aW9uKGRhdGEsIGxlbmd0aCkge1xuXG5cdFx0XHRcdGlmICggKGRhdGEgPj4+IGxlbmd0aCkgIT0gMCkge1xuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcignbGVuZ3RoIG92ZXInKTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHdoaWxlIChfYml0TGVuZ3RoICsgbGVuZ3RoID49IDgpIHtcblx0XHRcdFx0XHRfb3V0LndyaXRlQnl0ZSgweGZmICYgKCAoZGF0YSA8PCBfYml0TGVuZ3RoKSB8IF9iaXRCdWZmZXIpICk7XG5cdFx0XHRcdFx0bGVuZ3RoIC09ICg4IC0gX2JpdExlbmd0aCk7XG5cdFx0XHRcdFx0ZGF0YSA+Pj49ICg4IC0gX2JpdExlbmd0aCk7XG5cdFx0XHRcdFx0X2JpdEJ1ZmZlciA9IDA7XG5cdFx0XHRcdFx0X2JpdExlbmd0aCA9IDA7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRfYml0QnVmZmVyID0gKGRhdGEgPDwgX2JpdExlbmd0aCkgfCBfYml0QnVmZmVyO1xuXHRcdFx0XHRfYml0TGVuZ3RoID0gX2JpdExlbmd0aCArIGxlbmd0aDtcblx0XHRcdH07XG5cblx0XHRcdF90aGlzLmZsdXNoID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRcdGlmIChfYml0TGVuZ3RoID4gMCkge1xuXHRcdFx0XHRcdF9vdXQud3JpdGVCeXRlKF9iaXRCdWZmZXIpO1xuXHRcdFx0XHR9XG5cdFx0XHR9O1xuXG5cdFx0XHRyZXR1cm4gX3RoaXM7XG5cdFx0fTtcblxuXHRcdHZhciBnZXRMWldSYXN0ZXIgPSBmdW5jdGlvbihsendNaW5Db2RlU2l6ZSkge1xuXG5cdFx0XHR2YXIgY2xlYXJDb2RlID0gMSA8PCBsendNaW5Db2RlU2l6ZTtcblx0XHRcdHZhciBlbmRDb2RlID0gKDEgPDwgbHp3TWluQ29kZVNpemUpICsgMTtcblx0XHRcdHZhciBiaXRMZW5ndGggPSBsendNaW5Db2RlU2l6ZSArIDE7XG5cblx0XHRcdC8vIFNldHVwIExaV1RhYmxlXG5cdFx0XHR2YXIgdGFibGUgPSBsendUYWJsZSgpO1xuXG5cdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGNsZWFyQ29kZTsgaSArPSAxKSB7XG5cdFx0XHRcdHRhYmxlLmFkZChTdHJpbmcuZnJvbUNoYXJDb2RlKGkpICk7XG5cdFx0XHR9XG5cdFx0XHR0YWJsZS5hZGQoU3RyaW5nLmZyb21DaGFyQ29kZShjbGVhckNvZGUpICk7XG5cdFx0XHR0YWJsZS5hZGQoU3RyaW5nLmZyb21DaGFyQ29kZShlbmRDb2RlKSApO1xuXG5cdFx0XHR2YXIgYnl0ZU91dCA9IGJ5dGVBcnJheU91dHB1dFN0cmVhbSgpO1xuXHRcdFx0dmFyIGJpdE91dCA9IGJpdE91dHB1dFN0cmVhbShieXRlT3V0KTtcblxuXHRcdFx0Ly8gY2xlYXIgY29kZVxuXHRcdFx0Yml0T3V0LndyaXRlKGNsZWFyQ29kZSwgYml0TGVuZ3RoKTtcblxuXHRcdFx0dmFyIGRhdGFJbmRleCA9IDA7XG5cblx0XHRcdHZhciBzID0gU3RyaW5nLmZyb21DaGFyQ29kZShfZGF0YVtkYXRhSW5kZXhdKTtcblx0XHRcdGRhdGFJbmRleCArPSAxO1xuXG5cdFx0XHR3aGlsZSAoZGF0YUluZGV4IDwgX2RhdGEubGVuZ3RoKSB7XG5cblx0XHRcdFx0dmFyIGMgPSBTdHJpbmcuZnJvbUNoYXJDb2RlKF9kYXRhW2RhdGFJbmRleF0pO1xuXHRcdFx0XHRkYXRhSW5kZXggKz0gMTtcblxuXHRcdFx0XHRpZiAodGFibGUuY29udGFpbnMocyArIGMpICkge1xuXG5cdFx0XHRcdFx0cyA9IHMgKyBjO1xuXG5cdFx0XHRcdH0gZWxzZSB7XG5cblx0XHRcdFx0XHRiaXRPdXQud3JpdGUodGFibGUuaW5kZXhPZihzKSwgYml0TGVuZ3RoKTtcblxuXHRcdFx0XHRcdGlmICh0YWJsZS5zaXplKCkgPCAweGZmZikge1xuXG5cdFx0XHRcdFx0XHRpZiAodGFibGUuc2l6ZSgpID09ICgxIDw8IGJpdExlbmd0aCkgKSB7XG5cdFx0XHRcdFx0XHRcdGJpdExlbmd0aCArPSAxO1xuXHRcdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0XHR0YWJsZS5hZGQocyArIGMpO1xuXHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdHMgPSBjO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdGJpdE91dC53cml0ZSh0YWJsZS5pbmRleE9mKHMpLCBiaXRMZW5ndGgpO1xuXG5cdFx0XHQvLyBlbmQgY29kZVxuXHRcdFx0Yml0T3V0LndyaXRlKGVuZENvZGUsIGJpdExlbmd0aCk7XG5cblx0XHRcdGJpdE91dC5mbHVzaCgpO1xuXG5cdFx0XHRyZXR1cm4gYnl0ZU91dC50b0J5dGVBcnJheSgpO1xuXHRcdH07XG5cblx0XHR2YXIgbHp3VGFibGUgPSBmdW5jdGlvbigpIHtcblxuXHRcdFx0dmFyIF9tYXAgPSB7fTtcblx0XHRcdHZhciBfc2l6ZSA9IDA7XG5cblx0XHRcdHZhciBfdGhpcyA9IHt9O1xuXG5cdFx0XHRfdGhpcy5hZGQgPSBmdW5jdGlvbihrZXkpIHtcblx0XHRcdFx0aWYgKF90aGlzLmNvbnRhaW5zKGtleSkgKSB7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKCdkdXAga2V5OicgKyBrZXkpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdF9tYXBba2V5XSA9IF9zaXplO1xuXHRcdFx0XHRfc2l6ZSArPSAxO1xuXHRcdFx0fTtcblxuXHRcdFx0X3RoaXMuc2l6ZSA9IGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRyZXR1cm4gX3NpemU7XG5cdFx0XHR9O1xuXG5cdFx0XHRfdGhpcy5pbmRleE9mID0gZnVuY3Rpb24oa2V5KSB7XG5cdFx0XHRcdHJldHVybiBfbWFwW2tleV07XG5cdFx0XHR9O1xuXG5cdFx0XHRfdGhpcy5jb250YWlucyA9IGZ1bmN0aW9uKGtleSkge1xuXHRcdFx0XHRyZXR1cm4gdHlwZW9mIF9tYXBba2V5XSAhPSAndW5kZWZpbmVkJztcblx0XHRcdH07XG5cblx0XHRcdHJldHVybiBfdGhpcztcblx0XHR9O1xuXG5cdFx0cmV0dXJuIF90aGlzO1xuXHR9O1xuXG5cdHZhciBjcmVhdGVJbWdUYWcgPSBmdW5jdGlvbih3aWR0aCwgaGVpZ2h0LCBnZXRQaXhlbCwgYWx0KSB7XG5cblx0XHR2YXIgZ2lmID0gZ2lmSW1hZ2Uod2lkdGgsIGhlaWdodCk7XG5cdFx0Zm9yICh2YXIgeSA9IDA7IHkgPCBoZWlnaHQ7IHkgKz0gMSkge1xuXHRcdFx0Zm9yICh2YXIgeCA9IDA7IHggPCB3aWR0aDsgeCArPSAxKSB7XG5cdFx0XHRcdGdpZi5zZXRQaXhlbCh4LCB5LCBnZXRQaXhlbCh4LCB5KSApO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHZhciBiID0gYnl0ZUFycmF5T3V0cHV0U3RyZWFtKCk7XG5cdFx0Z2lmLndyaXRlKGIpO1xuXG5cdFx0dmFyIGJhc2U2NCA9IGJhc2U2NEVuY29kZU91dHB1dFN0cmVhbSgpO1xuXHRcdHZhciBieXRlcyA9IGIudG9CeXRlQXJyYXkoKTtcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IGJ5dGVzLmxlbmd0aDsgaSArPSAxKSB7XG5cdFx0XHRiYXNlNjQud3JpdGVCeXRlKGJ5dGVzW2ldKTtcblx0XHR9XG5cdFx0YmFzZTY0LmZsdXNoKCk7XG5cblx0XHR2YXIgaW1nID0gJyc7XG5cdFx0aW1nICs9ICc8aW1nJztcblx0XHRpbWcgKz0gJ1xcdTAwMjBzcmM9XCInO1xuXHRcdGltZyArPSAnZGF0YTppbWFnZS9naWY7YmFzZTY0LCc7XG5cdFx0aW1nICs9IGJhc2U2NDtcblx0XHRpbWcgKz0gJ1wiJztcblx0XHRpbWcgKz0gJ1xcdTAwMjB3aWR0aD1cIic7XG5cdFx0aW1nICs9IHdpZHRoO1xuXHRcdGltZyArPSAnXCInO1xuXHRcdGltZyArPSAnXFx1MDAyMGhlaWdodD1cIic7XG5cdFx0aW1nICs9IGhlaWdodDtcblx0XHRpbWcgKz0gJ1wiJztcblx0XHRpZiAoYWx0KSB7XG5cdFx0XHRpbWcgKz0gJ1xcdTAwMjBhbHQ9XCInO1xuXHRcdFx0aW1nICs9IGFsdDtcblx0XHRcdGltZyArPSAnXCInO1xuXHRcdH1cblx0XHRpbWcgKz0gJy8+JztcblxuXHRcdHJldHVybiBpbWc7XG5cdH07XG5cblx0Ly8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblx0Ly8gcmV0dXJucyBxcmNvZGUgZnVuY3Rpb24uXG5cblx0cmV0dXJuIHFyY29kZTtcbn0oKTtcbiIsIm1vZHVsZS5leHBvcnRzID0gKGZ1bmN0aW9uICgkKSB7XG4gICAgXCJ1c2Ugc3RyaWN0XCI7XG4gICAgZnVuY3Rpb24gZ2V0SnNvbldpdGhQcm9taXNlKHVybCkge1xuXG4gICAgICAgIHJldHVybiAkLmdldEpTT04odXJsKTtcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBnZXQocGF0aCkge1xuICAgICAgICByZXR1cm4gJC5nZXQocGF0aCk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcG9zdFdpdGhQcm9taXNlKHVybCwgZGF0YSkge1xuICAgICAgICByZXR1cm4gJC5wb3N0KHVybCwgZGF0YSk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcG9zdChwYXRoLCBkYXRhLCBzdWNjZXNzLCBlcnJvcikge1xuICAgICAgICAkLmFqYXgoe1xuICAgICAgICAgICAgdXJsOiBwYXRoLFxuICAgICAgICAgICAgdHlwZTogJ1BPU1QnLFxuICAgICAgICAgICAgZGF0YTogZGF0YSxcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHN1Y2Nlc3MsXG4gICAgICAgICAgICBlcnJvcjogZXJyb3JcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcHV0KHBhdGgsIGRhdGEsIHN1Y2Nlc3MsIGVycm9yKSB7XG4gICAgICAgICQuYWpheChcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB1cmw6IHBhdGgsXG4gICAgICAgICAgICAgICAgdHlwZTogJ1BVVCcsXG4gICAgICAgICAgICAgICAgZGF0YTogZGF0YSxcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiBzdWNjZXNzLFxuICAgICAgICAgICAgICAgIGVycm9yOiBlcnJvclxuICAgICAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gcHV0V2l0aFByb21pc2UocGF0aCwgZGF0YSkge1xuICAgICAgICByZXR1cm4gJC5hamF4KHtcbiAgICAgICAgICAgIHVybDogcGF0aCxcbiAgICAgICAgICAgIHR5cGU6ICdQVVQnLFxuICAgICAgICAgICAgZGF0YTogZGF0YSxcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlOiAnYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOCcsXG4gICAgICAgICAgICBkYXRhVHlwZTogJ2pzb24nXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIGZ1bmN0aW9uIHJlbW92ZShwYXRoKSB7XG4gICAgICAgIHJldHVybiAkLmFqYXgoe1xuICAgICAgICAgICAgdXJsOiBwYXRoLFxuICAgICAgICAgICAgdHlwZTogJ0RFTEVURSdcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgICAgZ2V0SnNvbldpdGhQcm9taXNlOiBnZXRKc29uV2l0aFByb21pc2UsXG4gICAgICAgIGdldDogZ2V0LFxuICAgICAgICBwb3N0V2l0aFByb21pc2U6IHBvc3RXaXRoUHJvbWlzZSxcbiAgICAgICAgcG9zdDogcG9zdCxcbiAgICAgICAgcHV0V2l0aFByb21pc2U6IHB1dFdpdGhQcm9taXNlLFxuICAgICAgICBwdXQ6IHB1dCxcbiAgICAgICAgcmVtb3ZlOiByZW1vdmVcbiAgICB9O1xufSkoalF1ZXJ5KTtcblxuIiwidmFyIGRpcmVjdG9yID0gcmVxdWlyZSgnZGlyZWN0b3InKSxcbiAgICB2aWV3RW5naW5lID0gcmVxdWlyZSgnLi4vaW5mcmFzdHJ1Y3R1cmUvdmlld19lbmdpbmUnKTtcblxudmFyIHJvdXRlcyA9IHtcbiAgICBcIi93ZWl4aW4vam9pbi9hY3Rpdml0eS86b3Blbl9pZC86YWN0aXZpdHlfaWRcIjogZnVuY3Rpb24gKG9wZW5JZCwgYWN0aXZpdHlJZCkge1xuICAgICAgICB2aWV3RW5naW5lLmJpbmRWaWV3KFwiL2pvaW4tYWN0aXZpdHlcIiwge1xuICAgICAgICAgICAgb3BlbklkOiBvcGVuSWQsXG4gICAgICAgICAgICBhY3Rpdml0eUlkOiBhY3Rpdml0eUlkXG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXG4gICAgY29uZmlndXJlOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciByb3V0ZXIgPSBuZXcgZGlyZWN0b3IuUm91dGVyKHJvdXRlcyk7XG5cbiAgICAgICAgcm91dGVyLmluaXQoKTtcbiAgICAgICAgcmV0dXJuIHJvdXRlcjtcbiAgICB9XG59OyIsInZhciB2aWV3UmVzb2x2ZXIgPSByZXF1aXJlKCcuL3ZpZXdfcmVzb2x2ZXInKSxcbiAgICB2aWV3TW9kZWxSZXNvbHZlciA9IHJlcXVpcmUoJy4vdmlld19tb2RlbF9yZXNvbHZlcicpO1xuXG5mdW5jdGlvbiBkb0JpbmQoVmlld01vZGVsLCB2aWV3LCBkYXRhKSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuICAgICQoZnVuY3Rpb24gKCkge1xuICAgICAgICBrby5wb3N0Ym94LnJlc2V0KCk7XG4gICAgICAgIHZhciBzZlZpZXcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2YtdmlldycpO1xuICAgICAgICAkKHNmVmlldykuaHRtbCh2aWV3KTtcbiAgICAgICAga28uY2xlYW5Ob2RlKHNmVmlldyk7XG4gICAgICAgIGtvLmFwcGx5QmluZGluZ3MobmV3IFZpZXdNb2RlbChkYXRhKSwgc2ZWaWV3KTtcbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gdmlld1Jlc29sdmVyQ29tcGxldGUocm91dGVOYW1lLCB2aWV3LCBkYXRhKSB7XG4gICAgdmFyIHZpZXdNb2RlbCA9IHZpZXdNb2RlbFJlc29sdmVyLnJlc29sdmVWaWV3TW9kZWwocm91dGVOYW1lKTtcbiAgICBkb0JpbmQodmlld01vZGVsLCB2aWV3LCBkYXRhKTtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgYmluZFZpZXc6IGZ1bmN0aW9uIChyb3V0ZU5hbWUsIGRhdGEpIHtcblxuICAgICAgICByZXR1cm4gdmlld1Jlc29sdmVyLnJlc29sdmVWaWV3KHJvdXRlTmFtZSlcbiAgICAgICAgICAgIC5kb25lKGZ1bmN0aW9uICh2aWV3KSB7XG4gICAgICAgICAgICAgICAgdmlld1Jlc29sdmVyQ29tcGxldGUocm91dGVOYW1lLCB2aWV3LCBkYXRhKTtcbiAgICAgICAgICAgIH0pO1xuICAgIH1cbn07XG4iLCIvL1RPRE8gUmVxdWlyZSB0aGlzIGluIHRoZSBmdXR1cmVcblxuLy92YXIgU3RhZmZpbmdQcm94eVZpZXdNb2RlbCA9IHJlcXVpcmUoJy4uL3ZpZXdfbW9kZWxzL3N0YWZmaW5nX3Byb3h5X3ZpZXdfbW9kZWwnKTtcbi8vdmFyIE9wcG9ydHVuaXR5RGV0YWlsc01vZGVsID0gcmVxdWlyZSgnLi4vdmlld19tb2RlbHMvb3Bwb3J0dW5pdHlfdmlld19tb2RlbCcpO1xuLy92YXIgT3Bwb3J0dW5pdHlSb2xlVmlld01vZGVsID0gcmVxdWlyZSgnLi4vdmlld19tb2RlbHMvb3Bwb3J0dW5pdHlfcm9sZV92aWV3X21vZGVsJyk7XG5cbi8vdmFyIHZpZXdNb2RlbHMgPSB7XG4vLyAgICBcIi9yb2xlXCI6IFN0YWZmaW5nUHJveHlWaWV3TW9kZWwsXG4vLyAgICBcIi9vcHBvcnR1bml0eS1kZXRhaWxzXCI6IE9wcG9ydHVuaXR5RGV0YWlsc01vZGVsLFxuLy8gICAgXCIvb3Bwb3J0dW5pdHktc3RhZmZpbmdcIjogT3Bwb3J0dW5pdHlSb2xlVmlld01vZGVsXG4vL307XG4vL1xuLy9tb2R1bGUuZXhwb3J0cyA9IHtcbi8vICAgIHJlc29sdmVWaWV3TW9kZWw6IGZ1bmN0aW9uIChyb3V0ZU5hbWUpIHtcbi8vICAgICAgICByZXR1cm4gdmlld01vZGVsc1tyb3V0ZU5hbWVdO1xuLy8gICAgfVxuLy99OyIsInZhciBhamF4V3JhcHBlciA9IHJlcXVpcmUoJy4uL2FqYXhfd3JhcHBlcicpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IChmdW5jdGlvbiAoKSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuICAgIHZhciB2aWV3QmFzZSA9IFwiL3ZpZXdzL3BhcnRpYWxzXCIsXG4gICAgICAgIHZpZXdCYXNlRXh0ZW5zaW9uID0gXCIuaHRtbFwiLFxuICAgICAgICB2aWV3Q2FjaGUgPSB7fTtcblxuICAgIHJldHVybiB7XG4gICAgICAgIHJlc29sdmVWaWV3OiBmdW5jdGlvbiAocm91dGVOYW1lKSB7XG4gICAgICAgICAgICB2YXIgZGVmZXJyZWQgPSAkLkRlZmVycmVkKCk7XG5cbiAgICAgICAgICAgIGlmICh2aWV3Q2FjaGUuaGFzT3duUHJvcGVydHkocm91dGVOYW1lKSkge1xuICAgICAgICAgICAgICAgIHZhciBjYWNoZWRWaWV3ID0gdmlld0NhY2hlW3JvdXRlTmFtZV07XG4gICAgICAgICAgICAgICAgZGVmZXJyZWQucmVzb2x2ZSgkLnBhcnNlSFRNTChjYWNoZWRWaWV3KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBhamF4V3JhcHBlci5nZXQodmlld0Jhc2UgKyByb3V0ZU5hbWUudG9Mb3dlckNhc2UoKSArIHZpZXdCYXNlRXh0ZW5zaW9uKVxuICAgICAgICAgICAgICAgICAgICAuZG9uZShmdW5jdGlvbiAodmlld0FzU3RyaW5nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3Q2FjaGVbcm91dGVOYW1lXSA9IHZpZXdBc1N0cmluZztcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmVycmVkLnJlc29sdmUoJC5wYXJzZUhUTUwodmlld0FzU3RyaW5nKSk7XG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5mYWlsKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmVycmVkLnJlamVjdCgnVmlldyBub3QgZm91bmQgYXQgcm91dGUnKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZGVmZXJyZWQucHJvbWlzZSgpO1xuICAgICAgICB9XG4gICAgfTtcbn0pKCk7IiwidmFyIGRvbVJlYWR5ID0gcmVxdWlyZSgnZG9tcmVhZHknKSxcbiAgICByb3V0ZUNvbmZpZyA9IHJlcXVpcmUoJy4vY29uZmlnL3JvdXRlcycpLFxuICAgIHJvdXRlcjtcblxubW9kdWxlLmV4cG9ydHMuaG9tZVBhZ2VWaWV3TW9kZWxGYWN0b3J5ID0gcmVxdWlyZShcIi4vdmlld19tb2RlbHMvaG9tZV9wYWdlX3ZpZXdfbW9kZWxfZmFjdG9yeVwiKTtcbm1vZHVsZS5leHBvcnRzLmFjdGl2aXR5UGFnZVZpZXdNb2RlbEZhY3RvcnkgPSByZXF1aXJlKFwiLi92aWV3X21vZGVscy9hY3Rpdml0eV9wYWdlX3ZpZXdfbW9kZWxfZmFjdG9yeVwiKTtcbm1vZHVsZS5leHBvcnRzLmpvaW5BY3Rpdml0eVBhZ2VWaWV3TW9kZWxGYWN0b3J5ID0gcmVxdWlyZShcIi4vdmlld19tb2RlbHMvam9pbl9hY3Rpdml0eV9wYWdlX3ZpZXdfbW9kZWxfZmFjdG9yeVwiKTtcblxuXG5kb21SZWFkeShmdW5jdGlvbiAoKSB7XG4gICAgcm91dGVyID0gcm91dGVDb25maWcuY29uZmlndXJlKCk7XG4gICAgbW9kdWxlLmV4cG9ydHMucm91dGVyID0gcm91dGVyO1xufSk7XG5cbiIsInZhciBhamF4ID0gcmVxdWlyZSgnLi4vYWpheF93cmFwcGVyJyk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXG4gICAgZ2V0QWxsQWN0aXZpdGllczogZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZGVmZXJyZWQgPSAkLkRlZmVycmVkKCk7XG5cbiAgICAgICAgYWpheC5nZXRKc29uV2l0aFByb21pc2UoJy93ZWl4aW4vZ2V0L2FsbC9hY3Rpdml0aWVzJylcbiAgICAgICAgICAgIC5kb25lKGZ1bmN0aW9uIChhY3Rpdml0aWVzKSB7XG4gICAgICAgICAgICAgICAgZGVmZXJyZWQucmVzb2x2ZShhY3Rpdml0aWVzKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZGVmZXJyZWQucHJvbWlzZSgpO1xuICAgIH1cbn07IiwidmFyIGFqYXggPSByZXF1aXJlKCcuLi9hamF4X3dyYXBwZXInKTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICBnZXRVc2VyQWN0aXZpdHlTdGF0dXM6IGZ1bmN0aW9uIChvcGVuSWQsIGFjdGl2aXR5SWQpIHtcbiAgICAgICAgdmFyIGRlZmVycmVkID0gJC5EZWZlcnJlZCgpO1xuXG4gICAgICAgIHZhciBwYXJhbXMgPSAnaWhha3VsYV9yZXF1ZXN0PWloYWt1bGFfbm9ydGhlcm5faGVtaXNwaGVyZSdcbiAgICAgICAgICAgICsgJyZvcGVuX2lkPScgKyBvcGVuSWRcbiAgICAgICAgICAgICsgJyZhY3Rpdml0eV9pZD0nICsgYWN0aXZpdHlJZDtcbiAgICAgICAgYWpheC5nZXRKc29uV2l0aFByb21pc2UoJy93ZWl4aW4vZ2V0L3VzZXIvYWN0aXZpdHkvc3RhdHVzPycgKyBwYXJhbXMpXG4gICAgICAgICAgICAuZG9uZShmdW5jdGlvbiAodXNlckFjdGl2aXR5SW5mbykge1xuICAgICAgICAgICAgICAgIGRlZmVycmVkLnJlc29sdmUodXNlckFjdGl2aXR5SW5mbyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGRlZmVycmVkLnByb21pc2UoKTtcbiAgICB9LFxuXG4gICAgZHJhd1ByaXplOiBmdW5jdGlvbiAob3BlbklkLCBhY3Rpdml0eUlkKSB7XG4gICAgICAgIHZhciBkZWZlcnJlZCA9ICQuRGVmZXJyZWQoKTtcblxuICAgICAgICB2YXIgcGFyYW1zID0gb3BlbklkICsgJy8nICsgYWN0aXZpdHlJZCArICAnP2loYWt1bGFfcmVxdWVzdD1paGFrdWxhX25vcnRoZXJuX2hlbWlzcGhlcmUnO1xuICAgICAgICBhamF4LmdldEpzb25XaXRoUHJvbWlzZSgnL3dlaXhpbi91c2VyL2RyYXcvcHJpemUvJyArIHBhcmFtcylcbiAgICAgICAgICAgIC5kb25lKGZ1bmN0aW9uICh1c2VyQWN0aXZpdHlJbmZvKSB7XG4gICAgICAgICAgICAgICAgZGVmZXJyZWQucmVzb2x2ZSh1c2VyQWN0aXZpdHlJbmZvKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZGVmZXJyZWQucHJvbWlzZSgpO1xuICAgIH1cbn07IiwidmFyIGFqYXggPSByZXF1aXJlKCcuLi9hamF4X3dyYXBwZXInKTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG5cbiAgICBnZXRBbGxTYWxlUmVjb3JkczogZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZGVmZXJyZWQgPSAkLkRlZmVycmVkKCk7XG5cbiAgICAgICAgYWpheC5nZXRKc29uV2l0aFByb21pc2UoJy9zYWxlL3JlY29yZHMnKVxuICAgICAgICAgICAgLmRvbmUoZnVuY3Rpb24gKHJlY29yZHMpIHtcbiAgICAgICAgICAgICAgICBkZWZlcnJlZC5yZXNvbHZlKHJlY29yZHMpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBkZWZlcnJlZC5wcm9taXNlKCk7XG4gICAgfVxufTsiLCJ2YXIgQWN0aXZpdHlQYWdlVmlld01vZGVsID0gcmVxdWlyZSgnLi9hY3Rpdml0eXBhZ2Vfdmlld19tb2RlbCcpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBhcHBseVRvUGFnZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBzZlZpZXcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2YtdmlldycpO1xuICAgICAgICBrby5hcHBseUJpbmRpbmdzKG5ldyBBY3Rpdml0eVBhZ2VWaWV3TW9kZWwoKSwgc2ZWaWV3KTtcbiAgICB9XG59OyIsInZhciBzYWxlc19zZXJ2aWNlID0gcmVxdWlyZSgnLi4vc2VydmljZXMvYWN0aXZpdHlfc2VydmljZS5qcycpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IChmdW5jdGlvbiAoKSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuICAgIHZhciBzZWxmO1xuXG4gICAgZnVuY3Rpb24gSG9tZXBhZ2VWaWV3TW9kZWwoKSB7XG4gICAgICAgIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLnVzZXJzSWRBcnIgPSBudWxsO1xuICAgICAgICBzZWxmLnVzZXJzRGV0YWlsRGljID0gbnVsbDtcbiAgICAgICAgc2VsZi51c2Vyc1NhbGVEaWMgPSBudWxsO1xuICAgICAgICBzZWxmLmFjY291bnRGaWVsZEFyciA9IG51bGw7XG4gICAgICAgIHNlbGYuYWNjb3VudEZpZWxkRGV0YWlsQXJyID0gbnVsbDtcbiAgICAgICAgc2VsZi5hY3Rpdml0aWVzID0ga28ub2JzZXJ2YWJsZUFycmF5KFtdKTtcbiAgICAgICAgc2VsZi51c2VyRmluYWNpYWwgPSBrby5vYnNlcnZhYmxlQXJyYXkoW10pO1xuICAgICAgICBzZWxmLmlzTG9hZGluZyA9IGtvLm9ic2VydmFibGUodHJ1ZSk7XG5cbiAgICAgICAgc2VsZi5pbml0aWFsaXNlKCk7XG5cbiAgICAgICAgc2VsZi5jYWNoZUNhY2hlcyA9IGZ1bmN0aW9uKGRhdGEpe1xuICAgICAgICAgICAgc2VsZi51c2Vyc0lkQXJyID0gZGF0YVtcInVzZXJzXCJdLnNwbGl0KFwiLFwiKTtcbiAgICAgICAgICAgIHNlbGYudXNlcnNEZXRhaWxEaWMgPSBkYXRhW1widXNlcnNfZGV0YWlsX2luZm9cIl07XG4gICAgICAgICAgICBzZWxmLnVzZXJzU2FsZURpYyA9IGRhdGFbXCJ1c2Vyc19zYWxlX3JlY29yZHNcIl07XG4gICAgICAgICAgICBzZWxmLmFjY291bnRGaWVsZEFyciA9IGRhdGFbXCJhY2NvdW50X2ZpZWxkXCJdO1xuICAgICAgICAgICAgc2VsZi5hY2NvdW50RmllbGREZXRhaWxBcnIgPSBkYXRhW1wiYWNjb3VudF9maWVsZF9kZXRhaWxcIl07XG4gICAgICAgIH07XG5cbiAgICAgICAgc2VsZi5jYWN1bGF0ZVJlY29yZHMgPSBmdW5jdGlvbigpe1xuICAgICAgICAgICAgdmFyIGFsbFJlY29yZHMgPSBbXTtcbiAgICAgICAgICAgIHZhciB0b3RhbEVhcm4gPSAwLjA7XG4gICAgICAgICAgICB2YXIgdG90YWxDb3N0ID0gMC4wO1xuICAgICAgICAgICAgdmFyIHVzZXJDb3N0QW5kRWFybiA9IFtdO1xuICAgICAgICAgICAgXy5lYWNoKHNlbGYudXNlcnNJZEFyciwgZnVuY3Rpb24odXNlcklkKXtcbiAgICAgICAgICAgICAgICB2YXIgdXNlckVhcm4gPSAwLjA7XG4gICAgICAgICAgICAgICAgdmFyIHVzZXJDb3N0ID0gMC4wO1xuICAgICAgICAgICAgICAgIHZhciB1c2VyTmFtZSA9IHNlbGYudXNlcnNEZXRhaWxEaWNbdXNlcklkXVsndXNlcl9uaWNrbmFtZSddO1xuICAgICAgICAgICAgICAgIHZhciBwZXJzb25SZWNvcmRzID0gc2VsZi51c2Vyc1NhbGVEaWNbdXNlcklkXTtcbiAgICAgICAgICAgICAgICBfLmVhY2gocGVyc29uUmVjb3JkcywgZnVuY3Rpb24gKHJlY29yZCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IGdldEZpZWxkQnlGaWVsZElEKHJlY29yZC5maWVsZF9pZClbMF07XG4gICAgICAgICAgICAgICAgICAgIHZhciBpdGVtRGV0YWlsID0gZ2V0RmllbGREZXRhaWxCeUZpZWxkRGV0YWlsSWQocmVjb3JkLmZpZWxkX2RldGFpbF9pZClbMF07XG4gICAgICAgICAgICAgICAgICAgIHZhciBzdGFydFNpZ24gPSBpdGVtLnR5cGUgPyAnKCspICcgOiAnKC0pICc7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0ZXh0ID0gc3RhcnRTaWduO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyRWFybiArPSByZWNvcmQubW9uZXk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyQ29zdCArPSByZWNvcmQubW9uZXk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGV4dCArPSBpdGVtLmZpZWxkICsgJzonICsgaXRlbURldGFpbC5uYW1lICsgJyAnICsgcmVjb3JkLm1vbmV5ICsgJyhDTlkpOyAnICsgcmVjb3JkLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgICAgICBhbGxSZWNvcmRzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgJ3RleHQnOiB0ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgJ2RhdGUnOiByZWNvcmQuZGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICdtb25leSc6IHN0YXJ0U2lnbiArIHJlY29yZC5tb25leSxcbiAgICAgICAgICAgICAgICAgICAgICAgICd1c2VyJzogdXNlck5hbWVcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdXNlckNvc3RBbmRFYXJuLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAndGV4dCc6IHVzZXJOYW1lLFxuICAgICAgICAgICAgICAgICAgICAndG90YWxDb3N0JzogdXNlckNvc3QsXG4gICAgICAgICAgICAgICAgICAgICd0b3RhbEVhcm4nOiB1c2VyRWFybixcbiAgICAgICAgICAgICAgICAgICAgJ3JldmVudWUnOiAodXNlckVhcm4gLSB1c2VyQ29zdCkudG9GaXhlZCgyKVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRvdGFsQ29zdCArPSB1c2VyQ29zdDtcbiAgICAgICAgICAgICAgICB0b3RhbEVhcm4gKz0gdXNlckVhcm47XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgc2VsZi51c2VyRmluYWNpYWwoW3tcbiAgICAgICAgICAgICAgICAndGV4dCc6ICflkIjorqEnLFxuICAgICAgICAgICAgICAgICd0b3RhbENvc3QnOiB0b3RhbENvc3QsXG4gICAgICAgICAgICAgICAgJ3RvdGFsRWFybic6IHRvdGFsRWFybixcbiAgICAgICAgICAgICAgICAncmV2ZW51ZSc6ICh0b3RhbEVhcm4gLSB0b3RhbENvc3QpLnRvRml4ZWQoMilcbiAgICAgICAgICAgIH1dLmNvbmNhdCh1c2VyQ29zdEFuZEVhcm4pKTtcblxuICAgICAgICAgICAgdmFyIHNvcnRlZFJlY29yZHMgPSBfLmNoYWluKGFsbFJlY29yZHMpXG4gICAgICAgICAgICAgICAgLnNvcnRCeShmdW5jdGlvbiAocmVjb3JkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZWNvcmQuZGF0ZTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5yZXZlcnNlKClcbiAgICAgICAgICAgICAgICAudmFsdWUoKTtcbiAgICAgICAgICAgIHNlbGYuc2FsZVJlY29yZHMoc29ydGVkUmVjb3Jkcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gZ2V0RmllbGRCeUZpZWxkSUQgKGZpZWxkSWQpe1xuICAgICAgICAgICAgcmV0dXJuIF8uZmlsdGVyKHNlbGYuYWNjb3VudEZpZWxkQXJyLCBmdW5jdGlvbihmaWVsZCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZpZWxkW1wiSURcIl0gPT09IGZpZWxkSWQ7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBnZXRGaWVsZERldGFpbEJ5RmllbGREZXRhaWxJZCAoZGV0YWlsSWQpe1xuICAgICAgICAgICAgcmV0dXJuIF8uZmlsdGVyKHNlbGYuYWNjb3VudEZpZWxkRGV0YWlsQXJyLCBmdW5jdGlvbihmaWVsZCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZpZWxkW1wiSURcIl0gPT09IGRldGFpbElkO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgfTtcblxuICAgIEhvbWVwYWdlVmlld01vZGVsLnByb3RvdHlwZS5pbml0aWFsaXNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gc2FsZXNfc2VydmljZS5nZXRBbGxBY3Rpdml0aWVzKClcbiAgICAgICAgICAgIC5kb25lKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XG4gICAgICAgICAgICAgICAgc2VsZi5jYWNoZUNhY2hlcyhkYXRhKTtcbiAgICAgICAgICAgICAgICBzZWxmLmNhY3VsYXRlUmVjb3JkcygpO1xuICAgICAgICAgICAgICAgIHNlbGYuaXNMb2FkaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIH0pO1xuICAgIH07XG5cbiAgICByZXR1cm4gSG9tZXBhZ2VWaWV3TW9kZWw7XG59KSgpOyIsInZhciBIb21lUGFnZVZpZXdNb2RlbCA9IHJlcXVpcmUoJy4vaG9tZXBhZ2Vfdmlld19tb2RlbCcpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBhcHBseVRvUGFnZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBzZlZpZXcgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2YtdmlldycpO1xuICAgICAgICBrby5hcHBseUJpbmRpbmdzKG5ldyBIb21lUGFnZVZpZXdNb2RlbCgpLCBzZlZpZXcpO1xuICAgIH1cbn07IiwidmFyIHNhbGVzX3NlcnZpY2UgPSByZXF1aXJlKCcuLi9zZXJ2aWNlcy9zYWxlc19zZXJ2aWNlLmpzJyk7XG5cbm1vZHVsZS5leHBvcnRzID0gKGZ1bmN0aW9uICgpIHtcbiAgICAndXNlIHN0cmljdCc7XG4gICAgdmFyIHNlbGY7XG5cbiAgICBmdW5jdGlvbiBIb21lcGFnZVZpZXdNb2RlbCgpIHtcbiAgICAgICAgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYudXNlcnNJZEFyciA9IG51bGw7XG4gICAgICAgIHNlbGYudXNlcnNEZXRhaWxEaWMgPSBudWxsO1xuICAgICAgICBzZWxmLnVzZXJzU2FsZURpYyA9IG51bGw7XG4gICAgICAgIHNlbGYuYWNjb3VudEZpZWxkQXJyID0gbnVsbDtcbiAgICAgICAgc2VsZi5hY2NvdW50RmllbGREZXRhaWxBcnIgPSBudWxsO1xuICAgICAgICBzZWxmLnNhbGVSZWNvcmRzID0ga28ub2JzZXJ2YWJsZUFycmF5KFtdKTtcbiAgICAgICAgc2VsZi51c2VyRmluYWNpYWwgPSBrby5vYnNlcnZhYmxlQXJyYXkoW10pO1xuICAgICAgICBzZWxmLmlzTG9hZGluZyA9IGtvLm9ic2VydmFibGUodHJ1ZSk7XG5cbiAgICAgICAgc2VsZi5pbml0aWFsaXNlKCk7XG5cbiAgICAgICAgc2VsZi5jYWNoZUNhY2hlcyA9IGZ1bmN0aW9uKGRhdGEpe1xuICAgICAgICAgICAgc2VsZi51c2Vyc0lkQXJyID0gZGF0YVtcInVzZXJzXCJdLnNwbGl0KFwiLFwiKTtcbiAgICAgICAgICAgIHNlbGYudXNlcnNEZXRhaWxEaWMgPSBkYXRhW1widXNlcnNfZGV0YWlsX2luZm9cIl07XG4gICAgICAgICAgICBzZWxmLnVzZXJzU2FsZURpYyA9IGRhdGFbXCJ1c2Vyc19zYWxlX3JlY29yZHNcIl07XG4gICAgICAgICAgICBzZWxmLmFjY291bnRGaWVsZEFyciA9IGRhdGFbXCJhY2NvdW50X2ZpZWxkXCJdO1xuICAgICAgICAgICAgc2VsZi5hY2NvdW50RmllbGREZXRhaWxBcnIgPSBkYXRhW1wiYWNjb3VudF9maWVsZF9kZXRhaWxcIl07XG4gICAgICAgIH07XG5cbiAgICAgICAgc2VsZi5jYWN1bGF0ZVJlY29yZHMgPSBmdW5jdGlvbigpe1xuICAgICAgICAgICAgdmFyIGFsbFJlY29yZHMgPSBbXTtcbiAgICAgICAgICAgIHZhciB0b3RhbEVhcm4gPSAwLjA7XG4gICAgICAgICAgICB2YXIgdG90YWxDb3N0ID0gMC4wO1xuICAgICAgICAgICAgdmFyIHVzZXJDb3N0QW5kRWFybiA9IFtdO1xuICAgICAgICAgICAgXy5lYWNoKHNlbGYudXNlcnNJZEFyciwgZnVuY3Rpb24odXNlcklkKXtcbiAgICAgICAgICAgICAgICB2YXIgdXNlckVhcm4gPSAwLjA7XG4gICAgICAgICAgICAgICAgdmFyIHVzZXJDb3N0ID0gMC4wO1xuICAgICAgICAgICAgICAgIHZhciB1c2VyTmFtZSA9IHNlbGYudXNlcnNEZXRhaWxEaWNbdXNlcklkXVsndXNlcl9uaWNrbmFtZSddO1xuICAgICAgICAgICAgICAgIHZhciBwZXJzb25SZWNvcmRzID0gc2VsZi51c2Vyc1NhbGVEaWNbdXNlcklkXTtcbiAgICAgICAgICAgICAgICBfLmVhY2gocGVyc29uUmVjb3JkcywgZnVuY3Rpb24gKHJlY29yZCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgaXRlbSA9IGdldEZpZWxkQnlGaWVsZElEKHJlY29yZC5maWVsZF9pZClbMF07XG4gICAgICAgICAgICAgICAgICAgIHZhciBpdGVtRGV0YWlsID0gZ2V0RmllbGREZXRhaWxCeUZpZWxkRGV0YWlsSWQocmVjb3JkLmZpZWxkX2RldGFpbF9pZClbMF07XG4gICAgICAgICAgICAgICAgICAgIHZhciBzdGFydFNpZ24gPSBpdGVtLnR5cGUgPyAnKCspICcgOiAnKC0pICc7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0ZXh0ID0gc3RhcnRTaWduO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS50eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyRWFybiArPSByZWNvcmQubW9uZXk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB1c2VyQ29zdCArPSByZWNvcmQubW9uZXk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGV4dCArPSBpdGVtLmZpZWxkICsgJzonICsgaXRlbURldGFpbC5uYW1lICsgJyAnICsgcmVjb3JkLm1vbmV5ICsgJyhDTlkpOyAnICsgcmVjb3JkLmRlc2NyaXB0aW9uO1xuICAgICAgICAgICAgICAgICAgICBhbGxSZWNvcmRzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgJ3RleHQnOiB0ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgJ2RhdGUnOiByZWNvcmQuZGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICdtb25leSc6IHN0YXJ0U2lnbiArIHJlY29yZC5tb25leSxcbiAgICAgICAgICAgICAgICAgICAgICAgICd1c2VyJzogdXNlck5hbWVcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdXNlckNvc3RBbmRFYXJuLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAndGV4dCc6IHVzZXJOYW1lLFxuICAgICAgICAgICAgICAgICAgICAndG90YWxDb3N0JzogdXNlckNvc3QsXG4gICAgICAgICAgICAgICAgICAgICd0b3RhbEVhcm4nOiB1c2VyRWFybixcbiAgICAgICAgICAgICAgICAgICAgJ3JldmVudWUnOiAodXNlckVhcm4gLSB1c2VyQ29zdCkudG9GaXhlZCgyKVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHRvdGFsQ29zdCArPSB1c2VyQ29zdDtcbiAgICAgICAgICAgICAgICB0b3RhbEVhcm4gKz0gdXNlckVhcm47XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgc2VsZi51c2VyRmluYWNpYWwoW3tcbiAgICAgICAgICAgICAgICAndGV4dCc6ICflkIjorqEnLFxuICAgICAgICAgICAgICAgICd0b3RhbENvc3QnOiB0b3RhbENvc3QsXG4gICAgICAgICAgICAgICAgJ3RvdGFsRWFybic6IHRvdGFsRWFybixcbiAgICAgICAgICAgICAgICAncmV2ZW51ZSc6ICh0b3RhbEVhcm4gLSB0b3RhbENvc3QpLnRvRml4ZWQoMilcbiAgICAgICAgICAgIH1dLmNvbmNhdCh1c2VyQ29zdEFuZEVhcm4pKTtcblxuICAgICAgICAgICAgdmFyIHNvcnRlZFJlY29yZHMgPSBfLmNoYWluKGFsbFJlY29yZHMpXG4gICAgICAgICAgICAgICAgLnNvcnRCeShmdW5jdGlvbiAocmVjb3JkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZWNvcmQuZGF0ZTtcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5yZXZlcnNlKClcbiAgICAgICAgICAgICAgICAudmFsdWUoKTtcbiAgICAgICAgICAgIHNlbGYuc2FsZVJlY29yZHMoc29ydGVkUmVjb3Jkcyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gZ2V0RmllbGRCeUZpZWxkSUQgKGZpZWxkSWQpe1xuICAgICAgICAgICAgcmV0dXJuIF8uZmlsdGVyKHNlbGYuYWNjb3VudEZpZWxkQXJyLCBmdW5jdGlvbihmaWVsZCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZpZWxkW1wiSURcIl0gPT09IGZpZWxkSWQ7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBnZXRGaWVsZERldGFpbEJ5RmllbGREZXRhaWxJZCAoZGV0YWlsSWQpe1xuICAgICAgICAgICAgcmV0dXJuIF8uZmlsdGVyKHNlbGYuYWNjb3VudEZpZWxkRGV0YWlsQXJyLCBmdW5jdGlvbihmaWVsZCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZpZWxkW1wiSURcIl0gPT09IGRldGFpbElkO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgfTtcblxuICAgIEhvbWVwYWdlVmlld01vZGVsLnByb3RvdHlwZS5pbml0aWFsaXNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gc2FsZXNfc2VydmljZS5nZXRBbGxTYWxlUmVjb3JkcygpXG4gICAgICAgICAgICAuZG9uZShmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGRhdGEpO1xuICAgICAgICAgICAgICAgIHNlbGYuY2FjaGVDYWNoZXMoZGF0YSk7XG4gICAgICAgICAgICAgICAgc2VsZi5jYWN1bGF0ZVJlY29yZHMoKTtcbiAgICAgICAgICAgICAgICBzZWxmLmlzTG9hZGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIEhvbWVwYWdlVmlld01vZGVsO1xufSkoKTsiLCJ2YXIgSm9pbkFjdGl2aXR5UGFnZVZpZXdNb2RlbCA9IHJlcXVpcmUoJy4vam9pbmFjdGl2aXR5cGFnZV92aWV3X21vZGVsJyk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIGFwcGx5VG9QYWdlOiBmdW5jdGlvbihvcGVuSWQsIGFjdGl2aXR5SWQpIHtcbiAgICAgICAgdmFyIHNmVmlldyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzZi12aWV3Jyk7XG4gICAgICAgIHZhciBtYWluUGFnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtYWluLXBhZ2UnKTtcbiAgICAgICAgbWFpblBhZ2UuaW5uZXJIVE1MID0gc2ZWaWV3LmlubmVySFRNTDtcbiAgICAgICAga28uYXBwbHlCaW5kaW5ncyhuZXcgSm9pbkFjdGl2aXR5UGFnZVZpZXdNb2RlbChvcGVuSWQsIGFjdGl2aXR5SWQpLCBtYWluUGFnZSk7XG4gICAgfVxufTsiLCJ2YXIgc2FsZXNfc2VydmljZSA9IHJlcXVpcmUoJy4uL3NlcnZpY2VzL2pvaW5fYWN0aXZpdHlfc2VydmljZS5qcycpO1xudmFyIHFyQ29kZSA9IHJlcXVpcmUoJ3FyY29kZS1ucG0nKTtcblxubW9kdWxlLmV4cG9ydHMgPSAoZnVuY3Rpb24gKCkge1xuICAgICd1c2Ugc3RyaWN0JztcbiAgICB2YXIgc2VsZjtcblxuICAgIGZ1bmN0aW9uIEpvaW5hY3Rpdml0eXBhZ2VWaWV3TW9kZWwob3BlbklkLCBhY3Rpdml0eUlkKSB7XG5cbiAgICAgICAgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYub3BlbklkID0gb3BlbklkO1xuICAgICAgICBzZWxmLmFjdGl2aXR5SWQgPSBhY3Rpdml0eUlkO1xuXG4gICAgICAgIHRoaXMuQUNUSVZJVFlfSVNfR09JTkcgPSA2MDA7XG4gICAgICAgIHRoaXMuQUNUSVZJVFlfTk9UX0ZPVU5EID0gNjAxO1xuICAgICAgICB0aGlzLkFDVElWSVRZX0lTX09WRVIgPSA2MDI7XG4gICAgICAgIHRoaXMuQUNUSVZJVFlfTk9UX1NUQVJUID0gNjAzO1xuICAgICAgICB0aGlzLkFDVElWSVRZX0hBU19KT0lORUQgPSA2MDQ7XG4gICAgICAgIHRoaXMuQUNUSVZJVFlfQ1JFQVRFX1NVQ0MgPSA5MDA7XG5cbiAgICAgICAgc2VsZi5zaGFrZUV2ZW50ID0gbmV3IFNoYWtlKHt0aHJlc2hvbGQ6IDE1fSk7XG4gICAgICAgIHNlbGYudXNlckFjdGl2aXR5ID0ge307XG4gICAgICAgIHNlbGYucHJpemUgPSB7fTtcblxuICAgICAgICBzZWxmLm1lc3NhZ2VUeXBlID0ga28ub2JzZXJ2YWJsZSgpO1xuICAgICAgICBzZWxmLm1lc3NhZ2VDb250ZW50ID0ga28ub2JzZXJ2YWJsZSgpO1xuICAgICAgICBzZWxmLmNvdXBvbklkID0ga28ub2JzZXJ2YWJsZSgpO1xuICAgICAgICBzZWxmLnByaXplTmFtZSA9IGtvLm9ic2VydmFibGUoKTtcbiAgICAgICAgc2VsZi5qb2luZWRUaW1lID0ga28ub2JzZXJ2YWJsZSgpO1xuICAgICAgICBzZWxmLmVuZERhdGUgPSBrby5vYnNlcnZhYmxlKCk7XG5cbiAgICAgICAgc2VsZi5pc0xvYWRpbmcgPSBrby5vYnNlcnZhYmxlKHRydWUpO1xuICAgICAgICBzZWxmLmlzRmlyc3RUaW1lID0ga28ub2JzZXJ2YWJsZShmYWxzZSk7XG4gICAgICAgIHNlbGYuaGFzSm9pbmVkID0ga28ub2JzZXJ2YWJsZShmYWxzZSk7XG4gICAgICAgIHNlbGYud29uQ291cG9uID0ga28ub2JzZXJ2YWJsZShmYWxzZSk7XG4gICAgICAgIHNlbGYuc2hvd01lc3NhZ2UgPSBrby5vYnNlcnZhYmxlKGZhbHNlKTtcblxuICAgICAgICBzZWxmLmluaXRpYWxpc2UoKTtcbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuZGlzcGF0Y2hlcldvblByaXplID0gZnVuY3Rpb24oKXtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLmlzTG9hZGluZyhmYWxzZSk7XG5cbiAgICAgICAgdmFyIHN0YXR1cyA9IHNlbGYucHJpemUuc3RhdHVzO1xuICAgICAgICBzd2l0Y2goc3RhdHVzKXtcbiAgICAgICAgICAgIGNhc2Ugc2VsZi5BQ1RJVklUWV9IQVNfSk9JTkVEOlxuICAgICAgICAgICAgICAgIHNlbGYuc2hvd0hhc0pvaW5lZE1lc3NhZ2UoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2Ugc2VsZi5BQ1RJVklUWV9DUkVBVEVfU1VDQzpcbiAgICAgICAgICAgICAgICBzZWxmLndvblByaXplKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuXG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuZGlzcGF0Y2hlciA9IGZ1bmN0aW9uKCl7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5pc0xvYWRpbmcoZmFsc2UpO1xuXG4gICAgICAgIHZhciBzdGF0dXMgPSBzZWxmLnVzZXJBY3Rpdml0eS5zdGF0dXM7XG4gICAgICAgIHN3aXRjaChzdGF0dXMpe1xuICAgICAgICAgICAgY2FzZSBzZWxmLkFDVElWSVRZX0lTX0dPSU5HOlxuICAgICAgICAgICAgICAgIGlmKHNlbGYudXNlckFjdGl2aXR5LmdvX3NoYWtlID09ICd5ZXMnKXtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93U2hha2UoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIHNlbGYuQUNUSVZJVFlfTk9UX0ZPVU5EOlxuICAgICAgICAgICAgICAgIHNlbGYuc2hvd05vdEZvdW5kKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIHNlbGYuQUNUSVZJVFlfSVNfT1ZFUjpcbiAgICAgICAgICAgICAgICBzZWxmLnNob3dBY3Rpdml0eUlzT3ZlcigpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSBzZWxmLkFDVElWSVRZX05PVF9TVEFSVDpcbiAgICAgICAgICAgICAgICBzZWxmLnNob3dBY3Rpdml0eUlzTm90U3RhcnRZZXQoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2Ugc2VsZi5BQ1RJVklUWV9IQVNfSk9JTkVEOlxuICAgICAgICAgICAgICAgIHNlbGYuc2hvd0hhc0pvaW5lZE1lc3NhZ2UoKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2Ugc2VsZi5BQ1RJVklUWV9DUkVBVEVfU1VDQzpcbiAgICAgICAgICAgICAgICBzZWxmLndvblByaXplKCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBkZWZhdWx0OlxuXG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUucmVzdG9yZSA9IGZ1bmN0aW9uKCl7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5pc0ZpcnN0VGltZShmYWxzZSk7XG4gICAgICAgIHNlbGYuaGFzSm9pbmVkKGZhbHNlKTtcbiAgICAgICAgc2VsZi53b25Db3Vwb24oZmFsc2UpO1xuICAgICAgICBzZWxmLnNob3dNZXNzYWdlKGZhbHNlKTtcbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUud29uUHJpemUgPSBmdW5jdGlvbigpe1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYucmVzdG9yZSgpO1xuICAgICAgICBzZWxmLndvbkNvdXBvbih0cnVlKTtcbiAgICAgICAgc2VsZi5wcml6ZU5hbWUoc2VsZi5wcml6ZS5uYW1lKTtcbiAgICAgICAgc2VsZi5jb3Vwb25JZChzZWxmLnByaXplLmNvZGUpO1xuICAgICAgICBzZWxmLmVuZERhdGUoc2VsZi5wcml6ZS5lbmRfZGF0ZSk7XG5cbiAgICAgICAgc2VsZi5kcmF3UVJDb2RlKHNlbGYucHJpemUuY29kZSk7XG4gICAgfTtcblxuICAgIEpvaW5hY3Rpdml0eXBhZ2VWaWV3TW9kZWwucHJvdG90eXBlLmRyYXdRUkNvZGUgPSBmdW5jdGlvbihjb2RlKXtcbiAgICAgICAgdmFyIHFyID0gcXJDb2RlLnFyY29kZSgxMCwgJ0gnKTtcbiAgICAgICAgcXIuYWRkRGF0YShjb2RlKTtcbiAgICAgICAgcXIubWFrZSgpO1xuXG4gICAgICAgIHZhciBpbWdUYWcgPSBxci5jcmVhdGVJbWdUYWcoKTtcbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJxcmNvZGVcIikuaW5uZXJIVE1MID0gaW1nVGFnO1xuICAgIH07XG5cbiAgICBKb2luYWN0aXZpdHlwYWdlVmlld01vZGVsLnByb3RvdHlwZS5zaG93U2hha2UgPSBmdW5jdGlvbigpe1xuICAgICAgICBjb25zb2xlLmxvZygnc2hvd1NoYWtlJyk7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5yZXN0b3JlKCk7XG4gICAgICAgIHNlbGYuaXNGaXJzdFRpbWUodHJ1ZSk7XG4gICAgICAgIHNlbGYuc3RhcnRTaGFrZVN1YnNjcmliZXIoKTtcblxuICAgICAgICAvLyQoXCIjc2hha2VCdXR0b25cIikuYmluZChcImNsaWNrXCIsZnVuY3Rpb24oKXtcbiAgICAgICAgLy8gICAgc2VsZi5zaGFrZUV2ZW50RGlkT2NjdXIoKTtcbiAgICAgICAgLy99KTtcbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuc2hha2VFdmVudERpZE9jY3VyID0gZnVuY3Rpb24oKXtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICB2YXIgYXVkaW8gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInNoYWtlLXNvdW5kLW1hbGVcIik7XG4gICAgICAgIGlmIChhdWRpby5wYXVzZWQpIHtcbiAgICAgICAgICAgIGF1ZGlvLnBsYXkoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGF1ZGlvLmN1cnJlbnRUaW1lID0gMDtcbiAgICAgICAgfVxuICAgICAgICBzZWxmLnN0b3BTaGFrZVN1YnNjcmliZXIoKTtcblxuICAgICAgICBzZWxmLmRyYXdGb3JBUHJpY2UoKTtcbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuc3RhcnRTaGFrZVN1YnNjcmliZXIgPSAgZnVuY3Rpb24oKXtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLnNoYWtlRXZlbnQuc3RhcnQoKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3NoYWtlJywgc2VsZi5zaGFrZUV2ZW50RGlkT2NjdXIuYmluZChzZWxmKSwgZmFsc2UpO1xuICAgIH07XG5cbiAgICBKb2luYWN0aXZpdHlwYWdlVmlld01vZGVsLnByb3RvdHlwZS5zdG9wU2hha2VTdWJzY3JpYmVyID0gIGZ1bmN0aW9uKCl7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5zaGFrZUV2ZW50LnN0b3AoKTtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3NoYWtlJywgc2VsZi5zaGFrZUV2ZW50RGlkT2NjdXIsIGZhbHNlKTtcbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuc2hvd0hhc0pvaW5lZE1lc3NhZ2UgPSBmdW5jdGlvbigpe1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYucmVzdG9yZSgpO1xuICAgICAgICBzZWxmLmhhc0pvaW5lZCh0cnVlKTtcbiAgICAgICAgc2VsZi5wcml6ZU5hbWUoc2VsZi51c2VyQWN0aXZpdHkuY291cG9uLm5hbWUpO1xuICAgICAgICBzZWxmLmNvdXBvbklkKHNlbGYudXNlckFjdGl2aXR5LmNvdXBvbi5jb2RlKTtcbiAgICAgICAgc2VsZi5qb2luZWRUaW1lKHNlbGYudXNlckFjdGl2aXR5LmNvdXBvbi5zdGFydF9kYXRlLnJlcGxhY2UoJ1QnLCAnICcpKTtcbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuc2hvd1VzZXJNZXNzYWdlID0gZnVuY3Rpb24odHlwZSwgY29udGVudCl7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5yZXN0b3JlKCk7XG4gICAgICAgIHNlbGYuc2hvd01lc3NhZ2UodHJ1ZSk7XG4gICAgICAgIHNlbGYubWVzc2FnZVR5cGUodHlwZSk7XG4gICAgICAgIHNlbGYubWVzc2FnZUNvbnRlbnQoY29udGVudCk7XG4gICAgfTtcblxuICAgIEpvaW5hY3Rpdml0eXBhZ2VWaWV3TW9kZWwucHJvdG90eXBlLnNob3dBY3Rpdml0eUlzTm90U3RhcnRZZXQgPSBmdW5jdGlvbigpe1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG4gICAgICAgIHNlbGYuc2hvd1VzZXJNZXNzYWdlKFxuICAgICAgICAgICAgXCLmtLvliqjluo/lj7fkuLrvvJpcIiArIHNlbGYuYWN0aXZpdHlJZCArIFwiIOeahOa0u+WKqOi/mOayoeacieW8gOWni1wiLFxuICAgICAgICAgICAgXCLor7flm57lpI3mlbDlrZfvvJoxIOafpeivouW9k+WJjea0u+WKqFwiXG4gICAgICAgICk7XG4gICAgfTtcblxuICAgIEpvaW5hY3Rpdml0eXBhZ2VWaWV3TW9kZWwucHJvdG90eXBlLnNob3dBY3Rpdml0eUlzT3ZlciA9IGZ1bmN0aW9uKCl7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgc2VsZi5zaG93VXNlck1lc3NhZ2UoXG4gICAgICAgICAgICBcIua0u+WKqOW6j+WPt+S4uu+8mlwiICsgc2VsZi5hY3Rpdml0eUlkICsgXCIg55qE5rS75Yqo5bey57uP57uT5p2fXCIsXG4gICAgICAgICAgICBcIuivt+WbnuWkjeaVsOWtl++8mjEg5p+l6K+i5b2T5YmN5rS75YqoXCJcbiAgICAgICAgKTtcbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuc2hvd05vdEZvdW5kID0gZnVuY3Rpb24oKXtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICBzZWxmLnNob3dVc2VyTWVzc2FnZShcbiAgICAgICAgICAgIFwi5rS75Yqo5bqP5Y+35Li677yaXCIgKyBzZWxmLmFjdGl2aXR5SWQgKyBcIiDnmoTmtLvliqjkuI3lrZjlnKhcIixcbiAgICAgICAgICAgIFwi6K+35Zue5aSN5pWw5a2X77yaMSDmn6Xor6LlvZPliY3mtLvliqhcIlxuICAgICAgICApO1xuICAgIH07XG5cbiAgICBKb2luYWN0aXZpdHlwYWdlVmlld01vZGVsLnByb3RvdHlwZS5pbml0aWFsaXNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICBpZihzZWxmLm9wZW5JZCA9PSAnaWhha3VsYV9jcmVhdGVfY291cG9uJykge1xuICAgICAgICAgICAgc2VsZi5pc0xvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgICAgdmFyIGNvdXBvbkluZm8gPSBzZWxmLmFjdGl2aXR5SWQuc3BsaXQoJzonKTtcbiAgICAgICAgICAgIHNlbGYucHJpemUgPSB7XG4gICAgICAgICAgICAgICAgbmFtZTogY291cG9uSW5mb1swXSxcbiAgICAgICAgICAgICAgICBjb2RlOiBjb3Vwb25JbmZvWzFdLFxuICAgICAgICAgICAgICAgIGVuZF9kYXRlOiBjb3Vwb25JbmZvWzJdLFxuICAgICAgICAgICAgICAgIHN0YXJ0X2RhdGU6IGNvdXBvbkluZm9bM11cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBzZWxmLndvblByaXplKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZWxmLmlzTG9hZGluZyh0cnVlKTtcbiAgICAgICAgICAgIHJldHVybiBzYWxlc19zZXJ2aWNlLmdldFVzZXJBY3Rpdml0eVN0YXR1cyhzZWxmLm9wZW5JZCwgc2VsZi5hY3Rpdml0eUlkKVxuICAgICAgICAgICAgICAgIC5kb25lKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYudXNlckFjdGl2aXR5ID0gZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5kaXNwYXRjaGVyKCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuXG4gICAgSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbC5wcm90b3R5cGUuZHJhd0ZvckFQcmljZSA9IGZ1bmN0aW9uKCl7XG4gICAgICAgIHNlbGYuaXNMb2FkaW5nKHRydWUpO1xuICAgICAgICByZXR1cm4gc2FsZXNfc2VydmljZS5kcmF3UHJpemUoc2VsZi5vcGVuSWQsIHNlbGYuYWN0aXZpdHlJZClcbiAgICAgICAgICAgIC5kb25lKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgc2VsZi5wcml6ZSA9IGRhdGE7XG4gICAgICAgICAgICAgICAgc2VsZi5kaXNwYXRjaGVyV29uUHJpemUoKTtcbiAgICAgICAgICAgIH0pO1xuICAgIH07XG5cbiAgICByZXR1cm4gSm9pbmFjdGl2aXR5cGFnZVZpZXdNb2RlbDtcbn0pKCk7Il19
(9)
});
