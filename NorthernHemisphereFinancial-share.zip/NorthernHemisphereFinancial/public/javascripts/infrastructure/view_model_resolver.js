//TODO Require this in the future

//var StaffingProxyViewModel = require('../view_models/staffing_proxy_view_model');
//var OpportunityDetailsModel = require('../view_models/opportunity_view_model');
//var OpportunityRoleViewModel = require('../view_models/opportunity_role_view_model');

//var viewModels = {
//    "/role": StaffingProxyViewModel,
//    "/opportunity-details": OpportunityDetailsModel,
//    "/opportunity-staffing": OpportunityRoleViewModel
//};
//
//module.exports = {
//    resolveViewModel: function (routeName) {
//        return viewModels[routeName];
//    }
//};